# AGENTS.md

- 修改前检查目标文件、同名文件、目录结构及关联依赖，遵循用户指定路径和项目规范。
- 新建辅助文件统一放入 `<项目根目录>/codexwork/<类别>/`，按需创建 `src`、`scripts`、`config`、`docs`、`assets`、`tests`、`build`、`output`、`temp`、`logs`。
- 文件名清晰明确，避免 `copy`、`backup`、`final2` 等含糊命名。
- 不擅自删除、移动或覆盖用户文件；同名交付文件先确认。
- 完成后清理本次产生的无用临时文件，报告实际修改与新增路径；归属不明的文件不擅自处理。

## 魔兽争霸 III 自动化测试

收到 Warcraft III 1.27、KKWE/JAPI 地图测试需求，或修改了需要实机验证的玩法时，先读 [测试操作手册](codexwork/docs/war3-test-ai.md)，再用 [测试 CLI](codexwork/scripts/war3-test/war3_test.py) 查看环境和可用场景。优先覆盖本次改动影响的玩法，按需扩展相关回归。已有场景无法覆盖时可为隔离地图创建场景配置。每轮用新的隔离运行目录，保持用户桌面可用，并依据实际游戏回执、断言、退出和清理状态决定是否复跑。
