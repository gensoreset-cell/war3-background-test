# planning-with-files 第五轮审查与 UTF-8 修复

2026-11-12 · Windows · Codex CLI 0.167.0-alpha.4.1

**审查评分 8.8 / 10，有条件投入日常开发。** 评分适用于本轮 Windows + Codex 环境。建议结束常规功能开发，转入真实游戏项目试运行。当前样本支持跨会话恢复，正式多小时工程验收及稳定节省 Token 仍待验证。

R4 是第五轮开测时已安装的第四轮版本。Windows UTF-8 补丁在本轮对照后安装，修复版另有真实压缩探针和安装后回归结果。

## 对照版本

| 版本 | 来源 | 对本轮有影响的变化 |
| --- | --- | --- |
| R0 | 本机历史修改逆向重建，28 个文件 | 早期 3.27.0 安装形态。上游发行版身份未核验 |
| R1 | 历史报告与差异 | 按适用性选择、按需读取、合并有意义的检查点。第一轮 34 项脚本与兼容检查通过 |
| R2 | 第三轮开始前的实际安装快照，31 个文件 | 扩展任务状态、依赖失效、条件写入与操作意图。历史 28 通过、1 跳过 |
| R3 | 第四轮开始前的实际安装快照，32 个文件 | 扩展审计绑定原生计划与验收依据，增加可选进度安全哈希 |
| R4 | 本轮开测时的实际安装，33 个文件 | 历史操作关闭、原生 turn_id 与 PostCompact 去重缓存清理 |

开测时 R4 的 33 个文件与上一轮候选快照逐字节匹配，第四轮安装清单的六个改动路径 SHA256 全匹配。原始第四轮补丁确有六个文件的变更。本轮源码指纹记录了逐版本文件差异（`source-fingerprints.json`）。

## 对照条件与判定

- 所有正式矩阵使用同一已登录 ChatGPT CLI、gpt-6.1-sol、low、相同夹具与提示。旧本机模型代理未监听，本轮与历史轮次之间的耗时不直接相减。预跑发现继承地图工程 AGENTS 后停止，正式夹具有独立 Git 根和最小 AGENTS。
- 自然模式是一项有明确边界的六配置文件迁移、战斗公式和产物生成。提示指定可读取的版本，是否创建持久计划由模型判断。每轮外部验证 26 项。
- 长任务有 24 个配置文件及同一战斗模块。阶段一迁移并留存计划，阶段二持久化改变后的需求并标记旧目录验收过期，阶段三以全新会话读取磁盘恢复。阶段二通过后，测试器实际写入 P01、P04 的新值，保留旧目录且不写业务完成日志。冷恢复须从现状识别两份已执行、四份待执行，保留已完成文件的原始字节并重验完整产物。部分落盘是受控注入。
- 自然模式限 180 秒，长任务各阶段限 180／125／180 秒。超时保留产物和已记录消耗，阻断该例的后续阶段。阶段有效需要正常退出和独立验收。所有跨版本百分比均从同一重复轮内、同阶段通过样本计算。
- 工具请求取 CLI rollout。文件计数覆盖夹具内 Python 文件打开事件，PowerShell 原生 I/O 另有命令记录。Cached Input 已计入 Input，表中总 Token 为 Input + Output。耗时按阶段 CLI 墙钟累加，包含启动、模型请求及会话内工具，阶段间人工复核和排程等待未计入。有些运行与另一测试通道重叠，顺序有轮换，服务端缓存与等待仍有波动。

## 自然模式

8/8 例通过，各为 26/26 项。四个版本两轮均选择直接交付，持久计划创建率为 0/8。

| 重复轮 | 版本 | Input | Cached Input | Output | 总 Token | 秒 | 工具请求 | Python 读／写 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | R0 | 99,653 | 90,240 | 1,426 | 101,079 | 74.645 | 4 | 17／8 |
| 1 | R2 | 99,008 | 89,472 | 1,582 | 100,590 | 85.732 | 4 | 17／21 |
| 1 | R3 | 121,524 | 102,400 | 1,576 | 123,100 | 81.194 | 5 | 19／21 |
| 1 | R4 | 122,551 | 112,128 | 1,784 | 124,335 | 87.378 | 5 | 33／27 |
| 2 | R0 | 101,947 | 91,520 | 1,402 | 103,349 | 82.517 | 4 | 24／14 |
| 2 | R2 | 91,086 | 82,304 | 1,332 | 92,418 | 68.490 | 4 | 16／8 |
| 2 | R3 | 97,893 | 81,792 | 1,251 | 99,144 | 82.382 | 4 | 25／8 |
| 2 | R4 | 98,008 | 89,216 | 1,574 | 99,582 | 86.935 | 4 | 21／21 |

R4 对 R0 的总 Token 分别为 +23.01%、−3.64%，耗时为 +17.06%、+5.35%。对 R2 的总 Token 为 +23.61%、+7.75%，耗时为 +1.92%、+26.93%。对 R3 的总 Token 为 +1.00%、+0.44%，耗时为 +7.62%、+5.53%。两轮均无自然模式节省的稳定证据。第四轮报告的 −51.68% 来自另一轮单样本，且该次 R0 启用了持久计划。本轮四个版本均跳过持久计划，该历史幅度未复现。

### 重复访问核对

自然模式 R4 第一例有 33 次 Python 读，24 次是六份配置各四次。命令回执显示四次分别用于迁移前加载、保留换行格式、从落盘配置生成目录、独立验收。可合并前两次对原字节的取样，保留独立验收。另有 19 次写打开来自实验用 reader 日志，不能计为业务产物写入。第二例配置各读两次，分别用于迁移与落盘验收。长任务 R3 第一例的变更阶段虽有 7 个 shell 操作项，Python 读写为 0，说明 PowerShell 访问不能用 Python 计数推断。全矩阵的无效重复读率与全系统读写量无法从当前仪表可靠估计。 R4 第一例命令回执（`matrix-natural-1-v4-phase1.events.jsonl`）

## 强制持久计划的长任务

每例按迁移、变更、冷恢复逐阶段判定。8 例完成 6 例，20/24 个预定阶段通过，2 个变更阶段超时，2 个冷恢复阶段依停止门槛未启动。所有实际进入冷恢复的 6 例均通过，36/36 个目标分类正确。R4 为 1/2 个完整任务、4/6 个预定阶段、1/1 个实际进入的冷恢复，目标分类 6/6。

阶段一和三分别有 44 项独立业务检查。阶段二检查计划已保存、变更可恢复、业务文件保持旧字节。冷恢复另验六份目标的原状态分类、未受影响文件的字节、计划最终状态和技能副本哈希。

| 重复轮 | 版本 | 阶段通过数 | Input | Cached Input | Output | 总 Token | 秒 | 工具请求 | Python 读／写 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | R0 | 3/3 | 611,622 | 560,256 | 9,655 | 621,277 | 373.112 | 22 | 156／110 |
| 1 | R2 | 1/3，阶段二超时 | 394,131 | 308,736 | 6,055 | 400,186 | 248.857 | 14 | 82／78 |
| 1 | R3 | 3/3 | 540,717 | 483,584 | 9,342 | 550,059 | 387.670 | 19 | 149／64 |
| 1 | R4 | 3/3 | 512,909 | 447,360 | 8,405 | 521,314 | 361.042 | 18 | 170／164 |
| 2 | R0 | 3/3 | 679,648 | 620,928 | 10,178 | 689,826 | 414.411 | 23 | 203／196 |
| 2 | R2 | 3/3 | 529,227 | 471,296 | 8,621 | 537,848 | 365.759 | 19 | 167／150 |
| 2 | R3 | 3/3 | 550,747 | 486,784 | 8,556 | 559,303 | 371.140 | 20 | 152／138 |
| 2 | R4 | 1/3，阶段二超时 | 422,270 | 374,016 | 6,580 | 428,850 | 251.855 | 15 | 76／99 |

表内成本包含已尝试的阶段。第一轮完整对照中，R4 相对重建 R0 的总 Token 减少 16.09%、用时减少 3.23%，未缓存输入增加 27.61%。相对 R3，总 Token 减少 5.23%、用时减少 6.87%，未缓存输入增加 14.73%。缓存输入与未缓存输入走势不同，整体 Token 变化不能直接解释为同幅度计费或可复现提速。R2 和 R4 分别完成第二、第一轮，两者没有同轮全程配对。

两轮迁移阶段，R4 均完成 44/44 业务验收，相对 R0 分别少用约 22.2% 和 20.9% 总 Token，相对 R3 分别多用约 4.4% 和 5.9%。这是同质量阶段对照。需求变更和冷恢复的完整收益仍以全程配对为准。

R4 第一例的阶段二原判失败来自测试器只接受字面 `+5` 和 `+1`。实际计划明确写了基于 schema 2 的增量，并列出 P00–P05 的六组准确前后值、目录证据失效与恢复收据。复核通过后保留原判定及复核凭据，继续阶段三。模型会话未重跑，原来的耗时、Token 和文件读写保留。第二例阶段二超过 125 秒，第三阶段未启动。 原始判定（`matrix-long-1-v4-phase2.result.json`） · 复核凭据（`matrix-long-1-v4-phase2.review.json`） · 第二例超时（`matrix-long-2-v4-phase2.result.json`）

## 已验证的原生压缩

测试中 Codex 真实自动压缩并在 rollout 写入 `compacted`。压缩前同一会话的第二次 PreToolUse 因去重保持静默。PostCompact 对当前缓存槽执行删除，输出为空。其后同 turn 的首个 PreToolUse 重新输出计划帧，随后恢复去重。PreCompact 在探针中只记录事件，以便单独验证 PostCompact 对缓存的影响。该配置只用于探针。每个探针经历一次压缩，多小时工程中连续压缩的稳定性仍待验证。 [官方 Hooks 文档](https://learn.chatgpt.com/docs/hooks#postcompact)

| 探针 | 实际事件和模型结果 | 检查 | 秒 | Input／Cached Input／Output |
| --- | --- | --- | ---: | --- |
| R4 支持投递 | 一次真实压缩，下一次 PreToolUse 重新注入。模型写回仅随此次 Hook 上下文投递的随机回执 | 8/8 | 82.342 | 72,378／40,320／537 |
| R4 磁盘回退 | 一次真实压缩，记录器抑制模型上下文投递。模型实际读取计划和进度，写回仅存磁盘的正确回执 | 8/8 | 70.333 | 93,575／89,856／571 |
| UTF-8 修复候选 | 强制 Python 非 UTF-8 模式，一次真实压缩，去重、清除、注入及回执均通过 | 8/8 | 78.995 | 94,152／88,064／627 |

三例的计划与原始 UI 文件哈希保持一致。Hook 随机回执由测试记录器添加，只用于证明实际投递。模型通过计划和进度取回的磁盘回执另行验证。这些探针分别验证功能，耗时和 Token 不用于比较 Hook 与磁盘模式的效率。真实压缩事件、逐次回调、缓存槽及外部断言见原生投递（`compact-native-hook.result.json`）、磁盘回退（`compact-native-disk.result.json`）、修复后探针（`compact-fixed-hook.result.json`）及rollout 见证（`compaction-rollout-witness.json`）。

### 确认并修复的缺陷

Codex 原生 Hook 发送 UTF-8 JSON，第四轮注入器用控制台默认编码读取文本。Windows 非 UTF-8 环境遇到未转义的中文路径时，可能在 JSON 解析前解码失败，也可能破坏路径及身份解析。最小探针开始无回调记录。App Server 诊断随后确认处理器实际被触发且退出 1，确定了探针自身也有同类解码问题。

修复仅让 `--codex-event` 从标准输入按字节接收 JSON，沿用 legacy 的 stdin 处理路径。受控反例中，旧版对四次原生调用都退出 3，修复版通过注入、去重、清除、重注入四次调用。原始 R4 回归为 71 通过、1 跳过，候选为 72 通过、1 跳过。跳过的是既有 Windows 符号链接权限测试。修复已安装，包内仅注入器与回归测试两个文件发生变化，安装字节匹配候选，安装后 7 项原生恢复测试全过。对照仍使用修复前的 R4。详见补丁（`planning-with-files-round5-utf8.patch`）、反例（`encoding-negative-control.json`）、候选回归（`encoding-candidate-regression.txt`）和安装证据（`encoding-fix-installation.json`）。

## 可选机制的收益与开销

| 机制 | 实际安全收益 | 成本与适用范围 |
| --- | --- | --- |
| 操作意图、实际状态观察和扩展任务图 | 同一操作 ID 保留原前置值。显式依赖、真实文件和证据变化可传播失效。原生阶段写成完成时，扩展审计仍会拦住过期验收和未解决操作 | 需要记录目标、依赖、基线、验收证据和版本，维护成本随变更增长。长任务矩阵只强制原生计划，额外机制的模型 Token 增量未单独测量。涉及可重放副作用或真实依赖图时按需使用 |
| 进度安全哈希 | 阶段状态、勾选及合法阶段引用更新后，旧凭据仍有效。受保护目标改写仍拒绝 | 本轮 151 次交错样本，20 阶段约 29.5 KB 的在内存中位数为全哈希 0.086 ms、进度安全 3.896 ms。100 阶段为 0.371／16.672 ms。安全投影需解析 Markdown 并受支持格式约束。确有频繁状态更新和凭据绑定冲突时再启用 |
| 历史操作关闭／取代 | 已验收的旧字节不再阻止同一任务后续合法提交，当前目标意外改变仍能拦截 | 第四轮 100 条同目标合成意图审计从 576.622 ms 降至 185.448 ms。逐条关闭先耗 36.945 秒，状态约增 61.7 KB，需要约 95 次同样审计才能摊平局部耗时。适用于确有历史字节冲突的条目，保持默认关闭 |
| 原生 PostCompact 和磁盘回退 | 缓存清理和后续计划投递已获真实运行回执。投递失效时仍能从已保存计划和进度恢复 | 只注册实际需要的事件。计划重新投递和磁盘回读都消耗工具或上下文，本轮未估算生产环境平均额外 Token |

进度哈希实测（`progress-hash-local.json`） · 第四轮历史关闭成本（`closure-adoption-cost.json`）

## 真实项目试运行

建议在《绽于深渊的少女》的独立测试分支选择一项跨多个系统、需要反复验证的开发任务，走完计划、实施、需求调整、中断恢复和最终验收。

| 优先级 | 验收事项 |
| --- | --- |
| P0 | 记录需求变更阶段的耗时和超时前已完成的步骤，定位 R4 长任务中变更阶段的超时原因。 |
| P1 | 让测试器按实际数值、落盘状态及验收状态确定性判定，继续保留原判定和复核记录。 |
| P1 | 完成一次多小时真实工程验收，核对目标偏移、重复操作、漏改文件和验收证据丢失，观察同一任务经历多次压缩后的恢复。 |

扩展任务图、进度安全哈希和历史操作关闭继续按需启用。试运行中发现可复现问题后，再针对该问题调整 Skill。

## 证据索引

本轮原始材料包括实测报告、逐阶段 CSV、证据 JSON 和修复补丁。CSV 记录 30 个已执行阶段，JSON 汇总用例、配对比较、压缩回执及安装证据。

- 实测报告 `planning-with-files-round5-report.md`
- 逐阶段数据 `planning-with-files-round5-stages.csv`
- 原始证据 `planning-with-files-round5-evidence.json`
- Windows 修复 `planning-with-files-round5-utf8.patch`，原文见下方

## Windows UTF-8 修复补丁

| 改动路径（相对于 Skill 安装目录） | 改动 |
| --- | --- |
| `scripts/inject-plan.py` | 原生 Codex 事件通过 `sys.stdin.buffer` 读取 UTF-8 JSON 字节，legacy 事件继续使用文本标准输入。 |
| `codexwork/tests/test_native_integrity.py` | 在 ASCII 标准输入编码环境下注入含中文路径的 UTF-8 JSON，验证首次注入、去重、PostCompact 清除及重新注入。 |

```diff
--- a/scripts/inject-plan.py
+++ b/scripts/inject-plan.py
@@ -1848,7 +1848,9 @@
     context, event = parse_args(argv)
     try:
         if event is not None:
-            payload = sys.stdin.read()
+            # Native Codex sends UTF-8 JSON regardless of the host console locale.
+            payload = (sys.stdin.buffer.read() if any(arg.startswith("--codex-event=") for arg in argv)
+                       else sys.stdin.read())
             if (os.environ.get("PWF_SKIP_SUBAGENTS") == "1"
                     and event in ("pre-tool-use", "post-tool-use")
                     and not hook_is_main(payload)):
--- a/codexwork/tests/test_native_integrity.py
+++ b/codexwork/tests/test_native_integrity.py
@@ -154,6 +154,28 @@
         self.assertEqual(self.event('PreToolUse'),b'')
         self.assertIn(b'BEGIN-PWF-DATA',self.event('PreToolUse',turn='round4-turn-2'))
 
+    def test_native_utf8_payload_is_independent_of_console_encoding(self):
+        payload = json.dumps({
+            'session_id': 'native-utf8-session',
+            'turn_id': 'native-utf8-turn',
+            'cwd': str(self.root / '\u7efd\u4e8e\u6df1\u6e0a'),
+            'tool_name': 'Bash',
+        }, ensure_ascii=False).encode('utf-8')
+        env = {**self.env, 'PYTHONIOENCODING': 'ascii'}
+
+        def event(name):
+            result = subprocess.run(
+                [sys.executable, '-B', str(ROOT / 'scripts/inject-plan.py'), '--codex-event=' + name],
+                input=payload, cwd=self.root, env=env, capture_output=True, timeout=15,
+            )
+            self.assertEqual(result.returncode, 0, result.stderr)
+            return result.stdout
+
+        self.assertIn(b'BEGIN-PWF-DATA', event('PreToolUse'))
+        self.assertEqual(event('PreToolUse'), b'')
+        self.assertEqual(event('PostCompact'), b'')
+        self.assertIn(b'BEGIN-PWF-DATA', event('PreToolUse'))
+
     def test_postcompact_clears_only_current_session_and_reinjects_once(self):
         self.assertIn(b'BEGIN-PWF-DATA',self.event('PreToolUse'))
         self.assertIn(b'BEGIN-PWF-DATA',self.event('PreToolUse',session='another-session'))
```
