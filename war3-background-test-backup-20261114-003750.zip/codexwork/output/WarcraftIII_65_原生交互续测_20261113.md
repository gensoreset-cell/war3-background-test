# 《65.w3x》原生交互后台续测

2026-11-13 JST。Windows 11 build 22631，控制台会话 1，Warcraft III 1.27.0.52240，OpenGL，KKWE/JAPI。客户端与地图都在独立档案，游戏在 `WinSta0` 的新建私有桌面，`Default` 保持接收用户输入。

## 结论

冻结候选已在私有桌面用 `Tab → Enter` 选择原生难度。E12 引擎截图直接显示「选择了【困难难度】」。只加回执、保留难度脚本和按钮参数的版本另有 `source=dialog|index=2|value=5`。同一回执版的定向鼠标在窗口过程完成三条消息后无难度回调，随后用键盘立即取得回执。 [冻结候选原生画面](../logs/war3-65-cold/E12-frozen-endurance/engine-frozen-difficulty.bmp)

当前私有桌面路线可通过真实鼠标消息预选奥菲斯 H005。完成选人所需的第二个原生事件尚未出现。原计时器到期、原生选择事件和实际回放均支持这一结论。战斗、任务推进和选人后的整条后台路线仍未通过。

## 输入与证据

| 输入 | SHA-256 |
| --- | --- |
| 正式原图 `65.w3x` | `cc8fe6f073184751571db8f53cac0e78645523429b4ea0136f70c13dd023b346` |
| 冻结候选 `ab65.w3x` | `d21fb1e5c2d16ae7e09a05ce3874f31f9d85ed6065c97c9102a6d67a94de6c10` |
| 上一轮隐藏难度框的诊断图 | `e28435dc4cfb042b434f1606cbb01b88a03aa5b6016fb3e0565f20ba8fbbb760` |
| 本轮只加难度回执的诊断图 | `6ef0f73cac91a81caeea2e319f6775b4db24a1daddd653b8020d50e910ca9ccf` |
| 本轮带原生选择、计时、镜头和门户观测的诊断图 | `51d86a9532ba5f92f583a7f61762cdcd1a1985c241747baba6697e0655154c86` |

复用上一轮已验证的独立 Job、Lua53Host 控制流和 PID 核对。每轮从空档案启动，入场与退出复核 32 项输入和正式原图的哈希，先验证 Job 内归属再控制自有窗口。诊断图由冻结候选派生。PJass 通过，读取比较 3776 个归档成员，只有 `war3map.j` 改动。保留难度框显示、三个按钮原参数、原始计时与数值、原生英雄事件和战斗逻辑。备用热键图另建且未用于实机结论。 [上一轮报告](WarcraftIII_65_后台自动化续研_20261113.md) · [难度回执构建](../build/war3-65-cold/dialog-probe-receipts-01/changes.json) · [选择回执构建](../build/war3-65-cold/dialog-probe-route-selection-01/changes.json)

## 难度框的故障定位

| 轮次 | 条件 | 游戏内结果 |
| --- | --- | --- |
| E01 | 冻结候选，定向 Space，随后 `Tab → Enter` | 心跳从 1 恢复至 5，菜单自然退出。冻结图没有所选难度的独立回执。 |
| E02 | 原难度逻辑加只读回执，定向 `Tab → Enter` | `dialog-shown` 记录原生三按钮和 3 秒默认计时。`dialog-chosen` 记录真实按钮事件、困难索引 2、值 5，菜单自然退出。 |
| E03 | 同 E02 SHA，先同步投递鼠标，等待，再发键盘 | 在已核对的 1904×984 客户区 `(955,359)` 发送 move、down、up，窗口过程三条均返回。期间仍停在第 1 条心跳，无难度回调。其后 `Tab → Enter` 触发同一困难回执并自然退出。 |

E02、E03 的目标 HWND、进程、私有桌面、DPI、客户区及 GUI 线程焦点均核实。E03 确定卡在窗口收到鼠标消息后、Warcraft 把它解释为有效模态按钮操作之前。`GetCursorPos` 在私有桌面返回 Win32 5。E10 对照窗口平移前后，游戏内 JAPI 鼠标坐标分别对应屏幕 `(0,0)` 换算至客户区的位置，仍能观察到鼠标按下事件。这支持系统光标回读与定向消息彼此独立。当前证据未定位 Warcraft 模态按钮内部具体调用点，也未用同一次鼠标截图逐像素确认按钮边界。键盘路线已避开这项局限。 [E01](../logs/war3-65-cold/E01-frozen-native/trial.json) · [E02](../logs/war3-65-cold/E02-native-receipts/game-output/Logs/dialog-chosen.pld) · [E03 鼠标回执](../logs/war3-65-cold/E03-mouse-wndproc/input-dialog-mouse-1-stdout.log) · [E03 全程](../logs/war3-65-cold/E03-mouse-wndproc/trial.json) · [Windows 光标规则](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getcursorpos)

## 选人与原生画面

- E04 首次 Space 太早或未被游戏接受，12 秒内无首条心跳，监督器回收。随后加入只在缺少首条心跳时的一次有界重试。E05 两次 Space 后到达难度与英雄界面。 [E04](../logs/war3-65-cold/E04-native-hero/trial.json) · [E05](../logs/war3-65-cold/E05-hero-pointer/trial.json)
- E05 两条左键按下均到达游戏输入探针，H005 原生选择事件发生一次。1904×984、32 位原生 TGA 显示困难和奥菲斯预览面板，尚处选人倒计时，金币 0。普通 `PrintWindow`、`BitBlt` 返回均匀像素，DWM 注册与更新返回成功但取回缓冲无变化。游戏自身 PrintScreen 产生有效图像，其原始 TGA SHA-256 为 `8be41a3f3d8ad2c66a00641d672fe8e959df925abe81be767fbebf2de4d095eb`。 [游戏画面](../logs/war3-65-cold/E05-hero-pointer/engine-hero-first.bmp) · [像素验证](../logs/war3-65-cold/E05-hero-pointer/engine-frame-validation.json) · [DWM 回执](../logs/war3-65-cold/E05-hero-pointer/game-dwm-thumbnail/observe-stdout.log) · [Blizzard 经典客户端截图说明](https://classic.battle.net/war3/faq/war3guide.shtml)
- E06 在两次选择之间插入 Escape，也测试了 `WM_LBUTTONDBLCLK`。后一次比较时镜头已经偏离英雄队列，结果不能单独否定双击消息。E07 的空地过渡试验也因镜头漂移未击中第一个 H005。之后发送了一条当时尚未加入运行中进程允许列表的命令，守卫回收游戏。已更新守卫，未知操作只记录拒绝；仍在 Job 内的游戏继续受监督。 [E06](../logs/war3-65-cold/E06-native-route/trial.json) · [E07](../logs/war3-65-cold/E07-empty-reselect/trial.json)
- E08 只平移私有游戏窗口以改变光标回退点，镜头最后稳定在 `(29696,9696)`。实际发生 H005 取消选中及 H033 预选，说明局部鼠标可以产生其他真实选择。这个变体的私有窗口焦点为空。E09 保持原始窗口位置，首次 H005 `owner=15` 在游戏 `2.650` 秒触发，同一原生计时器在 `3.150` 秒到期且 `committed=0`。两个按下相隔约 112 毫秒。回放仅有一次预选，无玩家拥有的 H005 或移动、攻击指令。 [E08](../logs/war3-65-cold/E08-centered-route/trial.json) · [E09 选择事件](../logs/war3-65-cold/E09-hero-timing/game-output/Logs/route-selection-1.pld) · [E09 计时到期](../logs/war3-65-cold/E09-hero-timing/game-output/Logs/route-selection-expired-1.pld) · [回放对照](../logs/war3-65-cold/resume-replay-cross-check.json)
- E10 通过同桌面的私有线程输入队列临时绑定恢复了目标 HWND 焦点，解除绑定后焦点保留，`Default` 未切换。H005 仍仅预选一次，原计时精确到期。两点点击、约 200–230 毫秒间隔、Shift 中转和空地中转未获得第二次原生事件。E11 在初始镜头下把空地插入时间延后再试，仍仅一次预选。两轮都通过菜单自然退出。 [E10 焦点回执](../logs/war3-65-cold/E10-private-focus/private-window-focus-stdout.log) · [E10](../logs/war3-65-cold/E10-private-focus/trial.json) · [E11](../logs/war3-65-cold/E11-timed-deselect/trial.json)

代表性自然路线已定位到原图的选人、走入村口区 035、按原生 Q 按钮传送和击杀首只灰狼。目标地图的回执只读取这些事件，不写英雄、金币、生命、击杀数或任务。由于 H005 未正式出生，当前没有启动 Q 或攻击自动验收。上一轮通过聊天触发的 READY/MUTATED 只验证探针状态变化。

## 前台活动与持续运行

- E07 的被动观察在 105.210 秒内采样 419 次，记录 21 次输入时间更新。E10 在 186.542 秒内采样 742 次，记录 10 次输入更新。两轮游戏成为用户桌面前台的样本均为 0，输入桌面保持 `Default`。观察只记录计数，不能区分人工和其他同会话程序的输入。 [E07 被动观测](../logs/war3-65-cold/E07-empty-reselect/activity/result.json) · [E10 被动观测](../logs/war3-65-cold/E10-private-focus/activity/result.json)
- E08 帧率和资源没有单独采样。逐条游戏文件写入时间确认最长连续心跳 273.476 秒，菜单正常退出。E11 同口径 78.730 秒。此处覆盖真实难度进入后的空闲/选人界面，英雄出生后的耐久仍需取证。
- E12 用冻结 SHA 运行 639.658 秒，原生 `Tab → Enter` 选择困难后留在选人及随后的空闲状态。共 605 条心跳，第 2 至 605 条连续 604.258 秒，监督器单调时钟观察为 604.974 秒。定向菜单退出，游戏与宿主均为 0，Job 空，无超时终止。被动观察采样 2550 次，`Default` 始终为输入桌面，无游戏前台样本。期间输入更新时间变化为 0，因此该次耐久没有叠加实际会话活动。 [耐久原始回执](../logs/war3-65-cold/E12-frozen-endurance/trial.json) · [被动监测](../logs/war3-65-cold/E12-frozen-endurance/activity/result.json)
- E12 冻结候选在第 350 条心跳附近的一次性能采样记录游戏工作集约 639 MiB、游戏 3D 引擎约 29.7%。游戏进程 CPU 在该通道不可读。数据为单点采样，未进行用户前台负载的性能对照。 [资源原始采样](../logs/war3-65-cold/E12-frozen-endurance/resource-sample.json)

## 复现及下一步

在 `E:\RPG\长任务` 使用本机 Python 3.13 和新的目录名。`dialog_trial.py` 只对自己的 Job 和私有桌面执行输入。`--activity` 在 `Default` 上启动被动观察器。当前机器只观察到单个活跃的控制台会话，RDP 服务停止，未发现可直接调用的 Windows 来宾。

```powershell
$py = 'C:/Users/Administrator/AppData/Roaming/uv/python/cpython-3.13.18-windows-x86_64-none/python.exe'
$trial = 'codexwork/scripts/war3-65-cold/dialog_trial.py'
& $py -B $trial codexwork/logs/war3-65-cold/repro-native-dialog codexwork/build/war3-65-cold/repro-native-profile --stage --actions dialog-nav --hold 600 --limit 735 --activity --screenshot
```

继续定位第二次选中需要一个可用的真实输入正对照。可使用短时独占当前控制台，或使用已有且获准的独立可输入图形会话。用同一选择回执图在原 0.5 秒窗口内采集实体双选事件和回放，再在私有桌面对照。英雄正式出生后，依原村口 Q 和自然灰狼击杀验收代表性任务，并复跑有前台活动的完整路线。共享用户桌面上的实体输入需要用户明确安排可独占窗口，当前后台实验保持用户桌面可用。

已准备 `dialog_trial.py --manual-default` 的只采集对照入口。该入口在用户允许占用桌面时用同一诊断候选启动，仅等待真实输入、记录事件与回收。它尚未在用户桌面运行。

本轮新增的脚本为 `build_dialog_probe.py`、`dialog_trial.py`、`desktop_activity.py`、`window_observe.py` 和 `replay_observe.py`，更新了 `directed_confirm.py` 与 `run.py`。构建校验、原始 `.pld`、回放、游戏内 TGA 和监督器日志保存在 `codexwork/build/war3-65-cold/` 与 `codexwork/logs/war3-65-cold/E01-*` 至 `E12-*`。关闭后校验并清理重复客户端目录。证据包保留源代码和构建说明，地图与客户端由本机隔离目录另行提供。上一轮 702 项证据包已重新通过 CRC 和逐项 SHA-256 检查。

本轮 12 次串行实机的监督时间合计 1847.750 秒，约 30 分 48 秒。10 次正常菜单退出，E04 和 E07 通过当次自有句柄回收，最终进程快照无 War3、Lua53Host 或编辑器。正式原图、冻结候选和诊断输入哈希复核一致。 [最终进程检查](../logs/war3-65-cold/resume-final-processes/result.json)
