﻿# Warcraft III 后台自动化测试可行性研究报告

2026-11-12（日本时间） · Windows · Warcraft III 1.27.0.52240 · 《65.w3x》

## 结论

**本机已证实 Warcraft III 1.27 可以在后台加载地图、执行真实游戏逻辑并自动回传结果，期间无需使用用户的前台窗口、鼠标或键盘。** 原版客户端用 OpenGL 启动，在非输入 Win32 桌面完成了 7 轮探针测试，全部取得 JASS 计时、原生伤害和游戏存档。开局后最小化、隐藏和遮挡都通过了单轮对照。

**《65.w3x》已在后台进入地图初始化，完整逻辑回归仍受阻。** 未改脚本的 Diagnostic 写出本地档案。受控副本执行了地图入口，且玩家、槽位和本地模式均符合测试前置条件。额外注册的 1 秒计时器未回传，原有受控路线也无后续断言。当前证据把阻塞缩小到地图入口后的推进。 正式 L1 仍受独立的发布链门禁约束。本轮未运行 L0 原图或正式 L1，也未做多人、KK 实房和平台存档验收。

**主方案与备选。** 普通 JASS 地图可以开始接入本机非输入 Win32 桌面的日常冒烟。针对《65.w3x》，下一步首选带 3D 的 Windows 虚拟机，让来宾游戏保持可交互，同时释放宿主的桌面和输入。备选为独立 Windows 实机。两条路线都先验证同 SHA 地图的计时推进、任务断言和真实画面，达到门槛后再扩展自动化。

## 一、本机实测

### 环境与范围

- Windows Pro build 22631，控制台会话 2。测试进程运行在 WinSta0 的非输入桌面，输入桌面始终为 `Default`。未切换宿主桌面、未发送鼠标键盘输入。进程结束后确认无本轮 War3 残留。
- 读到 NVIDIA GeForce GTX 1070。另有 GameViewer Virtual Display Adapter，枚举到的 10 个虚拟输出均未显示附着标志。64 位辅助进程的非输入桌面 D3D9 隐藏窗口能枚举一个适配器，HAL 创建设备返回 `0x8876086A`。此结果和 32 位游戏弹窗共同指向当前环境的图形初始化问题，驱动、桌面条件和适配器各自的影响尚未分离。
- 本机常用安装路径、命令和服务未找到可直接调用的 VMware、VirtualBox、Hyper-V 管理环境或 Windows Sandbox 启动器。CIM 受限，未判定虚拟化硬件和 Windows 可选功能的启用状态。本轮未安装虚拟化组件或改变系统设置。
- 原图 SHA-256 前后均为 `cc8fe6f073184751571db8f53cac0e78645523429b4ea0136f70c13dd023b346`。所有实验使用专用副本，未写入原图、正式工程、既有启动器或配置。只启动本地 KKWE 测试，没有登录 KK 平台或使用在线存档。

### 启动负向对照

| 真实客户端启动方式 | 观察 | 结果 |
| --- | --- | --- |
| 非输入桌面，默认图形 | 1.62 秒出现主窗，3.04 秒读到 DirectX 弹窗 | 初始化失败 |
| 请求最小化启动 | 主窗实际最小化，约 0.81 秒读到相同弹窗 | 初始化失败 |
| 请求隐藏启动 | 主窗不可见，约 0.81 秒读到相同弹窗 | 初始化失败 |
| 显式新建 Win32 桌面，默认图形 | 游戏在新桌面创建窗口，1.61 秒读到相同弹窗 | 隔离成功，初始化失败 |
| 同一探针图，默认图形 | 约 1.52 秒读到相同弹窗，未产生游戏回执 | 地图未进入 |

弹窗原文为「魔兽争霸III不能初始化DirectX」。带地图的 OpenGL 对照保留完整客户端和基础 MPQ。现有公开资料未提供暴雪 1.27 纯 Headless 客户端的可用证据。Windows 启动时隐藏窗口和引擎完成图形初始化是两个独立检查项。

### 后台逻辑与窗口状态

从项目已有小地图复制出探针，使用 StormLib 只替换副本的活动 JASS。PJass 返回 0，MPQ 回读和脚本字节一致。JASS 创建真实步兵，每个游戏秒写一份 PreloadGen 回执，第 3 次回执后调用原生伤害接口，第 8 次调用游戏存档。探针源图保持原字节。

将地图放在私有客户端的 Maps 目录，从客户端工作目录启动。保持 `-loadfile` 在前，并使用实测的参数顺序。

    War3.exe -loadfile Maps\bg.w3x -window -opengl

| 实验 | PID | 观察到的状态 | 游戏回执与新存档 | 启动至存档 |
| --- | ---: | --- | --- | ---: |
| 继承非输入桌面，第 1 轮 | 28260 | 私有桌面可见，无前台焦点 | 8/8，327,688 B | 约 12.31 秒 |
| 继承非输入桌面，第 2 轮 | 26184 | 同条件复测 | 8/8，327,692 B | 11.56 秒 |
| 继承非输入桌面，第 3 轮 | 2176 | 同条件复测 | 8/8，327,696 B | 11.64 秒 |
| 开局后最小化 | 21028 | 第 2 次回执后请求，5.72 秒确认最小化 | 8/8，327,668 B | 11.79 秒 |
| 开局后隐藏 | 27660 | 第 2 次回执后请求，5.91 秒确认不可见 | 8/8，327,696 B | 11.73 秒 |
| 开局后遮挡 | 29148 | 第 2 次回执后加等尺寸置顶窗口，不激活 | 8/8，327,689 B | 11.76 秒 |
| 显式新建 Win32 桌面 | 26260 | CreateDesktop + STARTUPINFO.lpDesktop，始终未切换到该桌面 | 8/8，327,694 B | 11.89 秒 |

所有轮次的生命序列相同。前三次为 `420.000`，第 4 次为 `380.250`，之后由游戏自身恢复至 `381.250`。六轮复测中，相邻回执的观察间隔为 0.926–1.136 秒，包含约 150 毫秒的采样粒度。每轮都先隔离旧日志，再验证新建的 `Logs\war3bg-*.txt` 和 `Save\Profile1\CustomSaves\bg\war3bg20261112`。这组实验覆盖非输入桌面启动，以及开局后的窗口状态变化。普通用户桌面发生前台失焦、会话锁屏、RDP 断开、无物理输出和休眠恢复还需分别实测。

### 《65.w3x》同版本对照

复用项目 m2_local_session.py、Lua53Host 与本地 KKWE/JAPI/Lua 启动链，在新目录锁定 32 个配置和依赖文件。无脚本改动的 Diagnostic 使用历史同 SHA 地图，包哈希为 `02f01b6f7ab9282ceb8838eb6a14eef4cf5f8e21886fa1cee028d69b5379a9df`。历史活动 JASS 为 `eb2e946a05da38ae055315016869c96ed1f3aba5347cea82f7361fc64a2a6fca`。受控副本沿用项目已有插桩，地图哈希为 `877726a107dc0a3ca26d1c26e6152fa8a25d3a410fbe0cb8c09218b9d852d2e8`。

| 条件 | 证据 | 判定 |
| --- | --- | --- |
| 历史可交互桌面，同 SHA Diagnostic | 隔离档案、难度和 H005 选人、Q 传送、击杀与复活、任务双奖励、E 等级门槛、正常退出录像 | 历史自然路线通过 |
| 历史非输入桌面，原有参数或把 `-opengl` 放在末尾 | 读到 DirectX 初始化弹窗 | 地图未进入 |
| 本轮绝对地图路径，`-opengl` 放在 `-kkwe` 前，保留 `-fastload` | 1.43 秒有窗口，约 2.89 秒写通用 `Campaigns.w3p`。14 秒内无目标图回执 | 跨过历史弹窗阶段，观察较短 |
| 本轮相对地图路径，同一 OpenGL 顺序，省略 `-fastload` | 0.62 秒有窗口，约 2.07 秒写通用文件。48 秒内未得到目标图回执 | 短预算未证实进图 |
| 同一套 KKWE 链启动小探针，PID 20216 | 11.67 秒内写出 8 次 JASS 回执和地图存档 | 启动链和 OpenGL 可共同加载普通地图 |
| 同一套 KKWE 链启动已有 65 受控副本，PID 24180 | 约 51.62 秒出现 `Q65\|m3_start\|1`，同时取得本地 `dz_w3_plugin.ini`。55 秒时由监督器收尾 | 游戏内入口通过，首条路线未完成 |
| 同受控副本复测，PID 24144 | 53.94 秒出现相同启动回执及本地档案。125 秒内无后续 W65 断言，自有进程由监督器结束 | 重复证实入口，受控路线未通过 |
| 未改脚本同 SHA Diagnostic，PID 26376 | 54.61 秒出现新本地档案。76 秒观察中无首条路线证据 | 地图本地初始化有证据，未验自然路线 |
| 独立计时诊断副本，PID 15444 | 50.81 秒读到本地玩家为 0、0 号槽为真实玩家且正在游戏、RPG 大厅标志为 0。88 秒观察中无 1 秒计时回执 | 测试入口前置成立，未证实地图时钟继续推进 |

独立计时诊断只在已有受控图的临时副本追加入口记录和一次性计时回执，未更改伤害、档案或任务规则。PJass 通过并从 MPQ 回读。地图 SHA-256 为 `ee71ce7ea493b25d3ca8b81bd6e0ef945f42652a762654ac20adafbf01dddee4`。入口回执为 `BG65|ENTRY|local=0;p0_user=1;p0_playing=1;rpg_lobby=0`，预期的 `BG65|TIMER|1` 未出现。根因仍需用可交互桌面、图形后端和相同诊断副本对照。

`Campaigns.w3p` 仅计为客户端通用活动。采样时刻相对首次观察到自有 PID。对照结果支持保留已验证参数顺序，尚未单独定位参数解析、地图加载、插件初始化各自耗时。

### 画面验证

PrintWindow 在《65.w3x》和同一启动链运行的已通过小探针上均返回成功，但捕获的两张 1920×1023 图像 SHA 相同，内容是窗口边框和白色客户区。显式 Win32 隔离桌面的 GDI 采样也只返回无效像素。游戏内事件和存档已证明实际运行，UI、贴图、模型、特效和输入命中仍需用独立的真实画面取证。

适合实测的画面方案是保持测试机或 Windows 来宾内游戏窗口可见，由虚拟机控制台或测试机端可用的捕获路径获取游戏帧。固定画质、分辨率、DPI、镜头、资源版本和采样时刻。对 HUD、模型和贴图取关键帧，动态特效取连续帧，控件命中用来宾真实输入及事件回执确认。捕获到空帧时保留失败记录。

## 二、方案排名

表格按《65.w3x》的完整验证排序。普通 JASS 日常冒烟优先采用已实测的本机方案。

| 排名与路线 | 适用性与实测 | 后台能力、覆盖面和代价 |
| --- | --- | --- |
| 1. 具备 3D 的 Windows VM | VMware、VirtualBox 有后台启动、来宾管理和截帧接口。本机未实测该游戏或插件 | 宿主可关闭控制台，来宾保留登录与渲染。可覆盖真实图形、输入和逻辑。OS 和 vGPU 增加资源开销，先测 32 位渲染和插件。不同前端对 3D 的支持需单独核对 |
| 2. 独立 Windows 实机或已有测试机 | 历史在可交互 Windows 桌面跑过同 SHA 图。另一台机器待实测 | 图形与输入留在测试机，适合模型、贴图、UI 与原有客户端兼容。维护小，有机器和远程访问成本 |
| 3. 本机独立进程 + Win32 非输入桌面 + OpenGL | 1.27 普通 JASS 已实测 7/7。65 已进初始化，计时推进未证实 | 无需宿主输入，普通地图适合测试计时、单位、任务及本地回执。成本低，可复用启动器。高质量截图、长期运行、多客户端待验 |
| 4. 当前用户桌面的失焦、隐藏、最小化与 Win+Tab | 本轮实测的是非输入桌面内的窗口状态。社区 1.27a 方案提示失焦可能使其流程暂停 | 实现简单，焦点、首次启动、模态框和物理输入仍需验证。普通虚拟桌面负责窗口归属，不能据此证明输入隔离 |
| 5. 独立 Windows 会话、RDP、计划任务 | RDS 提供独立交互窗口站。当前只观察到一个活动控制台 | 测试代理可驻留已登录会话。锁屏、断开 RDP 和重连分别测心跳与画面。无需把游戏移入服务的 Session 0 |
| 6. Windows Sandbox 或虚拟显示器 | Sandbox 支持 vGPU、目录映射和登录命令。当前未实测。现有虚拟显示器未切换为活动输出 | Sandbox 适合一次性验证，持续测试需重新准备依赖。虚拟显示器只解决输出，输入隔离仍由独立桌面或 VM 提供 |
| 7. 纯 Headless、服务、社区主机或替代引擎 | 未找到暴雪公开支持。GHost++ 是房间主机，Warsmash 是独立实现 | 可借用 LAN 编排和离线筛查。当前真实 1.27 引擎和 65 插件验收继续使用完整客户端 |

VM 试点优先验证 VMware 的 `vmrun start ... nogui`。VirtualBox 可用 `--type headless` 和 `controlvm ... screenshotpng` 对照，3D 依赖 Guest Additions 和选定前端。主机管理窗口关闭后，必须继续看到来宾游戏心跳与真实场景帧。Windows Sandbox 的 vGPU 属于独立可测试路线，未计入当前通过项。

## 三、实施与停止条件

1. **复用本机启动链做普通地图逻辑回归。** 以隔离工作目录、明确的客户端工作路径、短地图路径、固定参数顺序和唯一运行 ID 为输入。使用现有项目的 Python/Lua53Host 启动器。`m2_quick_test.py` 的目标图用例在隔离来宾验证计时后再接入，游戏内断言只加入临时副本。保留真实同步、单位指令、技能、任务和计时器，持续回传 `BOOT`、心跳、断言、`DONE` 和退出状态。
2. **自动收集与恢复。** 外部监督器按地图启动、无心跳、断言失败、崩溃、退出超时和图形取证失败分别报告。使用启动时持有的句柄，只清理本轮拥有的进程。按运行 ID 归档原始错误、日志、录像或画面、版本与哈希。启动超时按目标地图历史分布设置。采集以游戏内回执及系统诊断为主，无需常态读取游戏内存。
3. **补真实画面通道。** 在 3D Windows 来宾先开控制台验证小探针和同 SHA 65，再关闭主机窗口验证来宾仍运行且可截帧。来宾持续出现黑白空帧、掉档或不能启动时，停止该 VM 配置的扩展，转独立实机。视觉场景用实际摄像机、分辨率、渲染内容和输入结果取证。
4. **通过门槛。** 用同版本、地图、插件和档案起点做至少 3 轮连续测试，逐轮验证目标地图心跳、真实伤害、任务 1 双奖励、E 门槛、回执与退出。对照历史或当前交互式结果，补一轮无跳时钟、无直接改结果的自然路线和真实画面。满足门槛后扩大用例。正式 L1 仍需按原构建规则生成，并用对应成品复跑。多人、KK 平台和权威存档各在实际目标环境验收。

## 四、速度与资源

| 指标 | 结果 | 口径 |
| --- | --- | --- |
| 小探针启动到新存档 | 实测 11.56–12.31 秒 | 包含地图加载和 8 秒游戏计时，无编辑器操作和宿主输入 |
| 六轮复测客户端资源 | 实测累计 CPU 时间 0.81–1.83 秒，峰值工作集 141.76–142.36 MiB | CPU 为内核态与用户态累计，未测 GPU、显存或宿主总资源 |
| 《绽于深渊的少女》历史自动测试 | 历史实测复用 13.33 秒，含构建到清理 19.63 秒 | 受控冒烟，内容和计时范围与本轮不同 |
| 《65.w3x》墙钟和人工节省 | 目标图本地初始化实测约 51–55 秒。完整流程净节省未测 | 去掉编辑器点选、前台等待与重复采集可降低操作成本。VM 冷启动、同步、截图另计。净节省需同路线成对计时 |

下一轮记录启动到进图、断言完成、退出收尾、整轮墙钟、人工输入占用、CPU、工作集和 GPU。以同场景 3 组以上的中位数和失败率比较前台与后台，避免把脚本压缩测试时间计成环境节省。

## 五、证据与来源

- 项目历史证据位于 E:\RPG\绽于深渊的少女\策划方案\codexwork。见 `docs\war3整图重建_65_v1\下一轮执行与验收.md`、`M2本地实机验证.md`，以及 `logs\war3-rebuild-65-v1\m2-local` 的 `session-01\outcome.json`、`next-20261112-modal\startup-observation.json` 和 `next-20261112-opengl\startup-observation.json`。通用工具和历史计时见游戏项目 `codexwork\moehero-map\docs\自动测试.md`。
- 本轮实验记录位于 E:\RPG\长任务\codexwork\temp\war3-background-20261112-a01。依次为 `evidence.json`、`map-evidence.json`、`state-evidence.json`、`diagnostic65-evidence.json`、`diagnostic65-followup-evidence.json`、`diagnostic65-bridge-evidence.json` 、`diagnostic65-long-evidence.json` 和 `diagnostic65-timing-evidence.json`。复测证据 SHA-256 为 `a6741c8d359038d93773052ca5d7ac35fd007c822fa5a3e38fad7f21102ba4e7`。
- 客户端 `War3.exe` SHA-256 为 `6d88f9de8d085ea1e38d652c2d2a2e1fe9ecb661a13c9653b67a7bcaea10911e`，`Game.dll` 为 `e04d1716603c075eb0c8e1e21cf1093a664adc5249efab396bfa08d7b09d0c3a`。小探针地图 SHA-256 为 `96b526a4a434db91c2d08a177cba465f687c4b3d13234f77b1c630f090205314`，活动 JASS 为 `3abdde020d04e055734a2db9235bebef90926ba316fdf7bb325c1f03d6121cb3`。
- 1.27a 版本和特性。[暴雪公告存档](https://www.wowhead.com/blue-tracker/topic/warcraft-iii-gets-patched-20062996) · [补丁版本](https://liquipedia.net/warcraft/Patch_1.27a)
- 经典版参数顺序与真实 LAN 自动化案例。[Hive Workshop](https://www.hiveworkshop.com/threads/how-to-fix-loadfile-not-loading-the-map-main-menu-instead-warcraft-3-classic.351593/) · [wc3-ai-autotest](https://github.com/kingslayer15/wc3-ai-autotest) · [JASS PreloadGenEnd](https://wc3jass.com/jassdoc.php?class=functions&query=PreloadGenEnd)
- Win32 桌面、会话和服务的交互能力。[窗口站](https://learn.microsoft.com/en-us/windows/win32/winstation/window-stations) · [输入桌面](https://learn.microsoft.com/en-us/windows/desktop/winstation/desktops) · [STARTUPINFOW](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/ns-processthreadsapi-startupinfow) · [Win+Tab 窗口管理](https://learn.microsoft.com/en-us/windows/desktop/api/shobjidl_core/nn-shobjidl_core-ivirtualdesktopmanager) · [交互服务](https://learn.microsoft.com/en-us/windows/win32/services/interactive-services) · [RDS 会话状态](https://learn.microsoft.com/en-us/troubleshoot/windows-server/remote/troubleshoot-unexpected-rds-session-locks-or-disconnections)
- 图形设备与捕获。[D3D9 创建设备](https://learn.microsoft.com/en-us/windows/win32/api/d3d9/nf-d3d9-idirect3d9-createdevice) · [IddCx](https://learn.microsoft.com/en-us/windows-hardware/drivers/display/indirect-display-driver-model-overview) · [PrintWindow](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-printwindow) · [DXGI Desktop Duplication](https://learn.microsoft.com/en-us/windows-hardware/drivers/display/desktop-duplication-api)
- VM 与沙盒。[VMware Workstation Pro 17 指南](https://techdocs2-prod.adobecqms.net/content/dam/broadcom/techdocs/us/en/pdf/vmware/desktop-hypervisors/workstation/vmware-workstation-pro-17-0.pdf) · [VBoxManage 7.1](https://docs.oracle.com/en/virtualization/virtualbox/7.1/user/vboxmanage.html) · [VirtualBox Guest Additions](https://docs.oracle.com/en/virtualization/virtualbox/7.1/user/guestadditions.html) · [Windows Sandbox 配置](https://learn.microsoft.com/en-us/windows/security/threat-protection/windows-sandbox/windows-sandbox-configure-using-wsb-file)
- 第三方主持与独立引擎。[GHost++](https://github.com/ghostBot/ghostplusplus) · [WarsmashModEngine](https://github.com/Retera/WarsmashModEngine)

