# 《65.w3x》前台对照与后台验收

2026-11-13 JST。Windows 11 build 22631，控制台会话 1，Warcraft III 1.27.0.52240，KKWE/JAPI，默认使用 `-window -opengl`。每轮从独立目录冷启动，读档不参与验收。E13 短时使用当前 `Default`，其他对照运行在 `WinSta0` 的私有桌面。

## 验收结果

| 项目 | 实测结果 |
| --- | --- |
| 启动、PID、清理 | 启动器核对自有 Job、宿主和游戏 PID。正常菜单退出及独立超时回收均有回执。 |
| 冻结候选的原生难度 | E12 在私有桌面用 `Space` 进入、`Tab → Enter` 选「困难」。原生游戏截图显示广播。 |
| 冻结候选的连续运行 | E12 共 605 条心跳，第 2 至 605 条连续 604.258 秒。`F10 → E → X → X` 后游戏、宿主自然退出，均为 0。 |
| 真实英雄选择 | E13 在当前桌面对同一诊断图真实点击难度、双击奥菲斯。新英雄归玩家 0，金币 1000，任务 1。E13 在授权窗口到期后回收，连续心跳 41.842 秒。 |
| 私有桌面完整路线 | 未通过。原生英雄选择仍停在预选或重新预选。未走完村口 Q、灰狼战斗、选人后连续 60 秒和正常退出的同局链路。 |
| 用户操作共存 | E07 与 E10 分别观测到 21、10 次会话输入时间更新，均无游戏抢占前台。E12 耐久期间没有输入更新。完整路线在人工操作叠加下的稳定性待验。 |

[冻结候选截图](../logs/war3-65-cold/E12-frozen-endurance/engine-frozen-difficulty.bmp) · [E12 监督器原始结果](../logs/war3-65-cold/E12-frozen-endurance/trial.json) · [E12 活动采样](../logs/war3-65-cold/E12-frozen-endurance/activity/result.json)

## 前台和后台的原生事件对照

E13、E14 使用同一诊断地图 SHA-256 `51d86a9532ba5f92f583a7f61762cdcd1a1985c241747baba6697e0655154c86`，保留原始难度按钮与原生选人条件。E13 用 Windows 桌面鼠标操作，在客户区 `(954,423)` 点击「困难」，在 `(761,495)` 双击奥菲斯。原生难度回执为 `source=dialog|index=2|value=5|drop=0.000|tech=1`。两次按下的地形坐标为 `(28332.039,9447.768)`，第二次悬停是 H005。原图在游戏时钟 `23.372` 两次选中同一中立 H005，`23.872` 时报告 `committed=1`。随后选中归玩家 0 的新 H005，出生坐标 `(29109.500,-30405.000)`。E13 的 Job 截止为 180 秒，结果为 `timeout_terminated`，无完整回放、战斗或正常菜单退出。 [原生输入对照 JSON](../logs/war3-65-cold/E13-default-control/native-input-comparison.json) · [正式选人回执](../logs/war3-65-cold/E13-default-control/game-output/Logs/route-hero-chosen.pld) · [E13 退出记录](../logs/war3-65-cold/E13-default-control/trial.json)

E14 给同一私有游戏窗口取得焦点，使用同一坐标，首次真实选中同一中立 H005。发送原生双击消息，两次按下相隔 211 毫秒，之后另试同步投递两次普通按下。JAPI 可见按下、客户区坐标及窗口已激活，地形坐标仍为 `(0,0)`、悬停单位为空。首次选中后原计时器在 0.5 游戏秒到期，`committed=0`。E15 将 E13 成功的困难客户区坐标用于同步鼠标投递，窗口处理完成后无困难回执。随后同一局用 `Tab → Enter` 取得原生回执。这补上了 E03 未校准实际成功鼠标坐标的缺口。 [E14 首次选中](../logs/war3-65-cold/E14-calibrated-private/game-output/Logs/route-selection-1.pld) · [E14 计时器](../logs/war3-65-cold/E14-calibrated-private/game-output/Logs/route-selection-expired-1.pld) · [E15 鼠标调用](../logs/war3-65-cold/E15-native-selection-variants/input-dialog-mouse-1-stdout.log) · [E15 监督器](../logs/war3-65-cold/E15-native-selection-variants/trial.json)

两种桌面的差异出现在窗口接收鼠标消息后、引擎生成有效的模态按钮与重复选择事件之前。目标窗口、真实脚本回调、H005 对象和 0.5 秒计时器均有对照，单独恢复窗口焦点、对齐坐标和间隔均不足以成功。私有桌面的 `GetCursorPos` 返回 Win32 错误 5，Windows 文档要求调用线程位于当前输入桌面。实测支持指针和命中状态差异，Warcraft 内部具体调用链仍未确认。 [Windows GetCursorPos](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getcursorpos)

## 后续排查

| 轮次 | 操作和证据 | 退出 |
| --- | --- | --- |
| E14 | 同坐标、焦点和双击时距。一次 H005 原生预选，连续 142.728 秒。 | 菜单正常，Job 空。 |
| E15 | 前台实测困难坐标的同步鼠标无回执，随后原生键盘成功。框选与 Ctrl＋点击受镜头漂移影响，连续 129.037 秒。 | 菜单正常，Job 空。 |
| E16 | 提前 Ctrl＋点击，原生截图和镜头样本显示仍偏离选人区。连续 120.639 秒。 | 下发菜单后自然退出，监督截止同时触发。本轮不计为明确的菜单通过。 |
| E17 | 独立诊断图将本地镜头固定在原选人区，未改选人条件。框选一度从 H005 切到 H037，再选回 H005。三个计时器均未确认。追加 Ctrl＋点击及校准空地框选无正式选人。连续 114.878 秒。 | 菜单正常，Job 空。 |
| E18 | 在同一独立诊断图上只去掉 `-opengl`。80 秒内地图未产出初始化回执，无任何游戏输入。未测到该渲染路径的选人。 | 自有 Job 超时回收。 |
| E19 | 回到 OpenGL 和同 E13 的图。难度框及选人阶段的 Windows UI Automation 原始树均返回成功，只有通用窗口和代理节点，均无 Invoke、SelectionItem，树未截断。 | 原生困难选择成功，菜单正常，Job 空。 |

E17 镜头诊断地图 SHA-256 `67b33538bae3f044df7fa4c4de0c7d441c28a44a6b3914366a28a7c54c0474f1`。镜头观察和局部稳定逻辑仅存在于隔离副本，若原生确认英雄，镜头诊断即停止。校验 3776 个成员，仅 `war3map.j` 改动，PJass 通过。用户输入桌面保持 `Default`。 [E16 原始结果](../logs/war3-65-cold/E16-early-control-click/trial.json) · [E17 镜头截图](../logs/war3-65-cold/E17-stable-roster/engine-stable-roster.bmp) · [E17 原始结果](../logs/war3-65-cold/E17-stable-roster/trial.json) · [E18 原始结果](../logs/war3-65-cold/E18-client-default-renderer/trial.json) · [镜头诊断图构建](../build/war3-65-cold/dialog-probe-stable-roster-01/changes.json) · [Blizzard 经典输入手册](https://classic.battle.net/war3/basics/specialcommands.shtml)

E19 两次观测均绑定本轮 Game PID、HWND 和私有桌面。树没有公开三个难度按钮或英雄名册，无法通过 UI Automation 调用这些原生控件。 [难度框 UIA](../logs/war3-65-cold/E19-private-accessibility/dialog-accessibility/observe-stdout.log) · [英雄名册 UIA](../logs/war3-65-cold/E19-private-accessibility/roster-accessibility/observe-stdout.log) · [E19 全程](../logs/war3-65-cold/E19-private-accessibility/trial.json) · [微软 UI Automation 控件模式](https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-controlpatternsoverview)

## 复现与余项

在 `E:\RPG\长任务` 使用本机 Python 3.13，为每次运行提供全新档案和证据路径。以下复现冻结候选的后台冷启动、原生困难、十分钟心跳及菜单退出。私有桌面保持非输入状态，`--activity` 仅对 `Default` 做被动采样。回执存于 `trial.json`、`game-output/Logs` 和 `activity/result.json`。脚本退出码 0 代表受监督的干净自然退出，是否通过难度、英雄、战斗及心跳分别读相应字段。

```powershell
$py = 'C:/Users/Administrator/AppData/Roaming/uv/python/cpython-3.13.18-windows-x86_64-none/python.exe'
$trial = 'codexwork/scripts/war3-65-cold/dialog_trial.py'
& $py -B $trial 'codexwork/logs/war3-65-cold/repro-frozen-run' 'codexwork/build/war3-65-cold/repro-frozen-profile' --stage --actions dialog-nav --hold 600 --limit 735 --activity --screenshot
```

当前控制台是唯一可用的输入会话。后续完整实测需要可独立收发真实鼠标输入的图形会话，或另行安排可覆盖战斗和退出的前台时段。先取 H005 出生、村口原生 Q 传送、击杀 `n03X` 且任务计数增加的同局证据，继续采集选人后连续心跳和正常菜单退出，再叠加用户实际操作做耐久对照。被动采样的输入时间变化无法区分人工和自动输入。 [原始地图运行细节与 E01–E12 证据](WarcraftIII_65_原生交互续测_20261113.md) · [Windows GetLastInputInfo](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getlastinputinfo)

本轮 E01–E19 串行实机的监督时间共 2803.060 秒。14 轮为无超时回执的自然退出，4 轮为 `timeout_terminated`，E16 自然退出与监督截止重叠，单列。每轮结束后进程清单均无残留。原图 SHA-256 为 `cc8fe6f073184751571db8f53cac0e78645523429b4ea0136f70c13dd023b346`，冻结候选为 `d21fb1e5c2d16ae7e09a05ce3874f31f9d85ed6065c97c9102a6d67a94de6c10`，实机前后核验一致。已归档输出并清理 E01–E19 创建的重复档案。 [最后进程快照](../logs/war3-65-cold/resume-final-e19-processes/result.json)

新增与修改集中在 `codexwork/scripts/war3-65-cold/`。本次对照新增 `accessibility_observe.py`，更新 `build_dialog_probe.py`、`dialog_trial.py`、`directed_confirm.py` 和 `run.py`，构建 `codexwork/build/war3-65-cold/dialog-probe-stable-roster-01/`。原始结果保存在 `codexwork/logs/war3-65-cold/E01-*` 至 `E19-*`，证据包含原始日志、游戏截图、回放、脚本和构建清单。
