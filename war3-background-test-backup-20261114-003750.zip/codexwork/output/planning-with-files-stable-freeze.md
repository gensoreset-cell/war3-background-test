# planning-with-files 稳定版冻结记录

2026-11-12，用户确认冻结当前已安装的 3.27.0 第五轮 Windows UTF-8 修复版。已安装文件与源码快照逐一核对，33/33 一致。

- [冻结源码快照](planning-with-files-3.27.0-round5-utf8.zip)
- ZIP SHA-256 为 `0ae79d58bb1e50d261f326485276231d745c62d62bc2282028eb003c27e877bc`。
- 最近一次完整 Skill 回归为 72 项通过、1 项因 Windows 符号链接权限跳过。[回归记录](../logs/z05-plan-integrity-skill-regression-verified.txt)
- Z05 项目写入保护保存在独立分支 test/pwf-z05-formal 的提交 3ac42ce，项目专项回归 8/8 通过。[最终修复报告](planning-with-files-z05-integrity-final.md)

停止常规升级。高级任务控制按项目需要启用。Skill 仅在发现可复现缺陷时修改。日常使用重点转向《绽于深渊的少女》的正式开发。

持续主动编程、多人联机与 KK 平台仍是待验证场景，稳定降低 Token 仍缺公平对照。Z05 项目写入锁的适用范围、断电和非本地文件系统的验证边界见最终修复报告。

## Stable Freeze

用户独立核验了 ZIP 的 SHA-256、33 个文件、压缩包完整性及文件路径，确认该快照可作为恢复与回滚基准。用户抽查了原生 Codex 事件入口和 PostCompact 缓存恢复代码。72 项通过、1 项跳过及安装文件一致性沿用此前本机回归与核对记录。

普通任务直接执行。复杂长任务使用持久计划和阶段验收。遇到需求变更或重复执行风险时按需启用高级任务控制。发现可复现的 Skill 缺陷时修复并运行回归。
