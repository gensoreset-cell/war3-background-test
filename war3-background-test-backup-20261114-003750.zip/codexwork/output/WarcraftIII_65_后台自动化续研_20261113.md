# 《65.w3x》后台自动化续研

2026-11-13 JST。Windows 11 build 22631，会话 1，Warcraft III 1.27.0.52240，OpenGL，本地 KKWE/JAPI。

## 结果与范围

沿用原有默认难度的独立诊断图已连续 3/3 完成无人值守冷启动、至少 60 秒连续心跳、游戏内聊天触发状态验证和菜单正常退出。另一个烟测衍生图的窗口关闭方式也已通过 3/3。冻结诊断图两次用定向 Space 越过加载确认，现有定向鼠标消息未能使首次难度界面继续运行。

正式地图、正式工程与游戏数值只读。冷启动每轮从空档案启动，读档恢复的历史完整结果仍为 0/3。此次未启动读档实验。

## 输入和环境

| 项目 | SHA-256 |
| --- | --- |
| 原图 `65.w3x` | `cc8fe6f073184751571db8f53cac0e78645523429b4ea0136f70c13dd023b346` |
| 冻结诊断图 `ab65.w3x` | `d21fb1e5c2d16ae7e09a05ce3874f31f9d85ed6065c97c9102a6d67a94de6c10` |
| 后台烟测衍生图 | `0dabb52059e6f40a6302b47770e780ca3ec298c69c3748fceea7542b0424bca5` |
| War3.exe | `6d88f9de8d085ea1e38d652c2d2a2e1fe9ecb661a13c9653b67a7bcaea10911e` |
| Game.dll | `e04d1716603c075eb0c8e1e21cf1093a664adc5249efab396bfa08d7b09d0c3a` |
| kkapi_local_plugin.dll | `346aa2fa320b7919d95e7cd56792858331f6c224c5459652e166f36c832c8ee3` |

32 项客户端、地图与插件输入按源清单逐项核验。游戏使用 `-loadfile Maps\ab65.w3x -window -opengl -kkwe <隔离档案> -fastload`。加载前核对进程并检查诊断档案输出为空。原执行线程在本轮期间也推进了同项研究。按实时进程状态安排游戏，保留其证据的来源与计数。

## 启动、PID 和回收

- 较早的两次探针在 `util.lua:37` 把字符串当 `fs.path` 调用 `file_path:string()`。其后的 14:59 JST 历史探针已经修复参数类型并验证 `timeout-stop`、持有子进程退出和宿主退出码 0。15:00 的后续试跑仅约 24 秒回执，之后没有退出证据，不能计为通过。 [历史探针](<../temp/w3-cold-a-reclaim-20261113-01/canary/result.json>) · [中断运行](<../temp/w3-cold-a-reclaim-20261113-01/A1/stdout.log>)
- 新 Lua 驱动用 `fs.path` 写入临时 PID 文件，原子发布后才输出 PID。监督器核对文本、stdout 和自己的 Job 成员。宿主在创建时进入独立 Job，只继承三条标准流。Lua 依靠其持有的进程句柄处理 `timeout-stop` 与 stdin EOF。监督器意外终止时，Windows 关闭最后一个 Job 句柄，回收自有进程树。 [Windows Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects) · [启动时 Job 列表](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute)
- 本轮无游戏探针验证了 EOF 时仍活跃的子进程被回收、宿主退出码 0、Job 无残留。独立的 Job 句柄关闭探针在 stdin 仍打开时关闭 Job，宿主与测试子进程均退出。 [EOF 回执](<../logs/war3-65-cold/launcher-eof/result.json>) · [Job 回执](<../logs/war3-65-cold/launcher-job-close/result.json>)
- `Default` 工作进程可创建、枚举和销毁自有隐藏窗口。新非输入桌面的隐藏窗口收到另一个同桌面线程投递的私有消息，输入桌面保持 `Default`。该桌面查询系统鼠标返回 Win32 5，未尝试改变 ACL。CIM 和 `tasklist` 被拒，实际进程核对改用 Toolhelp 只读快照及自有 Job 句柄。 [Default 探针](<../logs/war3-65-cold/desktop-default-verified/result.json>) · [非输入桌面探针](<../logs/war3-65-cold/desktop-private/result.json>)

## 原执行线程的同期实机

| 轮次 | 结果 |
| --- | --- |
| 前台 A1，冻结诊断图 | 确认加载并操作原生难度框，实际选中深渊。72 条心跳，第 2 至 72 条连续约 70 秒。第 42 和 57 条附近收到 `READY` 与 `MUTATED`。`F10 → E → X → X` 正常退出，游戏和宿主均为 0。无选人或战斗证据。 |
| 后台 B1 / B2 / B3 | 冻结候选无输入为 0 条。清空 W3I 自定义加载模型后为 1 条。再隐藏首次难度框并保留现有三秒默认选择后为 90 条，约 89 秒。三轮均超时回收。 |
| 后台 B4，烟测衍生图 | 68 条、连续 67 秒。默认难度 `easy=1`。定时调用既有诊断函数并写状态，第 68 条请求 `EndGame(false)`，游戏进程继续运行，监督器限时回收。 |
| 前台 A2，B4 同 SHA | 同样的 68 条心跳和状态回执。`EndGame(false)` 后窗口仍在，目标窗口收到 `Alt+F4` 后游戏与宿主自然退出 0。 |

前台状态来自游戏内聊天 `-r2ready` 和 `-r2mutate`，后台烟测用脚本调用同一函数，预期单位自定义值、生命、金币从 `313/313/1234` 变为 `999/140/567`。烟测覆盖游戏逻辑和回执，真实玩法交互仍需独立证明。 [阶段报告](<../temp/w3-cold-a-stage-20261113-01/evidence-package/WarcraftIII_65_Automation_Stage_20261113.md>) · [菜单交互记录](<../temp/w3-cold-a-stage-20261113-01/evidence-package/ui-observations.txt>)

## 本轮独立实机

| 轮次 | 候选 | 实测结果 |
| --- | --- | --- |
| B01 | 冻结诊断图 | `TIMER_ARMED` 约 28.79 秒。向唯一匹配 PID、窗口类 `Warcraft III` 的自有窗口投递 Space，30.45 秒读到第 1 条心跳。此轮专测确认，主动发出停止指令。整轮 30.558 秒，游戏 `timeout_terminated`、宿主 0、Job 空。 |
| B02 | 冻结诊断图 | 重现 Space 与第一条心跳。向原生难度界面投递校准位置的鼠标移动、按下和抬起，Win32 均接受投递。12 秒内无第 2 条心跳，也无难度或状态变化证据，监督器回收。整轮 50.786 秒。 |
| C01 | 烟测衍生图 | 53 条心跳，观察跨度 51.841 秒，已读到 READY/MUTATED。日志采集发生 `PermissionError(13)`，监督器提前回收。整轮 89.279 秒。旧实现未留堆栈，具体出错调用未证实。对 Windows 共享读和证据文件原子替换增加有限等待与重试，后续异常留堆栈。 |
| C02 | 烟测衍生图 | 68 条、连续 66.996 秒，默认难度和两份状态回执均通过。第 68 条调用 `EndGame(false)` 后等 5 秒，再向自有窗口定向发出 `WM_CLOSE`。游戏 `natural 0`，宿主 0，Job 空。整轮 103.924 秒。 |
| C03 | 同 SHA 烟测衍生图，全新档案 | 68 条、连续 66.835 秒，状态回执通过。`WM_CLOSE` 后游戏 `natural 0`，宿主 0，Job 空。整轮 103.288 秒。 |
| C04 | 同 SHA 烟测衍生图，全新档案 | 68 条、连续 66.973 秒，状态回执通过。`WM_CLOSE` 后游戏 `natural 0`，宿主 0，Job 空。整轮 103.455 秒。 |
| D01 | B3 同 SHA，加载模型和首次难度对话框对照 | 脚本未自动调用诊断状态函数。定向键盘消息实际触发 `-r2ready` 和 `-r2mutate`，分别在第 7、9 个 tick 记录预期状态。62 条、连续 61.570 秒。对仍在局内的窗口发出 `WM_CLOSE` 后进程仍运行，按期限安全回收。整轮 101.523 秒。 |
| D02 | B3 同 SHA，全新档案 | 定向聊天取得两项预期状态。61 条、连续 60.119 秒。向私有桌面上的同一自有窗口发送 `F10 → E → X → X`，游戏 `natural 0`、宿主 0、Job 空，全程 `Default` 为输入桌面。整轮 92.419 秒。 |
| D03 | 同 SHA，全新档案 | 两项聊天状态通过。62 条、连续 61.151 秒。定向菜单键后游戏 `natural 0`、宿主 0、Job 空。整轮 92.772 秒。 |
| D04 | 同 SHA，全新档案 | 两项聊天状态通过。61 条、连续 60.100 秒。定向菜单键后游戏 `natural 0`、宿主 0、Job 空。整轮 92.527 秒。 |

C02–C04 串行 3/3，单次监督耗时 103.3–103.9 秒，中位数 103.455 秒。每轮 `Default` 为输入桌面，未发送全局键鼠，也未切换桌面。脚本触发状态变化，窗口管理消息请求关闭应用。D01 证实后台键盘能实际调用地图的聊天触发器。对照也表明 `WM_CLOSE` 的结果依赖游戏所处阶段。 [D01 原始回执](<../logs/war3-65-cold/D01-directed-chat/game.json>)

原生菜单快捷键沿用前台 A1 实测序列。D02–D04 的诊断脚本保留 READY/MUTATED 聊天触发器，没有自动写状态、`EndGame` 计时或游戏进程退出脚本。三轮定向菜单消息后退出、宿主返回和无残留相互印证。单轮 92.4–92.8 秒，中位数 92.527 秒。私有桌面菜单画面没有直接取证。 [D02 原始回执](<../logs/war3-65-cold/D02-directed-menu/game.json>) · [D03 原始回执](<../logs/war3-65-cold/D03-directed-menu/game.json>) · [D04 原始回执](<../logs/war3-65-cold/D04-directed-menu/game.json>)

本线程独立启动 War3 10 次，监督墙钟合计 860.531 秒，约 14 分 21 秒。16:27 JST 最终进程快照无 War3、Lua53Host 或测试监督器。原图和三个相关候选的哈希与输入一致。同期原执行线程的 6 次单独计数。 [最终进程快照](<../logs/war3-65-cold/processes-final/result.json>)

本轮证据按独立目录保存，各轮 `game.json` 包含哈希、桌面快照、状态、耗时与收尾，`host-stdout.log` 保留 PID 和结束回执。 [B01](<../logs/war3-65-cold/B01-directed-space/game.json>) · [B02](<../logs/war3-65-cold/B02-directed-route/game.json>) · [C01](<../logs/war3-65-cold/C01-background-close/game.json>) · [C02](<../logs/war3-65-cold/C02-background-close/game.json>) · [C03](<../logs/war3-65-cold/C03-background-close/game.json>) · [C04](<../logs/war3-65-cold/C04-background-close/game.json>)

## 复现

以下在 `E:\RPG\长任务` 中运行。`$py` 为本机已验证的 Python 3.13。每条命令使用新的诊断目录和日志名。当前模式只操作当次创建的进程。后台模式用新建 Win32 非输入桌面，保持用户输入桌面。

```powershell
$py = 'C:/Users/Administrator/AppData/Roaming/uv/python/cpython-3.13.18-windows-x86_64-none/python.exe'
$run = 'codexwork/scripts/war3-65-cold/run.py'
& $py -B $run private-desktop codexwork/logs/war3-65-cold/repro-desktop
& $py -B $run stage codexwork/logs/war3-65-cold/repro-stage --profile codexwork/build/war3-65-cold/repro-profile
& $py -B $run background-confirm codexwork/logs/war3-65-cold/repro-confirm --profile codexwork/build/war3-65-cold/repro-profile
```

推荐的后台最小验收路线复用 B3 的诊断图。`stage-chat` 会校验该诊断图 SHA `e28435dc4cfb042b434f1606cbb01b88a03aa5b6016fb3e0565f20ba8fbbb760`。`background-menu` 会等待并验证聊天状态，达到连续 60 秒后发出定向菜单键。退出时同时检查游戏自然退出码、宿主退出码、Job 剩余成员、输入桌面和输入文件哈希。

```powershell
& $py -B $run stage-chat codexwork/logs/war3-65-cold/repro-menu-stage --profile codexwork/build/war3-65-cold/repro-menu-profile
& $py -B $run background-menu codexwork/logs/war3-65-cold/repro-menu --profile codexwork/build/war3-65-cold/repro-menu-profile
```

`background-confirm` 的通过只表示加载确认生效并安全回收。`stage-smoke` 复用原线程留在独立诊断目录的烟测地图并检查哈希。`background-close` 在完成心跳和游戏内 `EndGame(false)` 后，尝试向同一私有桌面的自有窗口发送 `WM_CLOSE`。`WM_CLOSE` 是请求应用关闭窗口，必须以进程退出和无残留确认是否生效。 [Microsoft WM_CLOSE](https://learn.microsoft.com/en-us/windows/win32/winmsg/wm-close)

```powershell
& $py -B $run stage-smoke codexwork/logs/war3-65-cold/repro-smoke-stage --profile codexwork/build/war3-65-cold/repro-smoke-profile
& $py -B $run background-close codexwork/logs/war3-65-cold/repro-smoke --profile codexwork/build/war3-65-cold/repro-smoke-profile
```

## 交付与边界

- 新脚本位于 `codexwork/scripts/war3-65-cold/`。`run.py` 是入口，`owned_process.py` 和 `managed.lua` 管理桌面、Job、PID、控制和收尾。`desktop_canary.py` 是无游戏桌面探针，`directed_confirm.py` 只向同一私有桌面的已核对 War3 窗口发送定向消息。`foreground.py` 的识别和输入守卫仅通过历史图像与语法检查，`game` 模式需要显式启用实验开关。前台游戏与菜单基线使用原执行线程 A1 的实测。
- 原始回执、游戏日志和已生成的回放保存在 `codexwork/logs/war3-65-cold/`。计划和两个可查阅的诊断档案位于 `codexwork/build/war3-65-cold/`。其余由本轮创建且已经收尾的重复客户端副本，在归档回执后清理。诊断图构建来源依赖原线程的隔离副本，报告记录了源码变更和哈希。
- `WarcraftIII_65_后台自动化续研证据_20261113.zip` 包含本轮日志、原始地图回执和回放、测试源代码及输入清单。同期前台 A1 和相关诊断构建说明在包内 `reference/`。地图与客户端仍从本机隔离副本读取。
- 已覆盖本机 KKWE/JAPI、OpenGL、固定版本和私有 Win32 桌面下的诊断回归。后台主动选择难度、英雄、战斗、任务、画面及跨机耐久尚未验收。下一项有区分力的实验是在获准的独立 Windows 图形环境使用冻结候选，验证真实难度选择和选人，并与当前后台菜单路线按相同状态取证。现有环境未确认有可用来宾或第二台测试机。
