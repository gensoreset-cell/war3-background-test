"""Verify cold-start runtime manifests without launching Warcraft III."""

import json
from pathlib import Path
import sys
import unittest


CODEXWORK = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODEXWORK / "scripts" / "war3-test"))

from war3_test_config import RUNTIME
from war3_test_runner import MAP_INPUT, parse_runtime_inputs


class RuntimeManifestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.baseline = json.loads((RUNTIME / "inputs.json").read_text(encoding="utf-8-sig"))

    def test_historical_baseline_and_canonical_map_name(self):
        manifest = parse_runtime_inputs(self.baseline)
        self.assertEqual(len(manifest), 32)
        self.assertIn(MAP_INPUT, manifest)
        alternate = [
            {**row, "path": "BIN/maps/AB65.W3X"} if row["path"] == MAP_INPUT else row
            for row in self.baseline
        ]
        self.assertEqual(parse_runtime_inputs(alternate), manifest)

    def test_cold_generated_locations_are_rejected(self):
        for path in (
            "bin/LoGs/old.pld",
            r"bin\Screenshots\old.tga",
            "bin/Replay/old.w3g",
            "bin/Errors/old.txt",
            "bin/Save/Profile1/old.w3z",
            "bin/TempReplay.w3g",
            "bin/dz_w3_plugin.ini",
        ):
            with self.subTest(path=path), self.assertRaisesRegex(RuntimeError, "must not seed"):
                parse_runtime_inputs(self.baseline + [{**self.baseline[0], "path": path}])

    def test_windows_aliases_and_duplicates_are_rejected(self):
        for path in (
            "bin/Logs./old.pld",
            "bin/Logs /old.pld",
            "bin/Logs:stream",
            "bin/../Logs/old.pld",
            "/bin/Logs/old.pld",
            "C:/bin/Logs/old.pld",
            "bin/COM1",
            "BIN/maps/AB65.W3X",
        ):
            with self.subTest(path=path), self.assertRaisesRegex(RuntimeError, "Invalid"):
                parse_runtime_inputs(self.baseline + [{**self.baseline[0], "path": path}])


if __name__ == "__main__":
    unittest.main()
