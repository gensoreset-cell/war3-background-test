# 《65.w3x》后台原生选人轮次

E12 的冻结图在后台选择原生困难，在第 2–605 个心跳间连续 604.258 秒，随后通过原生菜单退出。E14 在诊断图见到一次 H005 原生选择，原确认计时器到期 `committed=0`。E15–E19 的同步点击、镜头和选择方式、渲染器、UI Automation 对照均未确认 H005。E21 在当前桌面用真实鼠标双选同一中立 H005，游戏时钟两次都是 33.320，到 33.820 的同一个计时器为 `committed=1`。随后玩家 0 出生、原生 035/Q、灰狼与计数、选人后心跳均通过。E21 最后的退出确认超时。

原始对照包括 [E12 监督](../logs/war3-65-cold/E12-frozen-endurance/trial.json)、[E14–E19 对照](../output/WarcraftIII_65_前台对照与后台验收_20261113.md) 和 [E21 证据](../output/WarcraftIII_65_E21_前台原生路线_20261113.md)。

## E22 原样复跑 E14 的首次双选

- 预期复现首个缺项。窗口收到点击，首次中立选择成功，原计时窗口没有第二次选择。若取得两次同一单位的 `select` 和 `committed=1`，则需先检验改善是否可重复。
- 在新隔离档案只跑一次快速双选，调用同一套启动/输入代码。实际在 64.669 秒结束，原生困难确认。移动到首按 56 毫秒，客户端坐标 `(761,495)`，地形 `(0,0)`，单位为空。H005 第一次选择为同一中立单位 `1053692`，游戏时钟 2.500；原计时器 3.000 到期 `committed=0`。第二条窗口按下形态为 `WM_LBUTTONDBLCLK`，原始 JAPI 只记录一条普通 `left-down`。
- 原生退出 `["natural",0]`，宿主 0，无超时，Job 和游戏进程清空。证据 [监督与输入时间线](../logs/war3-65-cold/E22-private-hover-baseline/trial.json)、[原始回执](../logs/war3-65-cold/E22-private-hover-baseline/game-output/Logs)、[引擎截图](../logs/war3-65-cold/E22-private-hover-baseline/game-output/Screenshots)。

## E23 延长指针预热

- 假设游戏要等更多帧才能把定向移动转换为命中。只增加移动至首按 400 毫秒；预期出现非零地形和 H005 鼠标命中。若仍为 `(0,0)`、命中为空，额外预热无法恢复这条路径。
- 用相同地图、启动和两按间隔运行 56.246 秒。实际移动至首按 456 毫秒、两按间隔 211 毫秒。原生困难确认；移动和首按仍无命中且地形零，连首次 H005 选中都未出现。该变化回退为默认 0 毫秒。原生退出 `["natural",0]`，宿主 0，无超时，Job 和游戏进程清空。证据 [监督与输入时间线](../logs/war3-65-cold/E23-private-hover-400ms/trial.json)、[原始回执](../logs/war3-65-cold/E23-private-hover-400ms/game-output/Logs)、[引擎截图](../logs/war3-65-cold/E23-private-hover-400ms/game-output/Screenshots)。
- E22/E23 原图 SHA-256 `cc8fe6f073184751571db8f53cac0e78645523429b4ea0136f70c13dd023b346`，正式工程 3,779 文件（相对 POSIX 路径排序，每条为 UTF-8 路径 + NUL + 小写文件 SHA-256 + LF）汇总 `dce641c2b2bbf8c85b5f8a9860d9a58cdb20a834f0628843866e086453f6d432`，实机前后一致。两轮用户输入桌面前后均为 `Default`。
- 下一轮 E24 只把第二条从双击消息换成常规 `WM_LBUTTONDOWN`。如果早期同靶点出现两条普通按下、首次原生选中而仍缺第二次选中，排除窗口消息类型这一解释；如果连首次原生选择都缺失，则此轮只能比较按下和命中层。

## E24 两次普通按下

- 实测 55.648 秒。移动到首按 56 毫秒，两次普通按下相隔 212 毫秒，游戏收到两条 `left-down`，均为客户区 `(761,495)`、`active=1`、地形 `(0,0)`、命中单位为空。原生困难仍确认，未产生本轮的第一次 H005 选择。此轮确认多一条原生按下仍未让指针命中，无法单独判明第二选中分发。
- 原生退出 `["natural",0]`，宿主 0，无超时，Job 和游戏进程清空。证据 [监督与输入时间线](../logs/war3-65-cold/E24-private-two-down/trial.json) 和 [原始回执](../logs/war3-65-cold/E24-private-two-down/game-output/Logs)。
- 当前只有 session 1 的 `WinSta0\Default` 接收输入。RDP 停止且本机关闭入站，未找到现成 Windows 来宾。下一项 H005 输入实验在已有独立输入来宾内先用 `desktop_canary.py --expect-desktop Default --require-input` 核对真实光标。然后用同一诊断图先取得移动后真实 H005 命中、再在原时间窗内双选，按同计时器和单位报告；若仍缺第二次，优先调查真实鼠标命中到原生选择事件的分发。当前私有桌面作为可复用 CLI 的回归环境继续使用。

## E22–E24 复现

在 `E:\RPG\长任务` 运行。每次换一个从未使用的 `$runId`。E22 使用 `$hoverMs = 0`、`$second = @('--hero-double-message')`。E23 使用 `$hoverMs = 400` 且保持 `$second`。E24 使用 `$hoverMs = 0`、`$second = @()`。

```powershell
$py = 'C:/Users/Administrator/AppData/Roaming/uv/python/cpython-3.13.18-windows-x86_64-none/python.exe'
$runId = 'Private-repro-01'
$hoverMs = 0
$second = @('--hero-double-message')
$env:WAR3_65_HERO_HOVER_MS = "$hoverMs"
& $py -B codexwork/scripts/war3-65-cold-experiments/dialog_trial.py `
  "codexwork/logs/war3-65-cold/$runId" "codexwork/build/war3-65-cold/profile-$runId" `
  --stage --map codexwork/build/war3-65-cold/dialog-probe-route-selection-01/ab65.w3x `
  --sha256 51d86a9532ba5f92f583a7f61762cdcd1a1985c241747baba6697e0655154c86 `
  --actions dialog-nav --hero 761 495 --hero-action hero-double-select @second `
  --hero-second-delay-ms 100 --fast-hero --neutral-origin --neutral-client 761 495 `
  --private-focus --screenshot --activity --hold 12 --limit 100
Remove-Item Env:WAR3_65_HERO_HOVER_MS
```

监督器返回 0 代表自然退出且清理通过。玩法是否通过由原始回执另判。新的通用入口应在玩法失败时返回失败状态。

E22–E24 的原始日志、截图、回放、阶段清单已封存。宿主的命令审查拒绝递归清理这三份实验档案，路径 `codexwork/build/war3-65-cold/profile-E22-private-hover-baseline`、`profile-E23-private-hover-400ms` 和 `profile-E24-private-two-down` 暂留。已分别核对受管进程退出。
