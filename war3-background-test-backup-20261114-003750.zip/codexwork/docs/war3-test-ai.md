# Warcraft III 后台自动化测试操作手册

本入口用于从 `E:\RPG\长任务` 运行 Warcraft III 1.27.0.52240、KKWE/JAPI 隔离测试，或接手别人留下的失败运行。测试保留用户当前桌面的使用权。所有启动输入、诊断和输出留在本次隔离目录，玩法回执由真正的游戏事件产生。

涉及新的玩法改动时，从触发条件、输入、预期回执和失败路径推导场景。优先验证实际改动影响到的行为，再复跑共享触发器或运行依赖的相关场景。单个场景的成功结果仅覆盖它实际断言的步骤。

## 开始前

先读项目根 `AGENTS.md`，再查看 CLI 帮助。使用本机已核验的 Python，运行目录从仓库根定位。

```powershell
Set-Location -LiteralPath 'E:\RPG\长任务'
$war3Py = 'C:\Users\Administrator\AppData\Roaming\uv\python\cpython-3.13.18-windows-x86_64-none\python.exe'
$war3Cli = 'codexwork/scripts/war3-test/war3_test.py'
& $war3Py -B $war3Cli --help
& $war3Py -B $war3Cli env
& $war3Py -B $war3Cli list
```

实机前核对运行目录是否全新，确认地图和运行依赖的指纹，检查已有 Warcraft III、KKWE、编辑器和测试宿主进程。`env` 可加 `--canary-evidence-dir` 并指定新目录，留存私有桌面的无游戏探针。现有游戏进程由其所有者安排退出，复跑只回收本轮自己的进程。读历史证据时，先看原始 `.pld`、监督器 `trial.json` 和输入时间线，再看报告的归纳。

## 配置与运行

`--scenario` 接受内置场景名或场景 JSON 路径。内置场景在 `codexwork/config/war3-test/`。新场景从最接近的配置派生，保留场景中的 `version`、`name`、`map.path`、`map.sha256`、`timeout_seconds` 与有序的 `steps`。用 `validate` 预检场景，再用 `run` 执行并指定新证据目录。

更换地图时请一起提供 `--map` 和 `--sha256`，以核对已知指纹。地图需要实际产生场景所断言的回执。更换运行依赖集合时可通过 `--runtime` 指定带 `inputs.json` 和 `profile` 的基线，操作应留在隔离副本。测试只使用受监督的游戏窗口输入。其他地图的原生路线需要先配置该地图的坐标、回执和场景断言。

当前场景操作包括 `wait_receipt`、`assert_receipt`、`input`、`heartbeat`、`capture` 和 `wait_exit`。每步用唯一 `id`，可指定等待上限。通用回执读取测试地图实际写到本轮 `bin/Logs` 的 `.pld` 文件；基准心跳操作使用现有 `desktop-ab-HEARTBEAT-*.pld` 约定。对于其他图里的任务计数或技能结果，场景必须能观察到真实回执，隔离诊断适配可为原生事件加只读记录。工具不改地图归档。

下面演示为另一张地图指定输入。将示例路径换成实际的地图副本和为它编写的场景 JSON。`Get-FileHash` 在此次测试前固定当前地图字节。已有审核通过的 SHA-256 时，直接把该值赋给 `$war3MapSha`。

```powershell
$war3OtherMap = 'codexwork/build/war3-fixtures/another-map.w3x'
$war3OtherScenario = 'codexwork/config/war3-test/another-map-smoke.json'
$war3MapSha = (Get-FileHash -LiteralPath $war3OtherMap -Algorithm SHA256).Hash
& $war3Py -B $war3Cli validate --scenario $war3OtherScenario --map $war3OtherMap --sha256 $war3MapSha
if ($LASTEXITCODE -eq 0) {
    $war3OtherEvidence = 'codexwork/logs/war3-test/another-map-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
    & $war3Py -B $war3Cli run --scenario $war3OtherScenario --map $war3OtherMap --sha256 $war3MapSha --evidence-dir $war3OtherEvidence
}
```

### 冷启动、困难、心跳和自然退出

```powershell
$war3RunName = 'hard-smoke-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
$war3Evidence = "codexwork/logs/war3-test/$war3RunName"
& $war3Py -B $war3Cli validate --scenario native-hard-heartbeat
& $war3Py -B $war3Cli run --scenario native-hard-heartbeat --evidence-dir $war3Evidence
$war3Exit = $LASTEXITCODE
Get-Content -Raw -Encoding UTF8 -LiteralPath "$war3Evidence/result.json"
```

该场景检查原生困难回执、至少 10 秒连续心跳、原生游戏截图和自然菜单退出。按同一命令复跑时重算 `$war3RunName` 和 `$war3Evidence`。`native-h005-route` 用于整条 H005 路线的回归，当前宿主环境仍有选人缺口。运行后读实际的 `failed_step`，通过时逐条核对同局的完整路线。

`frozen-heartbeat` 使用 E12 冻结图，检查原生对话框处理后的心跳、游戏截图和自然退出。该夹具没有难度数值 `.pld`，机器判定覆盖心跳和退出。默认游戏依赖清单为 `codexwork/temp/w3-cold-a-reclaim-20261113-01/inputs.json` 与相邻的 `profile/`。也可用 `--runtime` 提供设备上等效且已核对的 1.27/KKWE/JAPI 启动依赖。1.0.4 起，清单拒绝 `bin` 下的旧日志、截图、回放、错误记录、存档和运行生成配置，所有玩法回执均须在本轮生成。

### CLI 退出码

| 退出码 | `status` | 含义 |
| --- | --- | --- |
| 0 | `passed` | 场景断言和清理已通过 |
| 10 | `assertion_failed` | 原始回执与断言不符或未达到断言条件 |
| 11 | `input_invalid` | 目标进程归属校验失败，或受控输入未能送达目标窗口 |
| 12 | `startup_failed` | 已进入启动流程，未得到所需的进程回执 |
| 13 | `timeout` | 运行或等待达到时限 |
| 14 | `environment_unavailable` | 当前环境不能安全运行本场景 |
| 15 | `execution_failed` | 执行失败，查看具体步骤和错误 |
| 16 | `cleanup_failed` | 本轮清理验证失败 |
| 17 | `invalid_config` | 场景配置或地图路径与指纹校验失败 |
| 18 | `input_no_effect` | 指定输入已投递，在步骤时限内仍缺少预期原生回执 |

## 怎样判断一次运行

1. 选定用户要求的场景和验收断言，保存本次实际命令。复跑一律用新的证据目录，CLI 会创建独立运行档案。结束后从证据目录取回原始日志和截图。
2. CLI 1.0.2 起，运行中的 `result.json` 有 `status=running` 和 `terminal=false`。等到 `terminal=true` 再验收。实机记录归档与清理结束后进入 `phase=finished`。终态核对 `status`、`failed_step`、`steps` 和清理结果，再查 `game-output/Logs` 下的原生 `.pld`。`config.json` 保留实际场景和启动参数，`result.json` 记录输入时间线 `actions` 和回执观察 `events`。干净退出要求 `game_exit=["natural",0]`、`host_exit=0`、无 `timeout_sent`、Job 中无本轮进程。
3. 未通过时，找出**第一条**缺少或与预期不符的回执。回执步骤的 `details.receipt_state` 标明 `observed`（已观察）、`mismatch`（已有回执与断言不符）或 `missing`（等待结束时仍无回执）。从 1.0.3 起，若断言确实依赖某次投递，可以设置 `on_missing: "input_no_effect"`，并用 `after_input` 指定先前的输入步骤 ID。逐项检查回执和输入，区分断言冲突、缺少输入效果、游戏超时、预检失败与脚本异常。
4. 为下一轮写出假设、可证伪条件和预期结果。只改一个主要变量，在新目录做短试，比较与基线的差异。将日志、截图、回执、退出状态和下一步写入 `codexwork/docs`。如果只是修正故意配置的断言，保留失败证据，并明确是哪一项测试参数恢复为场景默认值。

输入先核对当前轮地图、进程和窗口归属。鼠标回执用客户区坐标、地形坐标和真实命中单位一起判断。心跳依据连续序号及真实时间跨度。截图用于核对实际画面，验收以相关游戏回执为准。

### 断言演练和复跑

`native-hard-assertion-mismatch` 是诊断练习。保留原始失败目录，先从 `failed_step` 确定是哪条断言，再与同局游戏的原始回执逐字段比较。以下命令使用独立的配置和证据路径。

```powershell
$war3Tag = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$war3FailEvidence = "codexwork/logs/war3-test/hard-mismatch-$war3Tag"
& $war3Py -B $war3Cli run --scenario native-hard-assertion-mismatch --evidence-dir $war3FailEvidence
$war3FailureCode = $LASTEXITCODE
Get-Content -Raw -Encoding UTF8 -LiteralPath "$war3FailEvidence/result.json"
Get-Content -Raw -Encoding UTF8 -LiteralPath "$war3FailEvidence/game-output/Logs/dialog-chosen.pld"
```

确认退出码为 `10` 且当轮原生回执存在后，把 `codexwork/config/war3-test/native-hard-assertion-mismatch.json` 派生为 `codexwork/config/war3-test/hard-assertion-corrected-$war3Tag.json`。只更正由回执定位的 `contains` 字段，保留心跳、截图和菜单退出步骤。

```powershell
$war3Fixed = "codexwork/config/war3-test/hard-assertion-corrected-$war3Tag.json"
$war3FixedEvidence = "codexwork/logs/war3-test/hard-corrected-$war3Tag"
& $war3Py -B $war3Cli validate --scenario $war3Fixed
& $war3Py -B $war3Cli run --scenario $war3Fixed --evidence-dir $war3FixedEvidence
$war3FixedCode = $LASTEXITCODE
Get-Content -Raw -Encoding UTF8 -LiteralPath "$war3FixedEvidence/result.json"
```

### 超时回收演练

```powershell
$war3DeadlineEvidence = 'codexwork/logs/war3-test/deadline-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
& $war3Py -B $war3Cli run --scenario native-route-deadline --evidence-dir $war3DeadlineEvidence
$war3TimeoutCode = $LASTEXITCODE
Get-Content -Raw -Encoding UTF8 -LiteralPath "$war3DeadlineEvidence/result.json"
```

该场景在原生困难后等待 `route-hero-chosen.pld`，刻意省去选人输入。预期是 `timeout` 和退出码 `13`。核对最后一条已出现的游戏回执、触发截止的步骤以及受管进程回收记录。回收验证只查本轮拥有的 Job 与 PID。

## 《65.w3x》原生路线边界

本地图的完整后台路线要求同次冷启动获得困难按钮回执 `source=dialog|index=2|value=5`。原有 0.5 游戏秒内，两条 `mode=select` 必须指向同一中立 `H005` 句柄，并得到同一计时器的 `committed=1`。检查新 H005 的 `owner=0`，进入区域 `035` 后按原生 `Q`，确认 `n03X` 被 H005 击杀且任务 1 的计数增加，再核对选人后至少连续 60 秒心跳和自然退出。完整路线通过后从新隔离目录冷启动复测。影响持续运行的改动再验证至少 600 秒。读档结果另记。

比较选人窗口使用 `route-selection-*.pld` 中的 `tick` 与 `fraction`。E21 两次原生选择都是 33.320 游戏秒，计时器在 33.820 游戏秒报告 `committed=1`，而两条文件的壁钟写入时间相隔约 0.984 秒。后台无同一 H005 第二条 `select` 时，已送达的窗口消息只能说明输入传输到达。E12 有 604.258 秒连续心跳和自然退出，E21 有完整战斗流程及玩家英雄回执，证据属于各自运行。

- [E12 后台原始监督记录](../logs/war3-65-cold/E12-frozen-endurance/trial.json)
- [E14–E19 前台和后台对照](../output/WarcraftIII_65_前台对照与后台验收_20261113.md)
- [E21 前台原生路线](../output/WarcraftIII_65_E21_前台原生路线_20261113.md)
- [后台试验与接续记录](war3-65-background-runs.md)

独立输入链路复测需要一个已登录、可收发输入的 Windows 图形会话。当前宿主的输入桌面是 `WinSta0\Default`，私有桌面可在保持当前桌面可用时运行键盘场景。在独立来宾的终端检查输入桌面。确认 `pass=true` 和 `cursor_query_succeeded=true` 后，用同一诊断图和游戏原窗口实际坐标先短测 H005。历史 E21 客户区参考坐标为 `(760,495)`。

```powershell
& $war3Py -B 'codexwork/scripts/war3-65-cold/desktop_canary.py' --expect-desktop Default --require-input
```
