"""Send a bounded window message sequence to owned War3 on a private desktop."""

import argparse
import ctypes as c
from ctypes import wintypes as w
import json
import time

from owned_process import bind, bind_user, require


MOUSE_ACTIONS = ("easy", "dialog-mouse", "mouse-move", "hero-select", "hero-double-select", "hero-reselect",
                 "hero-reselect-empty", "hero-reselect-drag", "hero-reselect-shift", "hero-select-control",
                 "route-attack", "route-move", "minimap-click",
                 "camera-hover-center")
HERO_CLEAR_ACTIONS = ("hero-reselect-empty", "hero-reselect-drag")


class GuiThreadInfo(c.Structure):
    _fields_ = [("size", w.DWORD), ("flags", w.DWORD), ("active", w.HWND), ("focus", w.HWND),
                ("capture", w.HWND), ("menu_owner", w.HWND), ("move_size", w.HWND),
                ("caret", w.HWND), ("caret_rect", w.RECT)]


def desktop_name(handle):
    query = bind_user("GetUserObjectInformationW", w.BOOL, w.HANDLE, c.c_int,
                      c.c_void_p, w.DWORD, c.POINTER(w.DWORD))
    name = c.create_unicode_buffer(256)
    require(handle and query(handle, 2, name, c.sizeof(name), None), "Read desktop name")
    return name.value


def input_name():
    open_input = bind_user("OpenInputDesktop", w.HANDLE, w.DWORD, w.BOOL, w.DWORD)
    close = bind_user("CloseDesktop", w.BOOL, w.HANDLE)
    handle = require(open_input(0, False, 1), "OpenInputDesktop (read only)")
    try:
        return desktop_name(handle)
    finally:
        close(handle)


def war3_windows(pid):
    callback_type = c.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
    enum = bind_user("EnumWindows", w.BOOL, callback_type, w.LPARAM)
    owner_of = bind_user("GetWindowThreadProcessId", w.DWORD, w.HWND, c.POINTER(w.DWORD))
    class_of = bind_user("GetClassNameW", c.c_int, w.HWND, w.LPWSTR, c.c_int)
    visible = bind_user("IsWindowVisible", w.BOOL, w.HWND)
    matches = []

    @callback_type
    def collect(window, _):
        owner = w.DWORD()
        owner_of(window, c.byref(owner))
        if owner.value == pid:
            name = c.create_unicode_buffer(128)
            class_of(window, name, len(name))
            if name.value == "Warcraft III" and visible(window):
                matches.append(window)
        return True

    require(enum(collect, 0), "EnumWindows on private desktop")
    return matches


def input_snapshot(hwnd, pid):
    owner_of = bind_user("GetWindowThreadProcessId", w.DWORD, w.HWND, c.POINTER(w.DWORD))
    get_gui = bind_user("GetGUIThreadInfo", w.BOOL, w.DWORD, c.POINTER(GuiThreadInfo))
    get_cursor = bind_user("GetCursorPos", w.BOOL, c.POINTER(w.POINT))
    owner = w.DWORD()
    tid = require(owner_of(hwnd, c.byref(owner)), "GetWindowThreadProcessId")
    if owner.value != pid:
        raise RuntimeError("Owned window identity changed")
    result = {"window_thread_id": tid}
    cursor = w.POINT()
    c.set_last_error(0)
    result["cursor_query_ok"] = bool(get_cursor(c.byref(cursor)))
    if not result["cursor_query_ok"]:
        result["cursor_query_error"] = c.get_last_error()
    gui = GuiThreadInfo(size=c.sizeof(GuiThreadInfo))
    c.set_last_error(0)
    if get_gui(tid, c.byref(gui)):
        result["gui_thread"] = {name: getattr(gui, name) for name in ("flags", "active", "focus", "capture", "menu_owner")}
    else:
        result["gui_thread_error"] = c.get_last_error()
    return result


def key_events(*keys):
    return tuple(event for key, scan in keys for event in
                 ((0x100, key, 1 | (scan << 16)), (0x101, key, 0xC0000001 | (scan << 16))))


def focus_private_window(hwnd, pid, expected, info, current_id, thread_desktop, foreground):
    """Try restoring focus inside the private desktop only, using the target's GUI queue."""
    attach = bind_user("AttachThreadInput", w.BOOL, w.DWORD, w.DWORD, w.BOOL)
    peek = bind_user("PeekMessageW", w.BOOL, c.POINTER(w.MSG), w.HWND, w.UINT, w.UINT, w.UINT)
    set_focus = bind_user("SetFocus", w.HWND, w.HWND)
    local_tid = current_id()
    target_tid = info["input_state_before"]["window_thread_id"]
    if target_tid == local_tid or desktop_name(thread_desktop(target_tid)) != expected:
        raise RuntimeError("War3 GUI thread is not on the verified private desktop")
    # A read-only peek ensures the caller has a USER message queue before attaching.
    message = w.MSG()
    peek(c.byref(message), None, 0, 0, 0)
    if input_name() != info["input_before"] or war3_windows(pid) != [hwnd]:
        raise RuntimeError("Input desktop or owned War3 window changed")
    info["transport"] = "AttachThreadInput + SetFocus (private experiment)"
    c.set_last_error(0)
    info["attach_ok"] = bool(attach(local_tid, target_tid, True))
    if not info["attach_ok"]:
        info["attach_error"] = c.get_last_error()
        info["error"] = "Could not attach the two private desktop input queues"
        return info
    try:
        if (input_name() != info["input_before"] or war3_windows(pid) != [hwnd]
                or input_snapshot(hwnd, pid)["window_thread_id"] != target_tid):
            raise RuntimeError("Private War3 focus identity changed before SetFocus")
        c.set_last_error(0)
        prior_focus = set_focus(hwnd)
        info["set_focus_error"] = c.get_last_error() if not prior_focus else 0
        info["input_state_while_attached"] = input_snapshot(hwnd, pid)
    except (OSError, RuntimeError) as exc:
        info["error"] = str(exc)
    finally:
        c.set_last_error(0)
        info["detach_ok"] = bool(attach(local_tid, target_tid, False))
        if not info["detach_ok"]:
            info["detach_error"] = c.get_last_error()
            info["error"] = "AttachThreadInput detach failed; stop the isolated run"
    info["input_after"] = input_name()
    info["foreground_unchanged"] = foreground() == info["foreground_before"]
    if war3_windows(pid) == [hwnd]:
        info["input_state_after"] = input_snapshot(hwnd, pid)
    state = info.get("input_state_after", {}).get("gui_thread", {})
    info["private_focus_ok"] = (info["detach_ok"] and info["input_after"] == info["input_before"]
                                and info["foreground_unchanged"] and state.get("active") == hwnd
                                and state.get("focus") == hwnd)
    if not info["private_focus_ok"] and not info.get("error"):
        info["error"] = "Private War3 focus did not persist after detaching"
    return info


def direct(pid, expected, action, *, point=None, sync=False, double_message=False, clear_point=None,
           neutral_client=None, second_point=None, first_click_pause_ms=0):
    current_id = bind("GetCurrentThreadId", w.DWORD)
    thread_desktop = bind_user("GetThreadDesktop", w.HANDLE, w.DWORD)
    station = bind_user("GetProcessWindowStation", w.HANDLE)
    foreground = bind_user("GetForegroundWindow", w.HWND)
    post = bind_user("PostMessageW", w.BOOL, w.HWND, w.UINT, w.WPARAM, w.LPARAM)
    send = bind_user("SendMessageTimeoutW", w.LPARAM, w.HWND, w.UINT, w.WPARAM, w.LPARAM,
                     w.UINT, w.UINT, c.POINTER(c.c_size_t))
    info = {"pid": pid, "action": action, "input_before": input_name(), "foreground_before": foreground(),
            "thread_desktop": desktop_name(thread_desktop(current_id())),
            "station": desktop_name(station()), "posted": []}
    if (info["thread_desktop"] != expected or info["station"] != "WinSta0"
            or not expected.startswith("War3Cold-") or info["input_before"] == expected):
        raise RuntimeError("Private desktop identity check failed")
    matches = war3_windows(pid)
    if len(matches) != 1:
        info["error"] = f"Expected exactly one visible PID/class match, found {len(matches)}"
        return info
    hwnd = matches[0]
    info["hwnd"] = hwnd
    observe_input = (action.startswith("dialog-") or action in MOUSE_ACTIONS
                     or action in ("camera-neutral-origin", "camera-private-focus"))
    if observe_input:
        info["input_state_before"] = input_snapshot(hwnd, pid)
    window_rect = bind_user("GetWindowRect", w.BOOL, w.HWND, c.POINTER(w.RECT))
    client_rect = bind_user("GetClientRect", w.BOOL, w.HWND, c.POINTER(w.RECT))
    client_point = bind_user("ScreenToClient", w.BOOL, w.HWND, c.POINTER(w.POINT))
    rect, client = w.RECT(), w.RECT()
    require(window_rect(hwnd, c.byref(rect)), "GetWindowRect of owned War3")
    require(client_rect(hwnd, c.byref(client)), "GetClientRect of owned War3")
    info["window_rect"] = [rect.left, rect.top, rect.right, rect.bottom]
    info["window_size"] = [rect.right - rect.left, rect.bottom - rect.top]
    info["client_size"] = [client.right, client.bottom]
    if action == "camera-private-focus":
        return focus_private_window(hwnd, pid, expected, info, current_id, thread_desktop, foreground)
    if action == "camera-neutral-origin":
        to_screen = bind_user("ClientToScreen", w.BOOL, w.HWND, c.POINTER(w.POINT))
        set_position = bind_user("SetWindowPos", w.BOOL, w.HWND, w.HWND, c.c_int, c.c_int,
                                 c.c_int, c.c_int, w.UINT)
        origin = w.POINT()
        require(to_screen(hwnd, c.byref(origin)), "ClientToScreen before repositioning")
        info["client_origin_before"] = [origin.x, origin.y]
        fallback_x, fallback_y = neutral_client or (client.right // 2, client.bottom // 2)
        if not (0 < fallback_x < client.right and 0 < fallback_y < client.bottom):
            info["error"] = "The neutral client point must be within the game client"
            return info
        desired_origin = -fallback_x, -fallback_y
        info["requested_fallback_client"] = [fallback_x, fallback_y]
        x = rect.left + desired_origin[0] - origin.x
        y = rect.top + desired_origin[1] - origin.y
        info["requested_client_origin"] = list(desired_origin)
        info["requested_window_origin"] = [x, y]
        if input_name() != info["input_before"] or war3_windows(pid) != [hwnd]:
            raise RuntimeError("Input desktop or owned War3 window changed")
        flags = 0x0001 | 0x0004 | 0x0010 | 0x0200  # NOSIZE, NOZORDER, NOACTIVATE, NOOWNERZORDER.
        require(set_position(hwnd, None, x, y, 0, 0, flags), "SetWindowPos on the private owned game")
        after = w.RECT()
        require(window_rect(hwnd, c.byref(after)), "GetWindowRect after repositioning")
        observed = w.POINT()
        require(to_screen(hwnd, c.byref(observed)), "ClientToScreen after repositioning")
        info["window_rect_after"] = [after.left, after.top, after.right, after.bottom]
        info["client_origin_after"] = [observed.x, observed.y]
        info["input_after"] = input_name()
        info["foreground_unchanged"] = foreground() == info["foreground_before"]
        info["input_state_after"] = input_snapshot(hwnd, pid)
        info["transport"] = "SetWindowPos"
        info["window_move_ok"] = (info["input_after"] == info["input_before"] and info["foreground_unchanged"]
                                  and (observed.x, observed.y) == desired_origin
                                  and [after.right - after.left, after.bottom - after.top] == info["window_size"])
        if not info["window_move_ok"]:
            info["error"] = "The final private window position, size or desktop state differed"
        return info
    events = key_events((0x20, 0x39))
    if action == "close":
        events = ((0x0010, 0, 0),)  # WM_CLOSE requests the application close its own window.
    elif action == "menu":
        events = key_events((0x79, 0x44), (0x45, 0x12), (0x58, 0x2D), (0x58, 0x2D))
    elif action == "dialog-enter":
        events = key_events((0x0D, 0x1C))
    elif action == "dialog-space":
        events = key_events((0x20, 0x39))
    elif action == "dialog-tab":
        events = key_events((0x09, 0x0F))
    elif action == "dialog-nav":
        events = key_events((0x09, 0x0F), (0x0D, 0x1C))
    elif action == "dialog-hotkey":
        events = key_events((0x42, 0x30))  # B is the native accelerator in the diagnostic variant.
    elif action == "portal-q":
        events = key_events((0x51, 0x10))
    elif action == "hero-f1":
        events = key_events((0x70, 0x3B))
    elif action == "route-stop":
        events = key_events((0x53, 0x1F))
    elif action == "arrow-down":
        events = key_events((0x28, 0x150))
    elif action == "arrow-right":
        events = key_events((0x27, 0x14D))
    elif action == "arrow-up":
        events = key_events((0x26, 0x148))
    elif action == "arrow-left":
        events = key_events((0x25, 0x14B))
    elif action == "camera-recenter":
        events = key_events((0x20, 0x39))
    elif action == "game-screenshot":
        events = key_events((0x2C, 0x137))  # PrintScreen has the extended-key bit set.
    elif action == "game-screenshot-ctrl":
        ctrl_down, ctrl_up = key_events((0x11, 0x1D))
        events = (ctrl_down,) + key_events((0x2C, 0x137)) + (ctrl_up,)
    elif action in MOUSE_ACTIONS:
        if point is None:
            if action == "camera-hover-center":
                point = client.right // 2, client.bottom // 2
            elif action != "easy" or info["window_size"] != [1920, 1023]:
                info["error"] = "A client point is required for this mouse action"
                return info
            else:
                position = w.POINT(rect.left + 963, rect.top + 390)
                require(client_point(hwnd, c.byref(position)), "ScreenToClient of owned War3")
                point = position.x, position.y
        x, y = point
        if not (0 <= x < min(client.right, 0x8000) and 0 <= y < min(client.bottom, 0x8000)):
            info["error"] = "Mouse target is outside the game client"
            return info
        target = (y << 16) | x
        info["client_point"] = [x, y]
        move = ((0x200, 0, target),)
        click = ((0x201, 1, target), (0x202, 0, target))
        if action in ("mouse-move", "camera-hover-center"):
            events = move
        elif action == "hero-double-select":
            second_click = ((0x203, 1, target), click[1]) if double_message else click
            events = move + click + second_click
            if second_point is not None:
                second_x, second_y = second_point
                if not (0 <= second_x < min(client.right, 0x8000) and 0 <= second_y < min(client.bottom, 0x8000)):
                    info["error"] = "Second selection target is outside the game client"
                    return info
                info["second_client_point"] = [second_x, second_y]
                second_target = (second_y << 16) | second_x
                second_down = 0x203 if double_message else 0x201
                events = move + click + ((0x200, 0, second_target), (second_down, 1, second_target),
                                         (0x202, 0, second_target))
        elif action == "hero-reselect":
            events = move + click + key_events((0x1B, 0x01)) + click
        elif action == "hero-reselect-shift":
            shift_down, shift_up = key_events((0x10, 0x2A))
            toggle = ((0x201, 0x0005, target), (0x202, 0x0004, target))
            events = move + click + (shift_down,) + toggle + (shift_up,) + click
        elif action == "hero-select-control":
            control_down, control_up = key_events((0x11, 0x1D))
            group_select = ((0x201, 0x0009, target), (0x202, 0x0008, target))
            events = move + click + (control_down,) + group_select + (control_up,)
        elif action in HERO_CLEAR_ACTIONS:
            if clear_point is None:
                raise ValueError("A verified empty client point is required")
            clear_x, clear_y = clear_point
            if not (0 <= clear_x < min(client.right, 0x8000) and 0 <= clear_y < min(client.bottom, 0x8000)):
                info["error"] = "The empty point is outside the game client"
                return info
            if (clear_x, clear_y) == (x, y):
                info["error"] = "The empty point must differ from the target"
                return info
            clear = (clear_y << 16) | clear_x
            info["clear_client_point"] = [clear_x, clear_y]
            if action == "hero-reselect-drag":
                end_x, end_y = clear_x + 80, clear_y + 56
                if not (end_x < min(client.right, 0x8000) and end_y < min(client.bottom, 0x8000)):
                    info["error"] = "Empty-ground drag extends outside the game client"
                    return info
                middle = ((clear_y + 28) << 16) | (clear_x + 40)
                end = (end_y << 16) | end_x
                info["clear_drag_end"] = [end_x, end_y]
                clear_selection = ((0x200, 0, clear), (0x201, 1, clear), (0x200, 1, middle),
                                   (0x200, 1, end), (0x202, 0, end))
            else:
                clear_selection = ((0x200, 0, clear), (0x201, 1, clear), (0x202, 0, clear))
            events = move + click + clear_selection + move + click
        elif action == "route-attack":
            events = key_events((0x41, 0x1E)) + move + click
        elif action == "route-move":
            events = move + ((0x204, 2, target), (0x205, 0, target))
        else:
            events = move + click
    elif action in ("ready", "mutate"):
        enter = key_events((0x0D, 0x1C))
        text = "-r2" + action
        events = enter + tuple((0x102, ord(character), 1) for character in text) + enter
    info["transport"] = "SendMessageTimeoutW for mouse" if sync else "PostMessageW"
    began = time.monotonic()
    first_click_completed = False
    for message, wparam, lparam in events:
        if input_name() != info["input_before"] or war3_windows(pid) != [hwnd]:
            info["error"] = "Input desktop or owned War3 window changed"
            break
        reply = c.c_size_t()
        synchronous = sync and 0x200 <= message <= 0x205
        c.set_last_error(0)
        if synchronous:
            sent = bool(send(hwnd, message, wparam, lparam, 0x22, 800, c.byref(reply)))
        else:
            sent = bool(post(hwnd, message, wparam, lparam))
        info["posted"].append({"message": message, "virtual_key": wparam, "wparam": wparam,
                               "lparam": lparam, "ok": sent, "win32_error": c.get_last_error() if not sent else None,
                               "elapsed_seconds": round(time.monotonic() - began, 3)})
        if synchronous and sent:
            info["posted"][-1]["window_proc_result"] = reply.value
        if not sent:
            break
        if action in ("hero-double-select", "hero-reselect", "hero-reselect-shift", "hero-select-control") + HERO_CLEAR_ACTIONS:
            delay = 0.030 if second_point is not None or action == "hero-reselect-drag" else 0.055
            if message == 0x202 and not first_click_completed:
                first_click_completed = True
                delay += first_click_pause_ms / 1000
            time.sleep(delay)
        else:
            time.sleep(0.3 if action in ("menu", "dialog-nav") and message == 0x101 else 0.1)
    info["input_after"] = input_name()
    info["foreground_unchanged"] = foreground() == info["foreground_before"]
    if observe_input:
        if war3_windows(pid) == [hwnd]:
            info["input_state_after"] = input_snapshot(hwnd, pid)
    return info


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pid", type=int)
    parser.add_argument("desktop")
    parser.add_argument("--action", choices=("confirm", "ready", "mutate", "close", "menu", "dialog-enter",
                                             "dialog-space", "dialog-tab", "dialog-nav", "dialog-hotkey",
                                             "hero-f1", "portal-q", "route-stop", "arrow-down", "arrow-right",
                                             "arrow-up", "arrow-left",
                                             "camera-recenter", "camera-neutral-origin", "camera-private-focus", "game-screenshot",
                                             "game-screenshot-ctrl") + MOUSE_ACTIONS,
                        default="confirm")
    parser.add_argument("--point", nargs=2, type=int, metavar=("X", "Y"), help="Client coordinates for a mouse action")
    parser.add_argument("--sync", action="store_true", help="Use bounded synchronous delivery for a mouse action")
    parser.add_argument("--double-message", action="store_true", help="Use WM_LBUTTONDBLCLK for the second hero press")
    parser.add_argument("--clear-point", nargs=2, type=int, metavar=("X", "Y"),
                        help="Verified empty client point to clear selection between hero clicks")
    parser.add_argument("--neutral-client", nargs=2, type=int, metavar=("X", "Y"),
                        help="Fallback client coordinates after the guarded private window move")
    parser.add_argument("--second-point", nargs=2, type=int, metavar=("X", "Y"),
                        help="Client coordinates for move and second click during hero-double-select")
    parser.add_argument("--second-delay-ms", "--first-click-pause-ms", dest="first_click_pause_ms",
                        type=int, choices=range(0, 301), metavar="0..300", default=0,
                        help="Extra pause after the first left-button release in hero-double-select")
    args = parser.parse_args()
    if (args.point is not None or args.sync) and args.action not in MOUSE_ACTIONS:
        parser.error("--point and --sync apply only to a mouse action")
    if args.action in MOUSE_ACTIONS and args.action not in ("easy", "camera-hover-center") and args.point is None:
        parser.error(f"{args.action} requires --point X Y")
    if args.double_message and args.action != "hero-double-select":
        parser.error("--double-message applies only to hero-double-select")
    if (args.clear_point is not None) != (args.action in HERO_CLEAR_ACTIONS):
        parser.error("Empty-ground reselection requires --clear-point X Y")
    if args.neutral_client is not None and args.action != "camera-neutral-origin":
        parser.error("--neutral-client applies only to camera-neutral-origin")
    if args.second_point is not None and args.action != "hero-double-select":
        parser.error("--second-point applies only to hero-double-select")
    if args.first_click_pause_ms and args.action not in ("hero-double-select",) + HERO_CLEAR_ACTIONS:
        parser.error("--second-delay-ms applies only to double selection or empty-ground reselection")
    try:
        info = direct(args.pid, args.desktop, args.action, point=args.point, sync=args.sync,
                      double_message=args.double_message, clear_point=args.clear_point,
                      neutral_client=args.neutral_client, second_point=args.second_point,
                      first_click_pause_ms=args.first_click_pause_ms)
    except Exception as exc:
        info = {"pid": args.pid, "error": repr(exc), "posted": []}
    print(json.dumps(info), flush=True)
    posted = info["posted"] and all(row["ok"] for row in info["posted"])
    return 0 if not info.get("error") and (posted or info.get("window_move_ok") or info.get("private_focus_ok")) else 2


if __name__ == "__main__":
    raise SystemExit(main())
