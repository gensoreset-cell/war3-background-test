"""Passively count session input updates without collecting input or window content."""

import argparse
import ctypes as c
from ctypes import wintypes as w
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time

from directed_confirm import desktop_name, input_name
from owned_process import bind, bind_user, require


RUNS = Path(__file__).resolve().parents[2] / "logs/war3-65-cold"


class LastInput(c.Structure):
    _fields_ = [("size", w.UINT), ("tick", w.DWORD)]


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_new(path, data):
    with path.open("x", encoding="utf-8") as file:
        json.dump(data, file, indent=2)
        file.write("\n")


def session_id(pid):
    get_session = bind("ProcessIdToSessionId", w.BOOL, w.DWORD, c.POINTER(w.DWORD))
    session = w.DWORD()
    require(get_session(pid, c.byref(session)), "ProcessIdToSessionId")
    return session.value


def console_identity():
    thread_id = bind("GetCurrentThreadId", w.DWORD)
    console_session = bind("WTSGetActiveConsoleSessionId", w.DWORD)
    get_thread_desktop = bind_user("GetThreadDesktop", w.HANDLE, w.DWORD)
    get_station = bind_user("GetProcessWindowStation", w.HANDLE)
    info = {"station": desktop_name(get_station()), "desktop": desktop_name(get_thread_desktop(thread_id())),
            "input_desktop": input_name(), "session_id": session_id(os.getpid())}
    if (info["station"] != "WinSta0" or info["desktop"] != "Default" or info["input_desktop"] != "Default"
            or info["session_id"] != console_session()):
        raise RuntimeError("The worker is not on the active console's Default input desktop")
    return info


def monitor(args, output, report):
    if args.pid_file.read_text(encoding="ascii").strip() != str(args.pid):
        raise RuntimeError("The provided PID does not match the owned game receipt")
    report.update(console_identity())
    report["target_identity"] = "owned PID receipt; supervisor checks private Job membership"
    get_last_input = bind_user("GetLastInputInfo", w.BOOL, c.POINTER(LastInput))
    get_foreground = bind_user("GetForegroundWindow", w.HWND)
    owner_of = bind_user("GetWindowThreadProcessId", w.DWORD, w.HWND, c.POINTER(w.DWORD))
    active_console = bind("WTSGetActiveConsoleSessionId", w.DWORD)
    previous_tick = None
    start = time.monotonic()
    report["windows_seconds"] = 10
    report["activity_updates_by_window"] = []
    while True:
        elapsed = time.monotonic() - start
        if report["samples"] and args.stop_file and args.stop_file.exists():
            report["stop_reason"] = "sentinel"
            break
        if elapsed >= args.duration:
            report["stop_reason"] = "duration"
            break
        if input_name() != report["input_desktop"] or active_console() != report["session_id"]:
            report["input_desktop_stable"] = False
            raise RuntimeError("The active console or input desktop changed during observation")
        last_input = LastInput(size=c.sizeof(LastInput))
        require(get_last_input(c.byref(last_input)), "GetLastInputInfo")
        bucket = int(elapsed // report["windows_seconds"])
        while len(report["activity_updates_by_window"]) <= bucket:
            report["activity_updates_by_window"].append(0)
        if previous_tick is not None and last_input.tick != previous_tick:
            report["input_updates"] += 1
            report["activity_updates_by_window"][bucket] += 1
        previous_tick = last_input.tick
        hwnd = get_foreground()
        if hwnd:
            owner = w.DWORD()
            if not owner_of(hwnd, c.byref(owner)):
                if get_foreground() == hwnd:
                    require(False, "GetWindowThreadProcessId for console foreground")
                report["foreground_transition_samples"] += 1
            elif owner.value == args.pid:
                report["game_foreground_samples"] += 1
                raise RuntimeError("The test game became foreground on the user's input desktop")
        else:
            report["no_foreground_samples"] += 1
        report["samples"] += 1
        if report["samples"] == 1:
            write_new(output / "ready.json", {"utc": utc(), "session_id": report["session_id"],
                                               "input_desktop": report["input_desktop"]})
        time.sleep(0.25)
    report["elapsed_seconds"] = round(time.monotonic() - start, 3)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--pid-file", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--stop-file", type=Path)
    parser.add_argument("--duration", type=float, default=120)
    args = parser.parse_args()
    if args.pid <= 0 or not 1 <= args.duration <= 43200:
        parser.error("PID must be positive and duration must be between 1 and 43200 seconds")
    output = args.output_dir.resolve()
    args.pid_file = args.pid_file.resolve()
    run = args.pid_file.parent
    if (not run.is_relative_to(RUNS.resolve()) or not output.is_relative_to(run) or run == output
            or args.pid_file.name != "owned-pid.txt"):
        parser.error("The PID receipt and output subdirectory must belong to a single test run")
    if args.stop_file:
        args.stop_file = args.stop_file.resolve()
        if not args.stop_file.is_relative_to(run):
            parser.error("Stop sentinel must belong to the same test run")
    output.mkdir(exist_ok=True)
    if (output / "result.json").exists() or (output / "ready.json").exists():
        parser.error("Use a fresh output subdirectory")
    report = {"pid": args.pid, "started_utc": utc(), "samples": 0, "input_updates": 0,
              "no_foreground_samples": 0, "foreground_transition_samples": 0,
              "game_foreground_samples": 0, "input_desktop_stable": True}
    try:
        monitor(args, output, report)
        report["passed"] = report["samples"] > 0
    except (OSError, RuntimeError) as exc:
        report.update(passed=False, error=str(exc))
    report.update(finished_utc=utc(), input_observed=report["input_updates"] > 0)
    write_new(output / "result.json", report)
    print(json.dumps(report), flush=True)
    return 0 if report["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
