"""Build a byte-verified isolated map with native dialog event receipts."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys


WORK = Path(__file__).resolve().parents[2]
SOURCE = WORK / 'temp/w3-cold-a-reclaim-20261113-01/profile/bin/Maps/ab65.w3x'
SOURCE_SHA = 'd21fb1e5c2d16ae7e09a05ce3874f31f9d85ed6065c97c9102a6d67a94de6c10'
SCRIPT_SHA = '25cd9f0fba0d6a96ba562ce8d192a1073b690e5bea0204a023a1985be737aabd'
MAP_PROJECT = Path('E:/RPG/\u7efd\u4e8e\u6df1\u6e0a\u7684\u5c11\u5973')
TOOLS = MAP_PROJECT / 'codexwork/moehero-map'
COMPILER = MAP_PROJECT / '\u7b56\u5212\u65b9\u6848/codexwork/build/war3-rebuild-65-v1/m1-compiler/attempt-07/toolchain'
ADMIN = {'(attributes)', '(listfile)', '(signature)'}
CALLBACK = b'Trig_Nandu_______uFunc008Conditions'
OPEN_DIALOG = b'Trig_Nandu_______uActions'


LOGGER = b'''function AB65DialogEvidence takes string key, string value returns nothing
    call PreloadGenClear()
    call PreloadGenStart()
    call Preload("AB65|" + key + "|" + value)
    call PreloadGenEnd(key + ".pld")
endfunction

function AB65DialogChoice takes integer selected, integer value, real dropRate, integer techLevel returns nothing
    local string source = "dialog"
    if GetTriggerEventId() == EVENT_GAME_TIMER_EXPIRED then
        set source = "timer"
    endif
    call AB65DialogEvidence("dialog-chosen", "source=" + source + "|index=" + I2S(selected) + "|value=" + I2S(value) + "|drop=" + R2S(dropRate) + "|tech=" + I2S(techLevel))
endfunction

'''

MOUSE_GLOBALS = b'''    integer AB65MouseMoves = 0
    integer AB65MouseLeftDowns = 0
    integer AB65MouseRightDowns = 0
'''

MOUSE_LOGGER = b'''function AB65MouseEvidence takes string eventName, integer sequence returns nothing
    local unit hovered = DzGetUnitUnderMouse()
    local string rawcode = "none"
    local string active = "0"
    if hovered != null then
        set rawcode = YDWEId2S(GetUnitTypeId(hovered))
    endif
    if DzIsWindowActive() then
        set active = "1"
    endif
    call AB65DialogEvidence("route-mouse-" + eventName + "-" + I2S(sequence), "event=" + eventName + "|sequence=" + I2S(sequence) + "|unit=" + rawcode + "|client_x=" + I2S(DzGetMouseXRelative()) + "|client_y=" + I2S(DzGetMouseYRelative()) + "|terrain_x=" + R2S(DzGetMouseTerrainX()) + "|terrain_y=" + R2S(DzGetMouseTerrainY()) + "|frame=" + I2S(DzGetMouseFocus()) + "|active=" + active)
    set hovered = null
endfunction

function AB65MouseMove takes nothing returns nothing
    if GetLocalPlayer() == Player(0) and AB65MouseMoves < 32 then
        set AB65MouseMoves = AB65MouseMoves + 1
        call AB65MouseEvidence("move", AB65MouseMoves)
    endif
endfunction

function AB65MouseLeftDown takes nothing returns nothing
    if GetLocalPlayer() == Player(0) and AB65MouseLeftDowns < 16 then
        set AB65MouseLeftDowns = AB65MouseLeftDowns + 1
        call AB65MouseEvidence("left-down", AB65MouseLeftDowns)
    endif
endfunction

function AB65MouseRightDown takes nothing returns nothing
    if GetLocalPlayer() == Player(0) and AB65MouseRightDowns < 16 then
        set AB65MouseRightDowns = AB65MouseRightDowns + 1
        call AB65MouseEvidence("right-down", AB65MouseRightDowns)
    endif
endfunction

'''

ROUTE_STATE = b'''function AB65RouteState takes nothing returns nothing
    local unit hero = udg_Hero[1]
    if hero != null and ModuloInteger(AB65TickCount, 2) == 0 then
        call AB65DialogEvidence("route-state-" + I2S(AB65TickCount), "type=" + YDWEId2S(GetUnitTypeId(hero)) + "|x=" + R2S(GetUnitX(hero)) + "|y=" + R2S(GetUnitY(hero)) + "|hp=" + R2S(GetWidgetLife(hero)) + "|level=" + I2S(GetHeroLevel(hero)) + "|task=" + I2S(Quick65HeroTask()) + "|gray_wolves=" + I2S(Quick65Count("n03X")) + "|tick=" + I2S(AB65TickCount))
    endif
    set hero = null
endfunction

'''

CAMERA_GLOBALS = b'''    integer AB65CameraDeselects = 0
'''

CAMERA_LOGGER = b'''function AB65CameraEvidence takes string key returns nothing
    call AB65DialogEvidence(key, "target_x=" + R2S(GetCameraTargetPositionX()) + "|target_y=" + R2S(GetCameraTargetPositionY()) + "|eye_x=" + R2S(GetCameraEyePositionX()) + "|eye_y=" + R2S(GetCameraEyePositionY()) + "|distance=" + R2S(GetCameraField(CAMERA_FIELD_TARGET_DISTANCE)) + "|rotation=" + R2S(GetCameraField(CAMERA_FIELD_ROTATION)) + "|aoa=" + R2S(GetCameraField(CAMERA_FIELD_ANGLE_OF_ATTACK)) + "|tick=" + I2S(AB65TickCount))
endfunction

function AB65CameraDeselect takes nothing returns nothing
    if AB65CameraDeselects < 16 then
        set AB65CameraDeselects = AB65CameraDeselects + 1
        call AB65DialogEvidence("route-deselected-" + I2S(AB65CameraDeselects), "source=unit-deselected|type=" + YDWEId2S(GetUnitTypeId(GetTriggerUnit())) + "|tick=" + I2S(AB65TickCount))
        call AB65CameraEvidence("route-camera-deselected-" + I2S(AB65CameraDeselects))
    endif
endfunction

function AB65CameraSample takes nothing returns nothing
    if AB65TickCount <= 90 and (AB65TickCount <= 20 or ModuloInteger(AB65TickCount, 2) == 0) then
        call AB65CameraEvidence("route-camera-" + I2S(AB65TickCount))
    endif
endfunction

'''

SELECTION_GLOBALS = b'''    integer AB65SelectionEvents = 0
    integer AB65SelectionTimers = 0
    integer AB65SelectionArms = 0
'''

SELECTION_LOGGER = b'''function AB65SelectionTime takes nothing returns string
    return I2S(AB65TickCount) + "|fraction=" + R2S(TimerGetElapsed(AB65Timer))
endfunction

function AB65SelectedUnit takes unit picked returns string
    if picked == null then
        return "type=none"
    endif
    return "type=" + YDWEId2S(GetUnitTypeId(picked)) + "|id=" + I2S(GetHandleId(picked)) + "|owner=" + I2S(GetPlayerId(GetOwningPlayer(picked))) + "|x=" + R2S(GetUnitX(picked)) + "|y=" + R2S(GetUnitY(picked))
endfunction

function AB65SelectionEvent takes nothing returns nothing
    local string mode = "select"
    if AB65SelectionEvents < 80 then
        if GetTriggerEventId() == EVENT_PLAYER_UNIT_DESELECTED then
            set mode = "deselect"
        endif
        set AB65SelectionEvents = AB65SelectionEvents + 1
        call AB65DialogEvidence("route-selection-" + I2S(AB65SelectionEvents), "source=unit-selection|mode=" + mode + "|" + AB65SelectedUnit(GetTriggerUnit()) + "|tick=" + AB65SelectionTime())
    endif
endfunction

function AB65SelectionArm takes timer pending returns nothing
    if GetTriggerPlayer() == Player(0) and AB65SelectionArms < 40 then
        set AB65SelectionArms = AB65SelectionArms + 1
        call AB65DialogEvidence("route-selection-arm-" + I2S(AB65SelectionArms), "source=hero-selection|timer=" + I2S(GetHandleId(pending)) + "|" + AB65SelectedUnit(GetTriggerUnit()) + "|tick=" + AB65SelectionTime())
    endif
endfunction

function AB65SelectionExpire takes timer pending returns nothing
    local player target = LoadPlayerHandle(YDLOC, GetHandleId(pending), 0x48E3E75F)
    local string committed = "0"
    if target == Player(0) and AB65SelectionTimers < 40 then
        set AB65SelectionTimers = AB65SelectionTimers + 1
        if udg_Hero[1] != null then
            set committed = "1"
        endif
        call AB65DialogEvidence("route-selection-expired-" + I2S(AB65SelectionTimers), "source=hero-timer|timer=" + I2S(GetHandleId(pending)) + "|committed=" + committed + "|" + AB65SelectedUnit(LoadUnitHandle(YDHT, GetHandleId(target), 0xFE03121B)) + "|tick=" + AB65SelectionTime())
    endif
    set target = null
endfunction

'''


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def function_span(data, name):
    pattern = rb'(?m)^function ' + name + rb' takes[^\r\n]+\r?\n[\s\S]*?^endfunction\b'
    matches = list(re.finditer(pattern, data))
    if len(matches) != 1:
        raise RuntimeError(f'Expected exactly one function {name!r}, found {len(matches)}')
    return matches[0].span()


def native_dialog_patch(data, hotkeys, route_receipts=False, mouse_receipts=False, portal_receipts=False,
                        camera_receipts=False, selection_receipts=False, roster_camera=False):
    """Patch only anchored byte spans. The manifest can reconstruct the original bytes."""
    callback_begin, callback_end = function_span(data, CALLBACK)
    opening_begin, opening_end = function_span(data, OPEN_DIALOG)
    callback = data[callback_begin:callback_end]
    opening = data[opening_begin:opening_end]
    eol = b'\r\n' if b'\r\n' in opening else b'\n'
    edits = []

    def insert_after_line(section, offset, marker, text, description):
        if section.count(marker) != 1:
            raise RuntimeError(f'Ambiguous insertion marker: {marker!r}')
        line_end = section.index(eol, section.index(marker)) + len(eol)
        edits.append((offset + line_end, b'', text + eol, description))

    edits.append((callback_begin, b'', LOGGER.replace(b'\n', eol), 'Preload evidence functions'))
    if roster_camera:
        entry_start, entry_end = function_span(data, b'AB65Entry')
        entry = data[entry_start:entry_end]
        stabilizer = b'''function AB65HoldRosterCamera takes nothing returns nothing
    if udg_Hero[1] != null then
        call DestroyTimer(GetExpiredTimer())
    elseif GetLocalPlayer() == Player(0) then
        call PanCameraToTimed(28816.00, 9696.00, 0.00)
    endif
endfunction

'''
        edits.append((entry_start, b'', stabilizer.replace(b'\n', eol), 'Diagnostic local roster camera only'))
        insert_after_line(entry, entry_start, b'call AB65Log("TIMER_ARMED", "interval=1.000")',
                          b'    call TimerStart(CreateTimer(), 0.05, true, function AB65HoldRosterCamera)',
                          'Hold the local camera while original selection is still pending')
    global_key = re.search(rb'StringHash\("[^\r\n]+?"\), 0x7358DE1B,', callback)
    if global_key is None:
        raise RuntimeError('Cannot identify difficulty state key')
    global_hash = global_key.group().split(b', 0x7358DE1B,', 1)[0]
    insert_after_line(callback, callback_begin, b'0x7358DE1B, LoadInteger(YDLOC',
                      b'\tcall AB65DialogChoice(LoadInteger(YDLOC, GetHandleId(GetTriggeringTrigger()), 0x300B6E6B), '
                      b'LoadInteger(YDHT, ' + global_hash + b', 0x7358DE1B), '
                      b'LoadReal(YDHT, ' + global_hash + b', 0x998E4195), '
                      b'GetPlayerTechCount(Player(11), \'R001\', true))', 'Actual applied difficulty state')
    insert_after_line(opening, opening_begin, b'call TriggerAddCondition(ydl_trigger, Condition(function ' + CALLBACK + b'))',
                      b'\tcall AB65DialogEvidence("dialog-shown", "buttons=3|timer=3.00|native=1")',
                      'Original dialog displayed and callbacks registered')
    if hotkeys:
        for label, key in ((b'019', b'65'), (b'020', b'66'), (b'021', b'67')):
            old = b'"TRIGSTR_' + label + b'", 0))'
            if opening.count(old) != 1:
                raise RuntimeError(f'Unexpected native button: {old!r}')
            new = b'"TRIGSTR_' + label + b'", ' + key + b'))'
            edits.append((opening_begin + opening.index(old), old, new, 'Native dialog button hotkey'))

    if route_receipts:
        hero_begin, hero_end = function_span(data, b'Trig_ChooseHero_____________uActions')
        hero = data[hero_begin:hero_end]
        insert_after_line(hero, hero_begin, b'call TimerStart(ydl_timer, 0.50, false,',
                          eol.join((b'\t\t\tif GetTriggerPlayer() == Player(0) then',
                                    b'\t\t\t\tcall AB65DialogEvidence("route-hero-first", "source=selection|type=" + YDWEId2S(GetUnitTypeId(GetTriggerUnit())))',
                                    b'\t\t\tendif')),
                          'Read-only evidence after first native selection')
        insert_after_line(hero, hero_begin, b'\t\tcall TriggerExecute(ydl_trigger)' + eol + b'\telse',
                          eol.join((b'\t\tif GetTriggerPlayer() == Player(0) then',
                                    b'\t\t\tcall AB65DialogEvidence("route-hero-chosen", "source=selection|type=" + YDWEId2S(GetUnitTypeId(udg_Hero[1])) + "|level=" + I2S(GetHeroLevel(udg_Hero[1])) + "|task=" + I2S(LoadInteger(YDHT, GetHandleId(Player(0)), 0xDE511409)) + "|gold=" + I2S(GetPlayerState(Player(0), PLAYER_STATE_RESOURCE_GOLD)))',
                                    b'\t\tendif')),
                          'Read-only hero and initial task state after normal hero load')
        quest_begin, quest_end = function_span(data, b'Trig_UI_TaskActions')
        quest = data[quest_begin:quest_end]
        insert_after_line(quest, quest_begin, b'call SaveInteger(YDHT, StringHash((LoadStr(YDLOC, GetHandleId(GetTriggeringTrigger()) * ydl_localvar_step, 0xC17A7013) )), StringHash',
                          eol.join((b'\t\t\t\t\t\tif GetKillingUnit() == udg_Hero[1] and GetUnitTypeId(GetTriggerUnit()) == \'n03X\' then',
                                    b'\t\t\t\t\t\t\tcall AB65DialogEvidence("route-gray-wolf-" + I2S(LoadInteger(YDLOC, GetHandleId(GetTriggeringTrigger()) * ydl_localvar_step, 0x45D90214) + 1), "source=death|victim=n03X|killer=" + YDWEId2S(GetUnitTypeId(GetKillingUnit())) + "|task=" + I2S(LoadInteger(YDHT, GetHandleId(Player(0)), 0xDE511409)) + "|before=" + I2S(LoadInteger(YDLOC, GetHandleId(GetTriggeringTrigger()) * ydl_localvar_step, 0x45D90214)) + "|after=" + I2S(LoadInteger(YDLOC, GetHandleId(GetTriggeringTrigger()) * ydl_localvar_step, 0x45D90214) + 1))',
                                    b'\t\t\t\t\t\tendif')),
                          'Read-only hero kill and quest increment after the original write')

    if mouse_receipts:
        globals_end = re.search(rb'(?m)^endglobals\b', data)
        if globals_end is None:
            raise RuntimeError('Cannot identify globals end')
        edits.append((globals_end.start(), b'', MOUSE_GLOBALS.replace(b'\n', eol), 'Bounded local telemetry counters'))
        entry_begin, entry_end = function_span(data, b'AB65Entry')
        edits.append((entry_begin, b'', MOUSE_LOGGER.replace(b'\n', eol), 'Local asynchronous JAPI mouse telemetry'))
        insert_after_line(data[entry_begin:entry_end], entry_begin, b'call AB65Log("TIMER_ARMED", "interval=1.000")',
                          eol.join((b'    call DzTriggerRegisterMouseMoveEventByCode(null, false, function AB65MouseMove)',
                                    b'    call DzTriggerRegisterMouseEventByCode(null, 1, 1, false, function AB65MouseLeftDown)',
                                    b'    call DzTriggerRegisterMouseEventByCode(null, 2, 1, false, function AB65MouseRightDown)',
                                    b'    call AB65DialogEvidence("route-mouse-armed", "move_limit=32|left_limit=16|right_limit=16")')),
                          'Register passive native input observations')

    if portal_receipts:
        portal_begin, portal_end = function_span(data, b'Trig_TP_XX01Actions')
        portal = data[portal_begin:portal_end]
        insert_after_line(portal, portal_begin, b'call TriggerAddCondition(ydl_trigger, Condition(function Trig_TP_XX01Func018Conditions))',
                          eol.join((b'\tif GetTriggerUnit() == udg_Hero[1] then',
                                    b'\t\tcall AB65DialogEvidence("route-portal-shown", "source=region|x=" + R2S(GetUnitX(GetTriggerUnit())) + "|y=" + R2S(GetUnitY(GetTriggerUnit())) + "|region=035")',
                                    b'\tendif')),
                          'Observe real village region entry and dialog registration')
        q_begin, q_end = function_span(data, b'Trig_TP_XX01Func018Conditions')
        portal_q = data[q_begin:q_end]
        insert_after_line(portal_q, q_begin, b'call GS_Delivery(',
                          eol.join((b'\t\t\tif LoadUnitHandle(YDLOC, GetHandleId(GetTriggeringTrigger()), 0x62274AD0) == udg_Hero[1] and GetClickedButtonBJ() == LoadButtonHandle(YDLOC, GetHandleId(GetTriggeringTrigger()), 0x52177E20 + 1) then',
                                    b'\t\t\t\tcall AB65DialogEvidence("route-portal-q", "source=dialog|index=1|x=" + R2S(GetUnitX(udg_Hero[1])) + "|y=" + R2S(GetUnitY(udg_Hero[1])))',
                                    b'\t\t\tendif')),
                          'Observe actual Q dialog event and hero coordinates after delivery')
        state_begin, state_end = function_span(data, b'AB65Callback')
        edits.append((state_begin, b'', ROUTE_STATE.replace(b'\n', eol), 'Read-only route state sampling'))
        insert_after_line(data[state_begin:state_end], state_begin,
                          b'call AB65Log("HEARTBEAT-"', b'        call AB65RouteState()',
                          'Sample live hero at even existing heartbeat ticks')

    if camera_receipts:
        globals_end = re.search(rb'(?m)^endglobals\b', data)
        if globals_end is None:
            raise RuntimeError('Cannot identify globals end')
        edits.append((globals_end.start(), b'', CAMERA_GLOBALS.replace(b'\n', eol), 'Bounded deselection count'))
        callback_start, callback_stop = function_span(data, b'AB65Callback')
        edits.append((callback_start, b'', CAMERA_LOGGER.replace(b'\n', eol), 'Read-only camera and deselection evidence'))
        insert_after_line(data[callback_start:callback_stop], callback_start, b'call AB65Log("HEARTBEAT-"',
                          b'        call AB65CameraSample()', 'Observe camera on existing game ticks')
        entry_start, entry_stop = function_span(data, b'AB65Entry')
        entry = data[entry_start:entry_stop]
        insert_after_line(entry, entry_start, b'local trigger mutate = CreateTrigger()',
                          b'    local trigger deselect = CreateTrigger()', 'Allocate passive native deselection observer')
        insert_after_line(entry, entry_start, b'call AB65Log("TIMER_ARMED", "interval=1.000")',
                          eol.join((b'    call TriggerRegisterPlayerSelectionEventBJ(deselect, Player(0), false)',
                                    b'    call TriggerAddAction(deselect, function AB65CameraDeselect)',
                                    b'    set deselect = null')),
                          'Register native deselection observer')

    if selection_receipts:
        globals_end = re.search(rb'(?m)^endglobals\b', data)
        if globals_end is None:
            raise RuntimeError('Cannot identify globals end')
        edits.append((globals_end.start(), b'', SELECTION_GLOBALS.replace(b'\n', eol), 'Bounded native selection telemetry counters'))
        expiry_start, expiry_end = function_span(data, b'Trig_ChooseHero_____________uFunc005Func001Func002T')
        edits.append((expiry_start, b'', SELECTION_LOGGER.replace(b'\n', eol), 'Read-only native selection and original expiry logging'))
        expiry = data[expiry_start:expiry_end]
        insert_after_line(expiry, expiry_start, b' takes nothing returns nothing',
                          b'    call AB65SelectionExpire(GetExpiredTimer())', 'Observe original timer before it clears pending selection')
        hero_start, hero_end = function_span(data, b'Trig_ChooseHero_____________uActions')
        insert_after_line(data[hero_start:hero_end], hero_start, b'call TimerStart(ydl_timer, 0.50, false,',
                          b'            call AB65SelectionArm(ydl_timer)', 'Observe original timer after native selection arms it')
        entry_start, entry_end = function_span(data, b'AB65Entry')
        entry = data[entry_start:entry_end]
        insert_after_line(entry, entry_start, b'local trigger mutate = CreateTrigger()',
                          b'    local trigger selection = CreateTrigger()', 'Allocate passive native selection observer')
        insert_after_line(entry, entry_start, b'call AB65Log("TIMER_ARMED", "interval=1.000")',
                          eol.join((b'    call TriggerRegisterPlayerSelectionEventBJ(selection, Player(0), true)',
                                    b'    call TriggerRegisterPlayerSelectionEventBJ(selection, Player(0), false)',
                                    b'    call TriggerAddAction(selection, function AB65SelectionEvent)',
                                    b'    set selection = null')),
                          'Observe native add and remove events for every selected object')

    patched, last, receipt = bytearray(), 0, []
    for offset, old, new, description in sorted(edits):
        if offset < last or data[offset:offset + len(old)] != old:
            raise RuntimeError(f'Overlapping or mismatched edit at {offset}')
        patched.extend(data[last:offset])
        receipt.append({'description': description, 'original_offset': offset, 'patched_offset': len(patched),
                        'old_hex': old.hex(), 'new_hex': new.hex()})
        patched.extend(new)
        last = offset + len(old)
    patched.extend(data[last:])
    restored = bytearray(patched)
    for row in reversed(receipt):
        offset = row['patched_offset']
        new = bytes.fromhex(row['new_hex'])
        restored[offset:offset + len(new)] = bytes.fromhex(row['old_hex'])
    if restored != data:
        raise RuntimeError('Instrumented byte edits are not reversible')
    return bytes(patched), receipt


def inventory(mpq, path, members=None):
    archive = mpq.open(path)
    try:
        script = mpq.read(archive, 'war3map.j')
        listing = mpq.read(archive, '(listfile)')
        if not script or not listing or mpq.read(archive, r'scripts\war3map.j') is not None:
            raise RuntimeError('Unexpected active JASS or missing MPQ listfile')
        names = listing.decode('utf-8-sig').splitlines() if members is None else members
        checked = {}
        for name in dict.fromkeys(names):
            if not name or name.casefold() in ADMIN:
                continue
            raw = mpq.read(archive, name)
            if raw is not None:
                checked[name] = digest_bytes(raw)
        return script, listing, names, checked
    finally:
        mpq.close(archive)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--native-hotkeys', action='store_true', help='Assign native A/B/C to the three dialog buttons')
    parser.add_argument('--route-receipts', action='store_true', help='Observe native hero selection and gray wolf quest increments')
    parser.add_argument('--mouse-receipts', action='store_true', help='Observe bounded local JAPI mouse move and press events')
    parser.add_argument('--portal-receipts', action='store_true', help='Observe the village portal and sample live hero state')
    parser.add_argument('--camera-receipts', action='store_true', help='Observe camera and native selection removal')
    parser.add_argument('--selection-receipts', action='store_true', help='Observe native unit selections and original hero timer expiry')
    parser.add_argument('--roster-camera', action='store_true', help='Stabilize the diagnostic local camera until original hero selection succeeds')
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.relative_to((WORK / 'build/war3-65-cold').resolve())
    output.mkdir(parents=True, exist_ok=False)
    target = output / 'ab65.w3x'
    script_path = output / 'war3map.j'
    if digest(SOURCE) != SOURCE_SHA:
        raise RuntimeError('Frozen candidate SHA changed')

    sys.path.insert(0, str(TOOLS / 'buildtools'))
    from mpq import MPQ

    mpq = MPQ(TOOLS / 'tools/stormlib-x64/StormLib.dll')
    script, listing, names, before = inventory(mpq, SOURCE)
    if digest_bytes(script) != SCRIPT_SHA or len(before) != 3776:
        raise RuntimeError(f'Frozen JASS or member inventory does not match, members={len(before)}')
    patched, edits = native_dialog_patch(script, args.native_hotkeys, args.route_receipts,
                                        args.mouse_receipts, args.portal_receipts, args.camera_receipts,
                                        args.selection_receipts, args.roster_camera)
    script_path.write_bytes(patched)
    compiler = subprocess.run([str(COMPILER / 'plugin/pjass/pjass-latest.exe'), '+rb', str(COMPILER / 'common.j'),
                               str(COMPILER / 'blizzard.j'), str(script_path)],
                              capture_output=True, timeout=40, creationflags=subprocess.CREATE_NO_WINDOW)
    (output / 'pjass.log').write_bytes(compiler.stdout + compiler.stderr)
    if compiler.returncode:
        raise RuntimeError('PJass rejected diagnostic JASS, see pjass.log')

    shutil.copyfile(SOURCE, target)
    archive = mpq.open(target, write=True)
    try:
        mpq.add(archive, 'war3map.j', script_path)
    finally:
        mpq.close(archive)
    readback, new_listing, _, after = inventory(mpq, target, names)
    changed = [name for name in before if before[name] != after.get(name)]
    if (readback != patched or new_listing != listing or changed != ['war3map.j']
            or before.keys() != after.keys() or digest(SOURCE) != SOURCE_SHA):
        raise RuntimeError(f'Unexpected archive readback differences: {changed}')
    receipt = {'source_map': str(SOURCE), 'source_map_sha256': SOURCE_SHA, 'source_jass_sha256': SCRIPT_SHA,
               'output_map': str(target), 'output_map_sha256': digest(target), 'jass_sha256': digest_bytes(readback),
               'listfile_sha256': digest_bytes(listing), 'readable_members': len(before), 'changed_members': changed,
               'pjass_exit': compiler.returncode, 'native_hotkeys': {'easy': 65, 'hard': 66, 'abyss': 67} if args.native_hotkeys else {},
               'route_receipts': args.route_receipts, 'mouse_receipts': args.mouse_receipts,
               'portal_receipts': args.portal_receipts, 'camera_receipts': args.camera_receipts,
               'selection_receipts': args.selection_receipts, 'roster_camera': args.roster_camera, 'edits': edits}
    (output / 'changes.json').write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in receipt.items() if k != 'edits'}))


if __name__ == '__main__':
    main()
