"""Compare native difficulty input on a private desktop with a frozen or instrumented map."""

import argparse
from collections import Counter
from contextlib import nullcontext, suppress
import hashlib
import json
from pathlib import Path
import re
import sys
import time
import traceback

from directed_confirm import HERO_CLEAR_ACTIONS, input_name
from owned_process import OwnedJob, PrivateDesktop
from run import (SCRIPTS, WORK, archive_game_outputs, current_logs, exclusive_game,
                 contiguous, game_processes, idle, prepare_game, read_receipts, stage, utc,
                 verify, wait_pid, write_json)


FROZEN_HASH = "d21fb1e5c2d16ae7e09a05ce3874f31f9d85ed6065c97c9102a6d67a94de6c10"


def probe_input(run, desktop, pid, label, action, point, sync, double_message=False, clear_point=None,
                neutral_client=None, second_point=None, second_delay_ms=None):
    command = [sys.executable, "-B", SCRIPTS / "directed_confirm.py", str(pid),
               desktop.split("\\")[-1], "--action", action]
    if point is not None:
        command.extend(["--point", *(str(number) for number in point)])
    if sync:
        command.append("--sync")
    if double_message:
        command.append("--double-message")
    if clear_point is not None:
        command.extend(["--clear-point", *(str(number) for number in clear_point)])
    if neutral_client is not None:
        command.extend(["--neutral-client", *(str(number) for number in neutral_client)])
    if second_point is not None:
        command.extend(["--second-point", *(str(number) for number in second_point)])
    if second_delay_ms is not None:
        command.extend(["--second-delay-ms", str(second_delay_ms)])
    with OwnedJob(command, run, desktop, run, label=label) as worker:
        code = worker.poll(9)
    raw = (run / f"{label}-stdout.log").read_text(encoding="utf-8")
    return {"code": code, "worker": json.loads(raw) if raw else None}


def observations(run, desktop, pid, when, modes):
    receipts = []
    for mode in modes:
        label = f"{when}-{mode}"
        destination = run / label
        destination.mkdir()
        command = [sys.executable, "-B", SCRIPTS / ("accessibility_observe.py" if mode == "accessibility" else "window_observe.py"),
                   str(pid), desktop.split("\\")[-1], "--pid-file", run / "owned-pid.txt"]
        if mode != "accessibility":
            command.extend(["--output-dir", destination, "--mode", mode])
        with OwnedJob(command, run, desktop, destination, label="observe") as worker:
            code = worker.poll(8 if mode == "accessibility" else 3.5)
        receipts.append({"phase": when, "mode": mode, "directory": label, "code": code})
    return receipts


def heartbeat_files(profile):
    """Use individual file write times when image or input workers temporarily delay polling."""
    samples = {}
    for path in (profile / "bin/Logs").glob("desktop-ab-HEARTBEAT-*.pld"):
        matched = re.fullmatch(r"desktop-ab-HEARTBEAT-(\d+)\.pld", path.name)
        if matched and (b"|tick=" + matched[1].encode("ascii") + b'"') in path.read_bytes():
            samples[int(matched[1])] = path.stat().st_mtime_ns / 1_000_000_000
    best = []
    current = []
    for tick, stamp in sorted(samples.items()):
        if current and (tick != current[-1][0] + 1 or not 0 < stamp - current[-1][1] <= 2.8):
            current = []
        current.append((tick, stamp))
        if len(current) > len(best):
            best = current.copy()
    return {"total": len(samples), "longest_count": len(best),
            "first_tick": best[0][0] if best else None, "last_tick": best[-1][0] if best else None,
            "seconds": round(best[-1][1] - best[0][1], 3) if best else 0,
            "source": "closed-run individual file write timestamps"}


def trial(run, profile, desktop, map_variant, args):
    actions, point, sync, hero, screenshot = args.actions, args.point, args.sync, args.hero, args.screenshot
    identity, host, argv, env = prepare_game(run, profile, map_variant, renderer=args.renderer)
    start = time.monotonic()
    result = {"desktop": desktop, "map_sha256": map_variant[1] if map_variant else FROZEN_HASH,
              "instrumented": map_variant is not None, "identity": identity, "argv": argv,
              "mode": "manual-default" if args.manual_default else "private-desktop",
              "started_utc": utc(), "actions": [], "observations": [], "events": [],
              "input_desktop_before": input_name()}
    write_json(run / "trial.json", result)
    seen = {}
    beats = {}
    next_checkpoint = 0.0
    issued = Counter()
    last_map_scan = 0
    confirms = 0
    confirmed = None
    prompted = None
    next_action = None
    quit_at = None
    hero_at = None
    menu_not_before = None
    screenshot_sent = False
    ready_since = None
    positioned = False
    scripted = 0
    monitor = None
    if args.interactive:
        (run / "commands").mkdir()
    with OwnedJob(host, profile, desktop, run, env) as job:
        try:
            pid = wait_pid(job, run)
            result.update(host_pid=job.pid, game_pid=pid, initial_job_members=job.pids())
            if args.activity:
                activity = run / "activity"
                activity.mkdir()
                worker = [sys.executable, "-B", SCRIPTS / "desktop_activity.py", "--pid", str(pid),
                          "--pid-file", run / "owned-pid.txt", "--output-dir", activity,
                          "--duration", str(args.limit), "--stop-file", run / "activity-stop"]
                monitor = OwnedJob(worker, run, r"WinSta0\Default", activity, label="monitor")
            while job.poll(0.2) is None:
                job.send("poll")
                t = time.monotonic() - start
                if input_name() != result["input_desktop_before"]:
                    raise RuntimeError("Input desktop changed during trial")
                # The game can spend minutes in a route. Never rescan the body of every old heartbeat.
                logs = current_logs(profile, skip=seen) if t >= last_map_scan + 0.18 else {}
                if logs:
                    last_map_scan = t
                for file, message in logs.items():
                    if file not in seen:
                        seen[file] = message
                        result["events"].append({"file": file, "message": message, "elapsed": round(t, 3)})
                        if file.startswith("desktop-ab-HEARTBEAT-"):
                            tick = file.removeprefix("desktop-ab-HEARTBEAT-").removesuffix(".pld")
                            if tick.isdigit() and message.endswith(f"|tick={tick}"):
                                beats[int(tick)] = t
                result["difficulty_receipt"] = seen.get("dialog-chosen.pld")
                result["hero_receipt"] = seen.get("route-hero-chosen.pld")
                result["combat_receipt"] = seen.get("route-gray-wolf-1.pld")
                if t > args.limit or (quit_at is not None and t > quit_at + 12):
                    result["stop_reason"] = "trial deadline"
                    break
                if args.manual_default:
                    result["game_resumed"] = "desktop-ab-HEARTBEAT-4.pld" in seen
                    if t >= next_checkpoint:
                        result["continuous_heartbeat"] = contiguous(beats)
                        write_json(run / "trial.json", result)
                        next_checkpoint = t + 0.75
                    continue
                if "desktop-ab-TIMER_ARMED.pld" not in seen:
                    if t > 80:
                        result["stop_reason"] = "map never armed"
                        break
                    continue
                if confirmed is None or ("desktop-ab-HEARTBEAT-1.pld" not in seen
                                         and confirms == 1 and t >= confirmed + 4):
                    if pid not in job.pids():
                        raise RuntimeError("Owned game left job before input")
                    if args.neutral_origin and not positioned:
                        receipt = probe_input(run, desktop, pid, "private-window-position",
                                              "camera-neutral-origin", None, False,
                                              neutral_client=args.neutral_client)
                        result["actions"].append({"action": "camera-neutral-origin", "elapsed": t, **receipt})
                        if receipt["code"] != 0:
                            result["stop_reason"] = "private window position could not be verified"
                            break
                        if args.private_focus:
                            focus_receipt = probe_input(run, desktop, pid, "private-window-focus",
                                                       "camera-private-focus", None, False)
                            result["actions"].append({"action": "camera-private-focus", **focus_receipt})
                        positioned = True
                    confirms += 1
                    receipt = probe_input(run, desktop, pid, f"input-confirm-{confirms}", "confirm", None, False)
                    result["actions"].append({"action": "confirm", **receipt})
                    if receipt["code"] != 0:
                        result["stop_reason"] = "Space sender did not complete"
                        break
                    confirmed = t
                if "desktop-ab-HEARTBEAT-1.pld" not in seen:
                    if t > confirmed + 12:
                        result["stop_reason"] = "no first heartbeat after Space"
                        break
                    write_json(run / "trial.json", result)
                    continue
                shown = "dialog-shown.pld" in seen
                if prompted is None and (shown or not map_variant) and t >= confirmed + 1:
                    prompted = t
                    if args.accessibility:
                        result["observations"].extend(observations(run, desktop, pid, "dialog", ("accessibility",)))
                    if not args.fast_hero:
                        result["observations"].extend(observations(run, desktop, pid, "dialog", ("info", "print", "bitblt")))
                    next_action = t if args.fast_hero else t + 1
                chosen = seen.get("dialog-chosen.pld")
                resumed = "desktop-ab-HEARTBEAT-4.pld" in seen
                if chosen or resumed:
                    result.update(difficulty_receipt=chosen, game_resumed=resumed)
                if (resumed or (args.fast_hero and chosen)) and hero and hero_at is None:
                    if pid not in job.pids():
                        raise RuntimeError("Owned game left job before hero input")
                    if not args.fast_hero:
                        result["observations"].extend(observations(run, desktop, pid, "hero", ("info", "print-window")))
                    receipt = probe_input(run, desktop, pid, "input-hero", args.hero_action, hero, args.hero_sync,
                                          args.hero_double_message, args.hero_clear_point,
                                          second_point=args.hero_second_point, second_delay_ms=args.hero_second_delay_ms)
                    hero_at = time.monotonic() - start
                    result["actions"].append({"action": args.hero_action, "elapsed": hero_at, **receipt})
                    menu_not_before = hero_at + 7
                if screenshot and resumed and not screenshot_sent:
                    if pid not in job.pids():
                        raise RuntimeError("Owned game left job before capture request")
                    receipt = probe_input(run, desktop, pid, "input-screenshot", "game-screenshot", None, False)
                    result["actions"].append({"action": "game-screenshot", "elapsed": t, **receipt})
                    result["observations"].extend(observations(run, desktop, pid, "game", ("dwm-thumbnail",)))
                    screenshot_sent = True
                if resumed and ready_since is None:
                    ready_since = t
                    if args.accessibility:
                        result["observations"].extend(observations(run, desktop, pid, "roster", ("accessibility",)))
                if resumed and args.interactive and quit_at is None:
                    marker = run / "commands" / f"{scripted + 1:03}.json"
                    if marker.is_file():
                        command = json.loads(marker.read_text(encoding="utf-8"))
                        action = command["action"]
                        allowed = {"game-screenshot", "hero-select", "hero-reselect", "hero-double-select",
                                   *HERO_CLEAR_ACTIONS, "hero-reselect-shift", "hero-select-control", "minimap-click",
                                   "portal-q", "hero-f1", "route-attack", "route-move",
                                   "route-stop", "menu", "mouse-move", "arrow-down", "arrow-right",
                                   "arrow-up", "arrow-left", "camera-recenter", "camera-hover-center",
                                   "camera-neutral-origin", "camera-private-focus"}
                        if pid not in job.pids():
                            raise RuntimeError("Route command target left its job")
                        scripted += 1
                        if action in allowed:
                            receipt = probe_input(run, desktop, pid, f"command-{scripted:03}-{action}", action,
                                                  command.get("point"), command.get("sync", False), command.get("double_message", False),
                                                  command.get("clear_point"), command.get("neutral_client"),
                                                  command.get("second_point"), command.get("second_delay_ms"))
                        else:
                            receipt = {"code": 2, "error": "unsupported route action"}
                        result["actions"].append({"action": action, "elapsed": t, **receipt})
                        if action == "menu":
                            quit_at = time.monotonic() - start
                if resumed and quit_at is None and not args.interactive and t >= ready_since + args.hold \
                        and (not hero or menu_not_before is not None and t >= menu_not_before):
                    if pid not in job.pids():
                        raise RuntimeError("Owned game left job before menu")
                    result["observations"].extend(observations(run, desktop, pid, "after-dialog", ("info", "print")))
                    receipt = probe_input(run, desktop, pid, "input-menu", "menu", None, False)
                    result["actions"].append({"action": "menu", **receipt})
                    quit_at = time.monotonic() - start
                if prompted is not None and not chosen and not resumed and next_action is not None and t >= next_action:
                    if not actions:
                        result["stop_reason"] = "no dialog callback or continued heartbeats"
                        break
                    action = actions.pop(0)
                    if pid not in job.pids():
                        raise RuntimeError("Owned game left job before dialog input")
                    issued[action] += 1
                    label = f"input-{action}-{issued[action]}"
                    receipt = probe_input(run, desktop, pid, label, action,
                                          point if action in ("easy", "dialog-mouse") else None,
                                          sync and action in ("easy", "dialog-mouse"))
                    result["actions"].append({"action": action, "elapsed": round(t, 3), **receipt})
                    next_action = time.monotonic() - start + 5
                if t >= next_checkpoint:
                    result["continuous_heartbeat"] = contiguous(beats)
                    write_json(run / "trial.json", result)
                    next_checkpoint = t + 0.75
        except Exception as error:
            result.update(error=repr(error), traceback=traceback.format_exc())
        finally:
            if monitor is not None:
                with suppress(OSError):
                    (run / "activity-stop").touch()
                try:
                    result["activity_exit"] = monitor.poll(3)
                except OSError as error:
                    result["activity_error"] = repr(error)
                with suppress(OSError):
                    monitor.close()
            if job.poll() is None:
                try:
                    job.send("timeout-stop")
                    result["timeout_sent"] = True
                except BrokenPipeError:
                    pass
            result["host_exit"] = job.poll(8)
            if idle(job, 2)["active"]:
                result["forced_job_reap"] = job.reap()
            result["members_after"] = job.pids()
            result["game_exit"] = read_receipts(run)[1]
    result.update(finished_utc=utc(), elapsed_seconds=round(time.monotonic() - start, 3),
                  input_desktop_after=input_name(), remaining_game_processes=game_processes())
    result["continuous_heartbeat"] = contiguous(beats)
    result["file_heartbeat"] = heartbeat_files(profile)
    result["crashes"] = [path.name for path in (profile / "bin/Errors").glob("*") if path.is_file()]
    result["hashes_after_match"] = identity == verify(profile, map_variant)
    result["output"] = archive_game_outputs(run, profile)
    result["clean"] = (result["host_exit"] == 0 and not result["members_after"] and
                       not result["remaining_game_processes"] and result["hashes_after_match"] and
                       not result["crashes"])
    write_json(run / "trial.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("profile", type=Path)
    parser.add_argument("--stage", action="store_true")
    parser.add_argument("--map", type=Path)
    parser.add_argument("--sha256")
    parser.add_argument("--actions", nargs="*", default=["dialog-nav", "dialog-enter"])
    parser.add_argument("--point", nargs=2, type=int)
    parser.add_argument("--sync", action="store_true")
    parser.add_argument("--hero", nargs=2, type=int, help="Send a calibrated double selection after the original dialog")
    parser.add_argument("--hero-action", choices=("hero-reselect", "hero-reselect-shift", "hero-double-select",
                                                   "hero-select-control") + HERO_CLEAR_ACTIONS,
                        default="hero-double-select")
    parser.add_argument("--hero-clear-point", nargs=2, type=int)
    parser.add_argument("--hero-second-point", nargs=2, type=int)
    parser.add_argument("--hero-second-delay-ms", type=int)
    parser.add_argument("--hero-double-message", action="store_true")
    parser.add_argument("--hero-sync", action="store_true")
    parser.add_argument("--fast-hero", action="store_true", help="Use early game receipt instead of delaying hero input for GDI")
    parser.add_argument("--neutral-origin", action="store_true", help="Position only the private game window for cursor-fallback comparison")
    parser.add_argument("--neutral-client", nargs=2, type=int, help="Target fallback client point with --neutral-origin")
    parser.add_argument("--private-focus", action="store_true", help="Try same-desktop focus after private-window move")
    parser.add_argument("--screenshot", action="store_true", help="Request an in-game screenshot and observe DWM on the private desktop")
    parser.add_argument("--interactive", action="store_true", help="Accept numbered JSON action files after the original dialog")
    parser.add_argument("--hold", type=int, default=0, help="Observe gameplay for this many seconds before menu exit")
    parser.add_argument("--limit", type=int, default=120)
    parser.add_argument("--activity", action="store_true", help="Collect only passive input activity counts on the input desktop")
    parser.add_argument("--accessibility", action="store_true", help="Read the private game UI Automation tree at the original dialog and roster")
    parser.add_argument("--renderer", choices=("opengl", "client-default"), default="opengl",
                        help="Compare the client default renderer without changing system settings")
    parser.add_argument("--manual-default", action="store_true", help="Start a user-operated foreground positive control; sends no input")
    args = parser.parse_args()
    if (args.private_focus or args.neutral_client is not None) and not args.neutral_origin:
        parser.error("--private-focus and --neutral-client require --neutral-origin")
    if not 30 <= args.limit <= 7200 or not 0 <= args.hold < args.limit:
        parser.error("--limit must be 30..7200 seconds and --hold must be below it")
    if args.manual_default and (args.hero or args.neutral_origin or args.screenshot or args.interactive or args.accessibility):
        parser.error("--manual-default only observes user input")
    run, profile = args.run.resolve(), args.profile.resolve()
    build = (WORK / "build/war3-65-cold").resolve()
    run.relative_to((WORK / "logs/war3-65-cold").resolve())
    profile.relative_to(build)
    variant = None
    if args.map:
        source = args.map.resolve(strict=True)
        source.relative_to(build)
        if not args.sha256 or len(args.sha256) != 64:
            parser.error("--map requires its audited SHA-256")
        with source.open("rb") as file:
            actual = hashlib.file_digest(file, "sha256").hexdigest()
        if actual != args.sha256.lower():
            raise RuntimeError("Diagnostic map hash differs")
        variant = source, actual
    run.mkdir()
    if args.stage:
        write_json(run / "stage.json", {"profile": str(profile), "identity": stage(profile, variant)})
    if not (SCRIPTS / "window_observe.py").is_file():
        raise RuntimeError("Missing window observation worker")
    if args.accessibility and not (SCRIPTS / "accessibility_observe.py").is_file():
        raise RuntimeError("Missing private accessibility observer")
    target = nullcontext(r"WinSta0\Default") if args.manual_default else PrivateDesktop()
    with exclusive_game(), target as desktop:
        if args.manual_default and input_name() != "Default":
            raise RuntimeError("Manual positive control requires the active Default desktop")
        result = trial(run, profile, desktop, variant, args)
    print(json.dumps({key: result.get(key) for key in ("map_sha256", "difficulty_receipt", "game_resumed",
                     "file_heartbeat", "hero_receipt", "combat_receipt", "game_exit", "host_exit",
                     "stop_reason", "clean", "error")}))
    successful_exit = result["game_exit"] == ["natural", 0] and not result.get("timeout_sent")
    return 0 if result["clean"] and "error" not in result and successful_exit else 1


if __name__ == "__main__":
    raise SystemExit(main())
