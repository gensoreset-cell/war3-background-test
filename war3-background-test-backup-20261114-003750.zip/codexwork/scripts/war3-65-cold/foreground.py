"""Guarded input for a supervised Warcraft III 1.27 diagnostic run."""

import argparse
import ctypes as c
from ctypes import wintypes as w
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import runpy
import struct
import time


HISTORY = Path(__file__).resolve().parents[2] / "temp"
REFERENCE = HISTORY / "war3-confirm-20261113-a05"
FRAME_SIZE = (1920, 1023)
PROMPT_BOX = (850, 894, 1070, 929)
HUD_BOXES = ((25, 760, 320, 779), (366, 797, 423, 994), (1210, 760, 1400, 789))
MIN_HUD_SCORE = 0.64


class Guarded(RuntimeError):
    pass


class Bitmap:
    def __init__(self, path):
        self.data = path.read_bytes()
        if self.data[:2] != b"BM":
            raise Guarded("capture is not a BMP")
        self.offset = struct.unpack_from("<I", self.data, 10)[0]
        width, height, planes, bits, compression = struct.unpack_from("<iiHHI", self.data, 18)
        if (width, height) != FRAME_SIZE or (planes, bits, compression) != (1, 32, 0):
            raise Guarded(f"capture geometry or bitmap encoding changed: {width}x{height}/{bits}")
        if len(self.data) < self.offset + width * height * 4:
            raise Guarded("capture is truncated")

    def pixel(self, x, y):
        pos = self.offset + ((FRAME_SIZE[1] - 1 - y) * FRAME_SIZE[0] + x) * 4
        return self.data[pos:pos + 3]

    def pixels(self, box, step=1):
        left, top, right, bottom = box
        return ((x, y, self.pixel(x, y)) for y in range(top, bottom, step) for x in range(left, right, step))


def difference(first, second):
    return max(abs(a - b) for a, b in zip(first, second, strict=True))


def sample_score(current, reference, boxes, *, step=4, tolerance=19, stable_against=None):
    hits = total = 0
    for box in boxes:
        for x, y, color in reference.pixels(box, step):
            if max(color) < 70:
                continue
            if stable_against is not None and difference(color, stable_against.pixel(x, y)) > 5:
                continue
            total += 1
            hits += difference(current.pixel(x, y), color) <= tolerance
    if not total:
        raise Guarded("visual reference has no usable pixels")
    return round(hits / total, 4)


def visual_state(path):
    bitmap = Bitmap(path)
    prompt = b"".join(color for _, _, color in bitmap.pixels(PROMPT_BOX))
    prompt_paths = [REFERENCE / "capture-before-01.bmp"]
    prompt_paths.extend(HISTORY / "war3-desktop-ab-20261113-a01" / f"capture-A{n}-5.bmp" for n in range(1, 5))
    prompt_hash = hashlib.sha256(prompt).digest()
    prompt_found = False
    for candidate in prompt_paths:
        known = Bitmap(candidate)
        region = b"".join(color for _, _, color in known.pixels(PROMPT_BOX))
        if hashlib.sha256(region).digest() == prompt_hash:
            prompt_found = True
            break
    difficulty = Bitmap(HISTORY / "war3-confirm-20261113-a02" / "capture-after-10.0.bmp")
    stable = Bitmap(HISTORY / "war3-confirm-20261113-a03" / "capture-after-28.0.bmp")
    hover = Bitmap(REFERENCE / "capture-difficulty-hover.bmp")
    return {
        "load_confirmation": prompt_found,
        "difficulty_score": sample_score(bitmap, difficulty, ((630, 265, 1290, 620),), stable_against=stable),
        "easy_hover_score": sample_score(bitmap, hover, ((740, 379, 923, 409), (1010, 379, 1188, 409))),
        "map_hud_score": sample_score(bitmap, hover, HUD_BOXES, tolerance=36),
    }


class KeyInput(c.Structure):
    _fields_ = [("vk", w.WORD), ("scan", w.WORD), ("flags", w.DWORD), ("time", w.DWORD), ("extra", c.c_size_t)]


class MouseInput(c.Structure):
    _fields_ = [("x", w.LONG), ("y", w.LONG), ("data", w.DWORD), ("flags", w.DWORD), ("time", w.DWORD), ("extra", c.c_size_t)]


class InputData(c.Union):
    _fields_ = [("key", KeyInput), ("mouse", MouseInput)]


class Input(c.Structure):
    _anonymous_ = ("data",)
    _fields_ = [("kind", w.DWORD), ("data", InputData)]


class LastInput(c.Structure):
    _fields_ = [("size", w.UINT), ("time", w.DWORD)]


class Foreground:
    def __init__(self, pid, output, receipt):
        self.pid, self.output, self.receipt = pid, output, receipt
        self.events = []
        self.native = runpy.run_path(str(REFERENCE / "capture.py"))
        self.native["capture"].__globals__["root"] = output
        bind, user = self.native["bind"], self.native["u"]
        self.send_input = bind(user, "SendInput", w.UINT, w.UINT, c.POINTER(Input), c.c_int)
        self.key_state = bind(user, "GetAsyncKeyState", c.c_short, c.c_int)
        self.last_input = bind(user, "GetLastInputInfo", w.BOOL, c.POINTER(LastInput))
        self.get_cursor = bind(user, "GetCursorPos", w.BOOL, c.POINTER(w.POINT))
        self.set_cursor = bind(user, "SetCursorPos", w.BOOL, c.c_int, c.c_int)
        self.metrics = bind(user, "GetSystemMetrics", c.c_int, c.c_int)
        self.post_message = bind(user, "PostMessageW", w.BOOL, w.HWND, w.UINT, w.WPARAM, w.LPARAM)
        self.window_at = bind(user, "WindowFromPoint", w.HWND, w.POINT)
        self.get_ancestor = bind(user, "GetAncestor", w.HWND, w.HWND, w.UINT)
        self.target = self.native["game_hwnd"](pid)
        if not self.target:
            raise Guarded("no Warcraft III window for this PID on worker desktop")

    def activity(self):
        info = LastInput(c.sizeof(LastInput), 0)
        if not self.last_input(c.byref(info)):
            raise Guarded("unable to check user input activity")
        return info.time

    def cursor(self):
        point = w.POINT()
        if not self.get_cursor(c.byref(point)):
            raise Guarded("unable to read cursor position")
        return point

    def guard(self, activity):
        try:
            owner = self.receipt.read_text(encoding="utf-8-sig").strip()
        except OSError as exc:
            raise Guarded("missing current-run owned PID receipt") from exc
        if owner != str(self.pid):
            raise Guarded("PID does not match current-run owned PID receipt")
        if self.receipt.with_name("host-exit.txt").exists():
            raise Guarded("current-run supervisor has exited")
        thread_desktop = self.native["get_thread_desktop"](self.native["get_thread"]())
        if (self.native["input_name"]() != "Default" or self.native["object_name"](thread_desktop) != "Default"
                or self.native["object_name"](self.native["get_station"]()) != "WinSta0"):
            raise Guarded("worker and input desktops must both be WinSta0\\Default")
        if self.native["game_hwnd"](self.pid) != self.target or self.native["foreground"]() != self.target:
            raise Guarded("owned Warcraft III window lost foreground or changed identity")
        if self.native["is_iconic"](self.target) or not self.native["is_window_visible"](self.target):
            raise Guarded("owned Warcraft III window is minimized or hidden")
        if self.activity() != activity:
            raise Guarded("recent input changed during the guarded step")
        down = [key for key in range(1, 255) if self.key_state(key) & 0x8000]
        if down:
            raise Guarded(f"held keys or mouse buttons: {down}")

    def shot(self, label):
        result = self.native["capture"](self.pid, label)
        if not result.get("sha256") or self.native["game_hwnd"](self.pid) != self.target:
            raise Guarded(f"could not capture owned game window: {result}")
        event = {"capture": f"capture-{label}.bmp", **result}
        self.events.append(event)
        return event

    def state(self, label):
        event = self.shot(label)
        event["visual"] = visual_state(self.output / event["capture"])
        return event["visual"]

    def send(self, items, activity, label):
        self.guard(activity)
        events = (Input * len(items))(*items)
        c.set_last_error(0)
        sent = self.send_input(len(items), events, c.sizeof(Input))
        self.events.append({"input": label, "requested": len(items), "inserted": sent, "error": c.get_last_error()})
        if sent != len(items):
            # Every button/key pair is adjacent. Complete a partially inserted pair so a held input cannot leak.
            if 0 < sent < len(items):
                pending = events[sent]
                if (pending.kind == 1 and pending.key.flags & 2) or (pending.kind == 0 and pending.mouse.flags == 4):
                    released = self.send_input(1, c.byref(pending), c.sizeof(Input))
                    self.events.append({"release_after_partial_insert": released})
            raise Guarded(f"{label} input was not fully inserted")
        return self.activity()

    @staticmethod
    def key(scan):
        down, up = Input(), Input()
        down.kind = up.kind = 1
        down.key, up.key = KeyInput(0, scan, 8, 0, 0), KeyInput(0, scan, 10, 0, 0)
        return [down, up]

    @staticmethod
    def mouse(x, y, flags):
        event = Input()
        event.mouse = MouseInput(x, y, 0, flags, 0, 0)
        return event

    def easy(self, activity):
        rect = w.RECT()
        if not self.native["get_rect"](self.target, c.byref(rect)) or (rect.right - rect.left, rect.bottom - rect.top) != FRAME_SIZE:
            raise Guarded("game window moved or has unrecognized geometry")
        original = self.cursor()
        x, y = rect.left + 963, rect.top + 390
        left, top, width, height = (self.metrics(n) for n in (76, 77, 78, 79))
        if width <= 1 or height <= 1 or not (left <= x < left + width and top <= y < top + height):
            raise Guarded("the target point is outside the input desktop")
        move = self.mouse(round(65535 * (x - left) / (width - 1)), round(65535 * (y - top) / (height - 1)), 0xC001)
        activity = self.send([move], activity, "hover Easy")
        try:
            time.sleep(0.45)
            position = self.cursor()
            if abs(position.x - x) > 4 or abs(position.y - y) > 4 or self.get_ancestor(self.window_at(position), 2) != self.target:
                raise Guarded("Easy hover no longer points at the owned game window")
            visual = self.state("easy-hover")
            if visual["difficulty_score"] < 0.86 or visual["easy_hover_score"] < 0.90:
                raise Guarded("Easy button hover did not visually match")
            activity = self.send([self.mouse(0, 0, 2), self.mouse(0, 0, 4)], activity, "request Easy click")
        finally:
            position = self.cursor()
            if (abs(position.x - x) <= 4 and abs(position.y - y) <= 4 and self.activity() == activity
                    and self.native["foreground"]() == self.target):
                self.set_cursor(original.x, original.y)

    def chat(self, text, activity, logs):
        if not logs or not recent_heartbeat(logs):
            raise Guarded("missing fresh cold-start map heartbeat for chat input")
        layout = {"-": 0x0C, "r": 0x13, "2": 0x03, "e": 0x12, "a": 0x1E, "d": 0x20,
                  "y": 0x15, "m": 0x32, "u": 0x16, "t": 0x14}
        activity = self.send(self.key(0x1C), activity, "open chat")
        time.sleep(0.15)
        self.shot("chat-open")
        keys = []
        for char in text:
            keys.extend(self.key(layout[char]))
        keys.extend(self.key(0x1C))
        self.send(keys, activity, text)

    def close_window(self, activity, logs):
        if not logs or not recent_heartbeat(logs):
            raise Guarded("missing fresh cold-start map heartbeat for window close")
        self.guard(activity)
        c.set_last_error(0)
        queued = bool(self.post_message(self.target, 0x0010, 0, 0))
        error = c.get_last_error()
        self.events.append({"requested": "WM_CLOSE", "hwnd": self.target, "queued": queued, "error": error})
        if not queued:
            raise Guarded("targeted WM_CLOSE was rejected")


def recent_heartbeat(logs):
    now = time.time()
    for path in logs.glob("desktop-ab-HEARTBEAT-*.pld"):
        match = re.fullmatch(r"desktop-ab-HEARTBEAT-(\d+)\.pld", path.name)
        if match and 0 <= now - path.stat().st_mtime < 4:
            tick = match[1].encode("ascii")
            data = path.read_bytes()
            if b"AB65|HEARTBEAT-" + tick + b"|" in data and b"|tick=" + tick + b'"' in data:
                return True
    return False


def run(args, output, summary):
    control = Foreground(args.pid, output, args.pid_file or args.output_dir / "owned-pid.txt")
    summary.update({"pid": args.pid, "hwnd": control.target, "events": control.events})
    if args.step == "capture":
        control.state("observed")
        return
    activity = control.activity()
    control.guard(activity)
    visual = control.state("before-input")
    if args.step == "confirm":
        if not visual["load_confirmation"]:
            raise Guarded("load confirmation prompt did not visually match")
        control.send(control.key(0x39), activity, "confirm load with Space")
    elif args.step == "easy":
        if visual["difficulty_score"] < 0.90:
            raise Guarded("difficulty modal did not visually match")
        control.easy(activity)
    elif args.step in ("ready", "mutate", "quit"):
        if visual["load_confirmation"] or visual["difficulty_score"] >= 0.86 or visual["map_hud_score"] < MIN_HUD_SCORE:
            raise Guarded("gameplay HUD did not visually match")
        if args.step == "quit":
            control.close_window(activity, args.logs_dir)
        else:
            control.chat("-r2" + args.step, activity, args.logs_dir)
    else:
        raise Guarded("hero selection needs a live visual reference and a separately verified gate")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pid", type=int)
    parser.add_argument("--pid-file", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--logs-dir", type=Path)
    parser.add_argument("--step", choices=("capture", "confirm", "easy", "hero", "ready", "mutate", "quit"))
    parser.add_argument("--fixture-bmp", type=Path, help="Classify an existing image. No desktop access or input.")
    args = parser.parse_args()
    if args.fixture_bmp:
        print(json.dumps(visual_state(args.fixture_bmp), sort_keys=True))
        return 0
    if args.pid is None or args.pid <= 0 or not args.step or not args.output_dir:
        parser.error("--pid, --step and --output-dir are required for an active run")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S-%fZ")
    output = args.output_dir / f"ui-{args.step}-{stamp}"
    output.mkdir(parents=True, exist_ok=False)
    summary = {"step": args.step, "utc": stamp, "directory": str(output)}
    try:
        run(args, output, summary)
        summary["status"] = {"capture": "observed", "easy": "easy_click_requested", "quit": "window_close_requested"}.get(
            args.step, "input_inserted"
        )
        code = 0
    except Guarded as exc:
        summary.update(status="guarded", reason=str(exc))
        code = 2
    except (OSError, ValueError, struct.error) as exc:
        summary.update(status="error", reason=str(exc))
        code = 1
    data = json.dumps(summary, indent=2, ensure_ascii=True)
    (output / "result.json").write_text(data + "\n", encoding="utf-8")
    print(data)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
