"""Read Warcraft III 1.27 replay selections and issued point or target orders."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
import zlib


# Layout references:
# https://github.com/scopatz/w3g/blob/master/w3g_format.txt
# https://github.com/scopatz/w3g/blob/master/w3g_actions.txt
MAGIC = b'Warcraft III recorded game\x1a\x00'
BLOCK_SIZE = 8192
NO_OBJECT = (0xFFFFFFFF, 0xFFFFFFFF)
ORDER_NAMES = {851971: 'smart', 851983: 'attack', 851986: 'move'}
RECORD_SIZES = {0x17: 13, 0x1A: 4, 0x1B: 4, 0x1C: 4, 0x23: 10, 0x2F: 8}

# Fixed payload sizes, excluding the action opcode. Other known layouts are
# parsed separately. Unknown opcodes fail instead of scanning for event bytes.
IGNORED_ACTION_SIZES = {
    0x01: 0, 0x02: 0, 0x03: 1, 0x04: 0, 0x05: 0, 0x07: 4,
    0x10: 14, 0x13: 38, 0x14: 42, 0x15: 50,
    0x1A: 0, 0x1B: 9, 0x1C: 9, 0x1D: 8, 0x1E: 5, 0x1F: 5,
    0x20: 0, 0x21: 8, 0x22: 0, 0x23: 0, 0x24: 0, 0x25: 0, 0x26: 0,
    0x27: 5, 0x28: 5, 0x29: 0, 0x2A: 0, 0x2B: 0, 0x2C: 0,
    0x2D: 5, 0x2E: 4, 0x2F: 0, 0x30: 0, 0x31: 0, 0x32: 0,
    0x51: 9, 0x61: 0, 0x62: 12, 0x63: 8, 0x64: 8, 0x65: 8,
    0x66: 0, 0x67: 0, 0x68: 12, 0x69: 16, 0x6A: 16, 0x75: 1,
}


class Reader:
    def __init__(self, data, context):
        self.data = data
        self.context = context
        self.offset = 0

    def remaining(self):
        return len(self.data) - self.offset

    def take(self, size):
        if size < 0 or size > self.remaining():
            self.error(f'invalid field length {size}, remaining {self.remaining()}')
        start = self.offset
        self.offset += size
        return self.data[start:self.offset]

    def unpack(self, fmt):
        return struct.unpack(fmt, self.take(struct.calcsize(fmt)))

    def byte(self):
        return self.take(1)[0]

    def cstring(self):
        end = self.data.find(b'\0', self.offset)
        if end < 0:
            self.error('missing string terminator')
        return self.take(end + 1 - self.offset)[:-1]

    def error(self, message):
        raise ValueError(f'{self.context} at byte {self.offset}: {message}')


def unpack_replay(raw):
    reader = Reader(raw, 'replay file')
    if reader.take(len(MAGIC)) != MAGIC:
        reader.error('invalid W3G signature')
    header_size, file_size, header_version, data_size, block_count = reader.unpack('<IIIII')
    game, patch, build, flags, header_duration, header_crc = reader.unpack('<4sIHHII')
    if header_version != 1 or game != b'PX3W' or patch != 27:
        reader.error(f'expected classic TFT patch 1.27, got {game!r}, patch {patch}, header {header_version}')
    if file_size != len(raw) or not block_count or not 0 < data_size <= block_count * BLOCK_SIZE:
        reader.error('invalid replay size or block count')
    if header_size != reader.offset or zlib.crc32(raw[:header_size - 4] + bytes(4)) != header_crc:
        reader.error('invalid classic header size or CRC32')
    output = bytearray()
    for index in range(block_count):
        packed_size, unpacked_size, _ = reader.unpack('<HHI')
        if not packed_size or not 0 < unpacked_size <= BLOCK_SIZE:
            reader.error(f'invalid compressed block {index} size')
        inflater = zlib.decompressobj()
        block = inflater.decompress(reader.take(packed_size), unpacked_size + 1)
        if len(block) != unpacked_size or inflater.unconsumed_tail or inflater.unused_data:
            reader.error(f'invalid compressed block {index} payload')
        output.extend(block)
    if reader.remaining() or not 0 <= len(output) - data_size < BLOCK_SIZE or any(output[data_size:]):
        reader.error('invalid block extent or nonzero final padding')
    header = {'patch': patch, 'build': build, 'flags': flags, 'header_duration_ms': header_duration}
    return bytes(output[:data_size]), header


def read_player(reader):
    reader.take(1)  # Player ID
    reader.cstring()
    reader.take(reader.byte())  # Additional player data


def read_lobby(reader):
    reader.take(4)  # Game info identifier
    if reader.byte() != 0:
        reader.error('missing host player record')
    read_player(reader)
    reader.cstring()  # Game name
    if reader.byte() != 0:
        reader.error('missing game name separator')
    reader.cstring()  # Encoded settings and map metadata
    reader.take(12)  # Player count, game type and language
    record = reader.byte()
    while record == 0x16:
        read_player(reader)
        reader.take(4)
        record = reader.byte()
    if record != 0x19:
        reader.error(f'expected slot record, got {record:#04x}')
    reader.take(reader.unpack('<H')[0])


def rawcode(value):
    code = value[::-1]
    if all(0x20 <= byte < 0x7F for byte in code):
        return code.decode('ascii')
    return None


def read_actions(payload, time_ms, player, events):
    reader = Reader(payload, f'player {player} actions at {time_ms} ms')
    while reader.remaining():
        opcode = reader.byte()
        event = {'time_ms': time_ms, 'player': player, 'opcode': f'{opcode:#04x}'}
        if opcode in (0x11, 0x12):
            flags, order, _, _, x, y = reader.unpack('<HIIIff')
            target = reader.unpack('<II') if opcode == 0x12 else NO_OBJECT
            event.update(kind='point_order' if target == NO_OBJECT else 'target_order',
                         order_id=order, order_name=ORDER_NAMES.get(order), flags=flags,
                         x=x if math.isfinite(x) else None, y=y if math.isfinite(y) else None,
                         target=None if target == NO_OBJECT else target)
            events.append(event)
        elif opcode in (0x16, 0x17):
            mode, count = reader.unpack('<BH')
            objects = list(struct.iter_unpack('<II', reader.take(count * 8)))
            if opcode == 0x16:
                if mode not in (1, 2):
                    reader.error(f'unknown selection mode {mode:#04x}')
                event.update(kind='selection', mode='select' if mode == 1 else 'deselect', objects=objects)
                events.append(event)
        elif opcode == 0x18:
            group, _ = reader.unpack('<BB')
            event.update(kind='select_group', group=group)
            events.append(event)
        elif opcode == 0x19:
            code, first, second = reader.unpack('<4sII')
            event.update(kind='subgroup', rawcode=rawcode(code), object=(first, second))
            events.append(event)
        elif opcode == 0x50:
            slot = reader.byte()
            if slot in (0xF0, 0xF1):
                # Length-framed variant seen in the local WorldEdit/KKWE replays.
                reserved, size = reader.unpack('<HI')
                if reserved != 0:
                    reader.error('unrecognized scenario action framing')
                reader.take(size)
            else:
                reader.take(4)
        elif opcode == 0x06:
            reader.cstring()
        elif opcode == 0x60:
            reader.take(8)
            reader.cstring()
        elif opcode in IGNORED_ACTION_SIZES:
            reader.take(IGNORED_ACTION_SIZES[opcode])
        else:
            reader.error(f'unsupported action {opcode:#04x}')


def observe(path):
    raw = path.read_bytes()
    data, header = unpack_replay(raw)
    reader = Reader(data, 'replay records')
    read_lobby(reader)
    events = []
    time_ms = 0
    while reader.remaining():
        opcode = reader.byte()
        if opcode in (0x1E, 0x1F):
            slot_size, = reader.unpack('<H')
            slot = Reader(reader.take(slot_size), f'time slot after {time_ms} ms')
            time_ms += slot.unpack('<H')[0]
            while slot.remaining():
                player, size = slot.unpack('<BH')
                read_actions(slot.take(size), time_ms, player, events)
        elif opcode == 0x20:
            _, size = reader.unpack('<BH')
            reader.take(size)
        elif opcode == 0x22:
            reader.take(reader.byte())
        elif opcode in RECORD_SIZES:
            reader.take(RECORD_SIZES[opcode])
        elif opcode == 0 and not any(reader.take(reader.remaining())):
            break
        else:
            reader.error(f'unsupported replay record {opcode:#04x}')
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(raw).hexdigest(),
            **header, 'time_slot_ms': time_ms, 'events': events}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('replay', nargs='+', type=Path, help='W3G replay file(s)')
    args = parser.parse_args()
    results = []
    for path in args.replay:
        try:
            results.append(observe(path))
        except (OSError, ValueError, zlib.error) as error:
            print(f'{path}: {error}', file=sys.stderr)
            return 1
    print(json.dumps(results, indent=2, allow_nan=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
