"""Read the owned War3 window's UI Automation tree under an outer OwnedJob deadline."""

import argparse
import ctypes as c
from ctypes import wintypes as w
import json
from pathlib import Path
import uuid

from directed_confirm import desktop_name, input_name, war3_windows
from owned_process import bind, bind_user, require


PROPERTIES = {
    "pid": 30002,
    "control_type": 30003,
    "name": 30005,
    "class_name": 30012,
    "hwnd": 30020,
    "can_invoke": 30031,
    "can_select_item": 30036,
    "provider": 30107,
}
MAX_DEPTH = 5
MAX_NODES = 48


class VariantValue(c.Union):
    _fields_ = [("integer", c.c_int32), ("boolean", c.c_int16),
                ("bstr", c.c_void_p), ("record", c.c_void_p * 2)]


class Variant(c.Structure):
    _fields_ = [("kind", c.c_uint16), ("reserved", c.c_uint16 * 3), ("value", VariantValue)]


def method(pointer, slot, result, *arguments):
    # Slots follow the interfaces in the Windows SDK UIAutomationClient.h.
    vtable = c.cast(pointer, c.POINTER(c.POINTER(c.c_void_p)))[0]
    return c.WINFUNCTYPE(result, c.c_void_p, *arguments)(vtable[slot])


def release(pointer):
    if pointer:
        method(pointer, 2, w.ULONG)(pointer)


def checked(hresult, operation):
    if hresult < 0:
        raise RuntimeError(f"{operation}: HRESULT 0x{hresult & 0xFFFFFFFF:08x}")


def pointer_result(pointer, slot, operation, *args):
    result = c.c_void_p()
    call = method(pointer, slot, c.c_long, *(argtype for argtype, _ in args), c.POINTER(c.c_void_p))
    checked(call(pointer, *(value for _, value in args), c.byref(result)), operation)
    return result


def property_value(element, prop, clear, string_len):
    value = Variant()
    try:
        call = method(element, 10, c.c_long, c.c_int, c.POINTER(Variant))
        checked(call(element, prop, c.byref(value)), f"GetCurrentPropertyValue({prop})")
        if value.kind == 3:  # VT_I4
            return value.value.integer
        if value.kind == 11:  # VT_BOOL
            return bool(value.value.boolean)
        if value.kind == 8:  # VT_BSTR
            return c.wstring_at(value.value.bstr, min(string_len(value.value.bstr), 256)) if value.value.bstr else ""
        return None
    finally:
        clear(c.byref(value))


def accessibility_tree(hwnd, pid):
    ole = c.WinDLL("ole32.dll")
    automation = c.WinDLL("oleaut32.dll")
    ole.CoInitializeEx.argtypes = (c.c_void_p, w.DWORD)
    ole.CoInitializeEx.restype = c.c_long
    ole.CoCreateInstance.argtypes = (c.c_void_p, c.c_void_p, w.DWORD, c.c_void_p, c.POINTER(c.c_void_p))
    ole.CoCreateInstance.restype = c.c_long
    ole.CoUninitialize.argtypes = ()
    ole.CoUninitialize.restype = None
    automation.VariantClear.argtypes = (c.POINTER(Variant),)
    automation.VariantClear.restype = c.c_long
    automation.SysStringLen.argtypes = (c.c_void_p,)
    automation.SysStringLen.restype = w.UINT
    clsid = (c.c_ubyte * 16).from_buffer_copy(uuid.UUID("ff48dba4-60ef-4201-aa87-54103eef594e").bytes_le)
    iid = (c.c_ubyte * 16).from_buffer_copy(uuid.UUID("30cbe57d-d9d0-452a-ab13-7ac5ac4825ee").bytes_le)

    nodes = []
    limits = {"truncated": False, "foreign_nodes_skipped": 0}

    def property_at(element, key):
        return property_value(element, PROPERTIES[key], automation.VariantClear, automation.SysStringLen)

    def walk(walker, element, depth):
        if property_at(element, "pid") != pid:
            if depth == 0:
                raise RuntimeError("UI Automation root belongs to a different PID")
            limits["foreign_nodes_skipped"] += 1
            return
        row = {"depth": depth}
        for key in PROPERTIES:
            try:
                row[key] = property_at(element, key)
            except RuntimeError as exc:
                row.setdefault("property_errors", {})[key] = str(exc)
        nodes.append(row)
        child = pointer_result(walker, 4, "GetFirstChildElement", (c.c_void_p, element))
        while child:
            try:
                if depth >= MAX_DEPTH or len(nodes) + limits["foreign_nodes_skipped"] >= MAX_NODES:
                    limits["truncated"] = True
                    break
                walk(walker, child, depth + 1)
                next_child = pointer_result(walker, 6, "GetNextSiblingElement", (c.c_void_p, child))
            finally:
                release(child)
            child = next_child

    checked(ole.CoInitializeEx(None, 0), "CoInitializeEx (MTA)")
    client, root, walker = c.c_void_p(), None, None
    try:
        checked(ole.CoCreateInstance(clsid, None, 1, iid, c.byref(client)), "CoCreateInstance (CUIAutomation)")
        root = pointer_result(client, 6, "ElementFromHandle", (w.HWND, hwnd))
        walker = pointer_result(client, 16, "RawViewWalker")
        if not root or not walker:
            raise RuntimeError("UI Automation returned no root element or raw-view walker")
        walk(walker, root, 0)
    finally:
        release(walker)
        release(root)
        release(client)
        ole.CoUninitialize()
    return {"raw_view": nodes, **limits}


def observe(args):
    if args.pid <= 0 or not args.desktop.startswith("War3Cold-"):
        raise ValueError("Expected a positive owned PID and a named War3Cold private desktop")
    if args.pid_file.read_text(encoding="utf-8-sig").strip() != str(args.pid):
        raise ValueError("PID does not match the supervisor receipt")

    station = bind_user("GetProcessWindowStation", w.HANDLE)
    current_id = bind("GetCurrentThreadId", w.DWORD)
    thread_desktop = bind_user("GetThreadDesktop", w.HANDLE, w.DWORD)
    window_thread = bind_user("GetWindowThreadProcessId", w.DWORD, w.HWND, c.POINTER(w.DWORD))
    info = {"pid": args.pid, "input_before": input_name(), "station": desktop_name(station()),
            "worker_desktop": desktop_name(thread_desktop(current_id()))}
    if info["station"] != "WinSta0" or info["worker_desktop"] != args.desktop or info["input_before"] == args.desktop:
        raise RuntimeError("Worker is outside the expected non-input desktop")
    matches = war3_windows(args.pid)
    if len(matches) != 1:
        raise RuntimeError(f"Expected one visible owned Warcraft III window, found {len(matches)}")
    hwnd = matches[0]
    owner = w.DWORD()
    tid = require(window_thread(hwnd, c.byref(owner)), "GetWindowThreadProcessId")
    target_desktop = desktop_name(thread_desktop(tid))
    if owner.value != args.pid or target_desktop != args.desktop:
        raise RuntimeError("Target PID or thread desktop changed")
    info.update(hwnd=hwnd, target_gui_thread=tid, target_desktop=target_desktop)
    info.update(accessibility_tree(hwnd, args.pid))
    info["input_after"] = input_name()
    if info["input_after"] != info["input_before"] or war3_windows(args.pid) != [hwnd]:
        raise RuntimeError("Input desktop or target window changed while observing")
    return info


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pid", type=int)
    parser.add_argument("desktop")
    parser.add_argument("--pid-file", required=True, type=Path)
    args = parser.parse_args()
    try:
        info = observe(args)
    except (OSError, RuntimeError, ValueError) as exc:
        info = {"pid": args.pid, "error": str(exc), "win32_error": getattr(exc, "winerror", None)}
    print(json.dumps(info), flush=True)
    return 2 if "error" in info else 0


if __name__ == "__main__":
    raise SystemExit(main())
