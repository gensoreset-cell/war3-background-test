"""Versioned, declarative scenario input for the Warcraft III runner."""

import hashlib
import json
from pathlib import Path
import re


VERSION = "1.0.4"
ROOT = Path(__file__).resolve().parents[3]
SCENARIOS = ROOT / "codexwork/config/war3-test"
LEGACY = ROOT / "codexwork/scripts/war3-65-cold"
RUNTIME = ROOT / "codexwork/temp/w3-cold-a-reclaim-20261113-01"
FORMATS = {
    "wait_receipt": ({"file"}, {"timeout_seconds"}),
    "assert_receipt": ({"file", "contains"}, {"timeout_seconds", "on_missing", "after_input"}),
    "input": ({"action"}, {"point", "sync", "double_message", "clear_point", "neutral_client",
                            "second_point", "second_delay_ms", "settle_seconds", "timeout_seconds"}),
    "heartbeat": ({"seconds"}, {"timeout_seconds"}),
    "capture": (set(), {"timeout_seconds"}),
    "wait_exit": (set(), {"timeout_seconds"}),
    "route_verdict": (set(), set()),
}
KEY_ACTIONS = {
    "confirm", "menu", "dialog-enter", "dialog-space", "dialog-tab", "dialog-nav", "dialog-hotkey",
    "hero-f1", "portal-q", "route-stop", "arrow-down", "arrow-right", "arrow-up", "arrow-left",
    "camera-recenter", "camera-neutral-origin", "camera-private-focus",
}
MOUSE_ACTIONS = {
    "easy", "dialog-mouse", "mouse-move", "hero-select", "hero-double-select", "hero-reselect",
    "hero-reselect-empty", "hero-reselect-drag", "hero-reselect-shift", "hero-select-control",
    "route-attack", "route-move", "minimap-click", "camera-hover-center",
}
CLEAR_ACTIONS = {"hero-reselect-empty", "hero-reselect-drag"}
SLUG = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}\Z")
SHA = re.compile(r"[0-9a-fA-F]{64}\Z")
RECEIPT = re.compile(r"[a-zA-Z0-9_.-]+\.pld(?:\.start)?\Z")


class InvalidConfig(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidConfig(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def fields(value, required, optional, label):
    require(isinstance(value, dict), f"{label} must be an object")
    missing = required - value.keys()
    extras = value.keys() - required - optional
    require(not (missing or extras), f"{label}: missing {sorted(missing)}, unknown {sorted(extras)}")


def number(value, low, high, label):
    require(type(value) in (int, float) and low <= value <= high,
            f"{label} must be a number between {low} and {high}")


def input_step(step, label):
    action = step["action"]
    require(isinstance(action, str) and action in KEY_ACTIONS | MOUSE_ACTIONS,
            f"{label}.action is unsupported")
    for name in ("point", "clear_point", "neutral_client", "second_point"):
        if name in step:
            point = step[name]
            require(isinstance(point, list) and len(point) == 2
                    and all(type(n) is int and 0 <= n < 32768 for n in point),
                    f"{label}.{name} must contain two nonnegative client coordinates")
    for flag in ("sync", "double_message"):
        if flag in step:
            require(type(step[flag]) is bool, f"{label}.{flag} must be boolean")
    if action in MOUSE_ACTIONS - {"easy", "camera-hover-center"}:
        require("point" in step, f"{label} requires point")
    if "point" in step or step.get("sync"):
        require(action in MOUSE_ACTIONS, f"{label}.point and sync require mouse input")
    require(("clear_point" in step) == (action in CLEAR_ACTIONS),
            f"{label}.clear_point is required only for empty-ground reselection")
    if "second_point" in step or step.get("double_message"):
        require(action == "hero-double-select", f"{label} second click options require hero-double-select")
    if "neutral_client" in step:
        require(action == "camera-neutral-origin", f"{label}.neutral_client requires camera-neutral-origin")
    if "second_delay_ms" in step:
        delay = step["second_delay_ms"]
        require(type(delay) is int and 0 <= delay <= 300, f"{label}.second_delay_ms must be 0..300")
        require(action in CLEAR_ACTIONS | {"hero-double-select"},
                f"{label}.second_delay_ms requires double selection or reselection")
    if "settle_seconds" in step:
        number(step["settle_seconds"], 0, 60, f"{label}.settle_seconds")


def scenario_file(request, directory):
    candidate = Path(request)
    if candidate.is_file() or candidate.suffix.lower() == ".json" or len(candidate.parts) > 1:
        return candidate.resolve()
    require(SLUG.fullmatch(request), "Scenario must be a registered name or JSON path")
    return (directory / f"{request}.json").resolve()


def load(path, map_override=None, sha_override=None, timeout_override=None):
    raw = path.read_bytes()
    data = json.loads(raw.decode("utf-8-sig"))
    fields(data, {"version", "name", "map", "timeout_seconds", "steps"}, {"description"}, "scenario")
    require(type(data["version"]) is int and data["version"] == 1, "Scenario version must be 1")
    require(isinstance(data["name"], str) and SLUG.fullmatch(data["name"]), "Invalid scenario name")
    if "description" in data:
        require(isinstance(data["description"], str), "description must be a string")
    fields(data["map"], {"path", "sha256"}, set(), "map")
    require(sha_override is None or map_override is not None, "--sha256 requires --map")
    if map_override is not None:
        data["map"] = {"path": str(map_override.resolve()), "sha256": sha_override}
    map_spec = data["map"]
    require(isinstance(map_spec["path"], str) and map_spec["path"], "map.path must be a file path")
    if map_spec["sha256"] is not None:
        require(isinstance(map_spec["sha256"], str) and SHA.fullmatch(map_spec["sha256"]),
                "map.sha256 must be a SHA-256 hex digest")
    require(map_override is not None or map_spec["sha256"] is not None,
            "Saved scenarios must specify map.sha256. Use --map to pin a temporary selection.")
    target = Path(map_spec["path"])
    # Paths in named and temporary scenarios use the same project-relative convention.
    target = (ROOT / target).resolve(strict=True) if not target.is_absolute() else target.resolve(strict=True)
    require(target.is_file() and target.suffix.lower() in {".w3x", ".w3m"}, "map must be a Warcraft III archive")
    actual = digest(target)
    require(map_spec["sha256"] is None or actual == map_spec["sha256"].lower(),
            f"map SHA-256 differs: actual {actual}")
    data["map"] = {"path": str(target), "sha256": actual}
    if timeout_override is not None:
        data["timeout_seconds"] = timeout_override
    number(data["timeout_seconds"], 10, 7200, "timeout_seconds")
    require(isinstance(data["steps"], list) and 1 <= len(data["steps"]) <= 250,
            "steps must be a nonempty list of up to 250 steps")
    used = {}
    for index, step in enumerate(data["steps"]):
        label = f"step {index + 1}"
        fields(step, {"id", "op"}, set().union(*(a | b for a, b in FORMATS.values())), label)
        operation, identifier = step["op"], step["id"]
        require(isinstance(identifier, str) and SLUG.fullmatch(identifier) and identifier not in used,
                f"{label}.id is invalid or repeated")
        require(isinstance(operation, str) and operation in FORMATS, f"{label}.op is unsupported")
        used[identifier] = operation
        required, optional = FORMATS[operation]
        fields(step, {"id", "op"} | required, optional, label)
        if "timeout_seconds" in step:
            number(step["timeout_seconds"], 0.2, 7200, f"{label}.timeout_seconds")
        if "file" in step:
            name = step["file"]
            require(isinstance(name, str) and RECEIPT.fullmatch(name) and ".." not in name,
                    f"{label}.file must be a single .pld or .pld.start filename")
        if operation == "assert_receipt":
            fragments = step["contains"]
            require(isinstance(fragments, list) and fragments
                    and all(isinstance(text, str) and text for text in fragments),
                    f"{label}.contains must be a nonempty list of strings")
            if "on_missing" in step or "after_input" in step:
                prior = step.get("after_input")
                require(step.get("on_missing") == "input_no_effect" and isinstance(prior, str)
                        and used.get(prior) == "input",
                        f"{label} needs on_missing=input_no_effect and an earlier input step ID in after_input")
        if operation == "input":
            input_step(step, label)
        if operation == "heartbeat":
            number(step["seconds"], 0.1, 7200, f"{label}.seconds")
        if operation == "route_verdict":
            require(index == len(data["steps"]) - 1 and index > 0 and data["steps"][index - 1]["op"] == "wait_exit",
                    "route_verdict must be last and immediately follow wait_exit")
    require(all(step["op"] != "wait_exit" or index == len(data["steps"]) - 1
                or data["steps"][index + 1]["op"] == "route_verdict" for index, step in enumerate(data["steps"])),
            "wait_exit must be last apart from route_verdict")
    return data, hashlib.sha256(raw).hexdigest()
