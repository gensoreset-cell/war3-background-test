"""Cold-start supervision and evidence collection on a non-input desktop."""

from contextlib import suppress
import json
from ntpath import isreserved
from pathlib import Path
import re
import shutil
import stat
import sys
import time
import traceback
import uuid

from war3_test_config import LEGACY, ROOT, SHA, VERSION, digest

sys.path.insert(0, str(LEGACY))
import run as legacy
from directed_confirm import input_name
from owned_process import OwnedJob, PrivateDesktop, process_snapshot
from window_observe import inspect_tga


EXIT_CODES = {"passed": 0, "assertion_failed": 10, "input_invalid": 11, "startup_failed": 12,
              "timeout": 13, "environment_unavailable": 14, "execution_failed": 15,
              "cleanup_failed": 16, "invalid_config": 17, "input_no_effect": 18}
MAP_INPUT = r"bin\Maps\ab65.w3x"
OUTPUT_LOCATIONS = ("Logs", "Screenshots", "Replay", "Errors", "Save", "TempReplay.w3g", "dz_w3_plugin.ini")
OUTPUT_NAMES = frozenset(name.casefold() for name in OUTPUT_LOCATIONS)
RECEIPT_TICK = re.compile(r"desktop-ab-HEARTBEAT-(\d+)\.pld\Z")
HOST_TIMEOUT = 8
ACTION_TIMEOUT = 9
STEP_TIMEOUT = 15
PRELOAD = re.compile(rb'^\s*call\s+Preload\(\s*"((?:[^"\\]|\\.)*)"\s*\)', re.M)


class Failure(Exception):
    def __init__(self, status, message, details=None):
        super().__init__(message)
        self.status = status
        self.details = {} if details is None else details


def runtime_manifest(runtime):
    profile = (runtime / "profile").resolve(strict=True)
    manifest_path = runtime / "inputs.json"
    rows = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    return profile, parse_runtime_inputs(rows)


def parse_runtime_inputs(rows):
    if not isinstance(rows, list) or not rows:
        raise RuntimeError("Runtime inputs.json must be a nonempty manifest")
    manifest = {}
    unique = set()
    canonical = {name.casefold(): name for name in (MAP_INPUT, r"bin\War3.exe", r"bin\Game.dll",
                 r"bin\Lua53Host.exe", r"plugin\warcraft3\yd_loader.dll", r"plugin\warcraft3\config.cfg")}
    for row in rows:
        raw = row["path"]
        parts = re.split(r"[/\\]", raw)
        if any(part in {"", ".", ".."} or ":" in part or isreserved(part) for part in parts):
            raise RuntimeError(f"Invalid relative runtime input: {raw}")
        normalized = tuple(part.casefold() for part in parts)
        if len(normalized) >= 2 and normalized[0] == "bin" and normalized[1] in OUTPUT_NAMES:
            raise RuntimeError(f"Runtime manifest must not seed generated game output: {raw}")
        key = "\\".join(normalized)
        path = canonical.get(key, "\\".join(parts))
        if key in unique or not SHA.fullmatch(row["sha256"]) or type(row["length"]) is not int:
            raise RuntimeError(f"Invalid or duplicate runtime manifest entry: {path}")
        unique.add(key)
        manifest[path] = (row["length"], row["sha256"].lower())
    if not canonical.keys() <= unique:
        raise RuntimeError("Missing mapped archive, client, launcher or KKWE loader manifest entry")
    return manifest


def file_in(root, relative):
    path = root / relative
    if not path.resolve(strict=True).is_relative_to(root) or not path.is_file():
        raise RuntimeError(f"Invalid input file path: {path}")
    for item in (path, *path.parents):
        if item == root:
            break
        if is_reparse_point(item):
            raise RuntimeError(f"Runtime input uses a reparse point: {item}")
    return path


def identity(profile, manifest, map_hash=None):
    values = {}
    for relative, (length, expected) in manifest.items():
        path = file_in(profile, relative)
        if relative == MAP_INPUT and map_hash is not None:
            expected = map_hash
        elif path.stat().st_size != length:
            raise RuntimeError(f"Runtime input size differs: {path}")
        actual = digest(path)
        if actual != expected:
            raise RuntimeError(f"Runtime input SHA-256 differs: {path}")
        values[relative] = actual
    return values


def stage(runtime, map_spec, profile):
    source, manifest = runtime_manifest(runtime)
    # A fresh profile is deliberately populated from the manifest only.
    # Existing saves, logs, replays and launcher settings never enter a cold start.
    path = Path(map_spec["path"])
    profile.mkdir()
    for relative in manifest:
        origin = path if relative == MAP_INPUT else file_in(source, relative)
        target = profile / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(origin, target)
    for name in OUTPUT_LOCATIONS:
        destination = profile / "bin" / name
        if destination.exists() or destination.is_symlink():
            raise RuntimeError(f"Cold-start output path already exists: {destination}")
    return manifest, identity(profile, manifest, map_spec["sha256"])


def environment(runtime, canary=None):
    profile, manifest = runtime_manifest(runtime)
    hashes = identity(profile, manifest)
    active = input_name()
    result = {"tool_version": VERSION, "status": "passed", "mode": "private-desktop", "runtime": str(runtime),
              "runtime_manifest_sha256": digest(runtime / "inputs.json"), "identity": hashes, "input_desktop": active,
              "existing_game_processes": legacy.game_processes(),
              "independent_interactive_cursor": {"available": False,
                                                  "reason": "This transport runs on a Win32 non-input desktop."}}
    with PrivateDesktop() as desktop:
        result["private_desktop"] = {"available": True, "name": desktop, "is_input": desktop.split("\\")[-1] == active}
        if canary is not None:
            canary.mkdir()
            result["canary"] = legacy.desktop_probe(canary, desktop, private=True)
            result["independent_interactive_cursor"]["canary_get_cursor_pos"] = result["canary"]["worker"].get(
                "cursor_query_succeeded")
            result["independent_interactive_cursor"]["canary_win32_error"] = result["canary"]["worker"].get(
                "cursor_query_error")
            if result["canary"]["code"] != 0 or result["canary"]["members_after"]:
                result["status"] = "environment_unavailable"
    result["input_desktop_after"] = input_name()
    if result["input_desktop_after"] != active or result["private_desktop"]["is_input"]:
        result["status"] = "environment_unavailable"
    return result


def current_receipts(profile, skip):
    for path in (profile / "bin/Logs").glob("*.pld*"):
        if path.name in skip or not path.name.endswith((".pld", ".pld.start")):
            continue
        try:
            stamp = path.stat().st_mtime_ns
            with path.open("rb") as stream:
                data = stream.read(1024 * 1024 + 1)
        except OSError as error:
            if getattr(error, "winerror", None) in (2, 32, 33):
                continue
            raise
        # Wait for Warcraft's PreloadGen output to be complete before locking in the receipt.
        if len(data) <= 1024 * 1024 and b"endfunction" in data:
            payloads = PRELOAD.findall(data)
            if payloads:
                decoded = [part.decode("utf-8", errors="replace") for part in payloads]
                yield path.name, "\n".join(decoded), stamp


def is_reparse_point(path):
    return bool(getattr(path.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT)


def archive_inventory(root):
    checks = {}
    for path in root.rglob("*"):
        if is_reparse_point(path):
            raise RuntimeError(f"Cannot archive or remove a reparse point: {path}")
        if path.is_file():
            checks[path.relative_to(root).as_posix()] = digest(path)
    return checks


def heartbeat_span(profile, since_ns):
    samples = {}
    for path in (profile / "bin/Logs").glob("desktop-ab-HEARTBEAT-*.pld"):
        match = RECEIPT_TICK.fullmatch(path.name)
        try:
            stamp = path.stat().st_mtime_ns
            if match and stamp >= since_ns and (b"|tick=" + match[1].encode("ascii") + b'"') in path.read_bytes():
                samples[int(match[1])] = stamp
        except OSError as error:
            if getattr(error, "winerror", None) not in (2, 32, 33):
                raise
    longest, previous_tick, previous_ns = [], None, None
    current = []
    for tick, stamp in sorted(samples.items()):
        if previous_tick is not None and (tick != previous_tick + 1 or not 0 < stamp - previous_ns <= 2_800_000_000):
            current = []
        current.append((tick, stamp))
        if len(current) > len(longest):
            longest = current.copy()
        previous_tick, previous_ns = tick, stamp
    span = (longest[-1][1] - longest[0][1]) / 1_000_000_000 if longest else 0
    return {"samples": len(longest), "seconds": span, "first_tick": longest[0][0] if longest else None,
            "last_tick": longest[-1][0] if longest else None, "max_gap_seconds": 2.8}


class Trial:
    def __init__(self, evidence, profile, config, result):
        self.evidence, self.profile, self.config, self.result = evidence, profile, config, result
        self.started = time.monotonic()
        self.deadline = self.started + config["timeout_seconds"]
        self.receipts = {}
        self.observed_utc = {}
        self.last_poll = self.last_scan = 0
        self.current = None

    def elapsed(self):
        return round(time.monotonic() - self.started, 3)

    def save(self):
        legacy.write_json(self.evidence / "result.json", self.result)

    def poll(self, force=False):
        now = time.monotonic()
        if input_name() != self.result["input_desktop_before"]:
            raise Failure("environment_unavailable", "Windows input desktop changed during the run")
        if self.job.poll() is None and (force or now - self.last_poll >= 0.2):
            with suppress(BrokenPipeError):
                self.job.send("poll")
            self.last_poll = now
        if force or now - self.last_scan >= 0.2:
            for name, message, stamp in current_receipts(self.profile, self.receipts):
                self.receipts[name] = message
                self.observed_utc[name] = stamp
                self.result["events"].append({"file": name, "message": message, "elapsed": self.elapsed()})
            self.last_scan = now

    def remaining(self, limit):
        remain = limit - time.monotonic()
        if remain <= 0:
            if time.monotonic() >= self.deadline:
                self.result["global_timeout"] = True
                raise Failure("timeout", "Cold-start run deadline expired")
        return remain

    def until(self, limit, probe, status, reason, details=None, allow_exit=False):
        while self.remaining(limit) > 0:
            self.poll()
            answer = probe()
            if answer is not None:
                return answer
            if not allow_exit and self.job.poll() is not None:
                self.poll(force=True)
                answer = probe()
                if answer is not None:
                    return answer
                raise Failure("startup_failed" if not self.result["actions"] else "execution_failed",
                              "Owned game exited before the requested step completed",
                              {"game_exit": legacy.read_receipts(self.evidence)[1], "host_exit": self.job.poll()})
            time.sleep(min(0.15, max(0, limit - time.monotonic())))
        raise Failure(status, reason, details() if callable(details) else details)

    def action(self, step, limit, label):
        pid = self.result["game_pid"]
        if pid not in self.job.pids():
            raise Failure("input_invalid", "The target game PID has left its owning job")
        command = [sys.executable, "-B", LEGACY / "directed_confirm.py", str(pid),
                   self.result["desktop"].split("\\")[-1], "--action", step["action"]]
        for field in ("point", "clear_point", "neutral_client", "second_point", "second_delay_ms"):
            if field in step:
                value = step[field]
                command.extend([f"--{field.replace('_', '-')}", *(str(n) for n in value)] if isinstance(value, list)
                               else [f"--{field.replace('_', '-')}", str(value)])
        for flag in ("sync", "double_message"):
            if step.get(flag):
                command.append(f"--{flag.replace('_', '-')}")
        started = self.elapsed()
        with OwnedJob(command, self.evidence, self.result["desktop"], self.evidence, label=label) as worker:
            code = worker.poll(max(0.01, self.remaining(limit)))
            worker_members = worker.pids()
            if worker_members:
                worker.reap(2)
            worker_members_after = worker.pids()
        stdout = self.evidence / f"{label}-stdout.log"
        raw = stdout.read_text(encoding="utf-8")
        with suppress(json.JSONDecodeError):
            raw = json.loads(raw)
        record = {"action": step["action"], "elapsed": started, "finished_elapsed": self.elapsed(),
                  "code": code, "worker": raw if isinstance(raw, dict) else None,
                  "worker_members_after": worker_members_after,
                  "stdout": stdout.name, "stderr": f"{label}-stderr.log"}
        self.result["actions"].append(record)
        if worker_members_after:
            raise Failure("cleanup_failed", "Owned input worker still has live processes", record)
        if self.remaining(limit) <= 0 and code is None:
            raise Failure("timeout", "The guarded input worker exceeded its step budget", record)
        if code != 0 or not record["worker"]:
            raise Failure("input_invalid", "The guarded input worker could not deliver the action", record)
        if step.get("settle_seconds"):
            target = time.monotonic() + step["settle_seconds"]
            self.until(limit, lambda: True if time.monotonic() >= target else None,
                       "timeout", "Input settling period exceeded the step budget")
        return record

    def receipt(self, step, limit):
        filename = step["file"]
        expected = step.get("contains", [])

        def observed():
            if filename not in self.receipts:
                self.retry_continue(filename, limit)
                return None
            actual = self.receipts[filename]
            details = {"file": filename, "actual": actual, "expected_fragments": expected,
                       "receipt_state": "observed"}
            if any(fragment not in actual for fragment in expected):
                details["receipt_state"] = "mismatch"
                raise Failure("assertion_failed", "The native receipt did not match", details)
            return details

        status = "assertion_failed" if step["op"] == "assert_receipt" else "timeout"
        missing = {"file": filename, "expected_fragments": expected, "receipt_state": "missing"}
        if step.get("on_missing") == "input_no_effect":
            previous = next(row for row in self.result["steps"] if row["id"] == step["after_input"])
            action = previous.get("details", {})
            worker = action.get("worker", {})
            posted = worker.get("posted", [])
            if (previous["status"] == "passed" and action.get("code") == 0 and
                    worker.get("pid") == self.result["game_pid"] and posted and all(item["ok"] for item in posted)):
                status = "input_no_effect"
                missing.update(after_input_step=previous["id"], delivered_action=action["action"],
                               input_worker_stdout=action["stdout"])
        try:
            return self.until(limit, observed, status, f"Missing native receipt {filename}", missing)
        except Failure as error:
            if self.result.get("global_timeout") and filename not in self.receipts:
                error.details.update(missing)
            raise

    def retry_continue(self, filename, limit):
        # The legacy loader can accept a first Space before the prompt becomes actionable.
        # Only retry once while both post-load signals are still absent.
        actions = self.result["actions"]
        if (filename not in {"dialog-shown.pld", "desktop-ab-HEARTBEAT-1.pld"} or not actions
                or actions[-1]["action"] != "confirm" or any(row.get("automatic_retry") for row in actions)
                or "dialog-shown.pld" in self.receipts or "desktop-ab-HEARTBEAT-1.pld" in self.receipts
                or self.elapsed() - actions[-1]["finished_elapsed"] < 4 or limit - time.monotonic() < 1):
            return
        self.poll(force=True)
        if "dialog-shown.pld" not in self.receipts and "desktop-ab-HEARTBEAT-1.pld" not in self.receipts:
            record = self.action({"action": "confirm"}, min(limit, time.monotonic() + 2), "retry-continue")
            record["automatic_retry"] = True

    def capture(self, step, limit, label):
        folder = self.profile / "bin/Screenshots"
        old = {path.name for path in folder.glob("*.tga")}
        self.action({"action": "game-screenshot"}, limit, label)

        def observed():
            for path in sorted(folder.glob("*.tga")):
                if path.name in old:
                    continue
                try:
                    info = inspect_tga(path, self.evidence / f"{step['id']}.bmp")
                except (ValueError, OSError):
                    continue
                if info["nonblank_client"]:
                    info["file"] = f"game-output/Screenshots/{path.name}"
                    return info
            return None

        return self.until(limit, observed, "assertion_failed", "No valid nonblank native screenshot")

    def natural_exit(self, limit, verify=True):
        def exited():
            code = self.job.poll()
            if code is None:
                return None
            return {"game_exit": legacy.read_receipts(self.evidence)[1], "host_exit": code}

        details = self.until(limit, exited, "timeout", "The game did not exit through the native menu", allow_exit=True)
        if verify and not (details["game_exit"] == ["natural", 0] and details["host_exit"] == 0):
            raise Failure("assertion_failed", "Natural zero-code game and host exit required", details)
        return details

    def apply_step(self, step, number):
        op = step["op"]
        label = f"step-{number:03d}-{step['id']}"
        default = ACTION_TIMEOUT if op in {"input", "capture"} else STEP_TIMEOUT
        limit = min(self.deadline, time.monotonic() + step.get("timeout_seconds", default))
        row = {"id": step["id"], "op": op, "status": "running", "started_elapsed": self.elapsed()}
        self.current = step
        self.result["steps"].append(row)
        self.save()
        try:
            if op in {"wait_receipt", "assert_receipt"}:
                row["details"] = self.receipt(step, limit)
            elif op == "input":
                row["details"] = self.action(step, limit, label)
            elif op == "capture":
                row["details"] = self.capture(step, limit, label)
            elif op == "heartbeat":
                after = time.time_ns()

                def sample():
                    best = heartbeat_span(self.profile, after)
                    return best if best["seconds"] >= step["seconds"] else None

                row["details"] = self.until(limit, sample, "assertion_failed", "Continuous heartbeat below target",
                                            lambda: heartbeat_span(self.profile, after))
            elif op == "wait_exit":
                row["details"] = self.natural_exit(limit)
            else:
                row["status"] = "pending_finalization"
                return
            row["status"] = "passed"
        except Failure as error:
            row.update(status=error.status, error=str(error), details=error.details)
            self.result["failed_step"] = step["id"]
            raise
        finally:
            row["finished_elapsed"] = self.elapsed()
            self.save()

    def close_job(self):
        cleanup = self.result["cleanup"]
        if self.job.poll() is None and self.result.get("status") in {
                "assertion_failed", "input_invalid", "input_no_effect", "timeout"}:
            menu_already_sent = any(row["action"] == "menu" for row in self.result["actions"])
            heartbeat = max((stamp for name, stamp in self.observed_utc.items() if RECEIPT_TICK.fullmatch(name)), default=0)
            budget = min(self.deadline - time.monotonic(), 8)
            if not menu_already_sent and (time.time_ns() - heartbeat) < 3_000_000_000 and budget >= 3.5:
                try:
                    limit = time.monotonic() + budget
                    self.action({"action": "menu"}, limit, "cleanup-menu")
                    cleanup["menu"] = self.natural_exit(limit)
                except (Failure, OSError) as error:
                    cleanup["menu_error"] = str(error)
        if self.job.poll() is None:
            try:
                self.job.send("timeout-stop")
                self.result["timeout_sent"] = True
                cleanup["timeout_stop"] = True
            except BrokenPipeError:
                cleanup["timeout_stop"] = False
        self.result["host_exit"] = self.job.poll(8)
        if legacy.idle(self.job, 2)["active"]:
            cleanup["forced_owned_job_reap"] = self.job.reap(2)
            self.result["forced_job_reap"] = cleanup["forced_owned_job_reap"]
        self.result["members_after"] = self.job.pids()
        cleanup["job_accounting"] = self.job.accounting()
        self.result["game_exit"] = legacy.read_receipts(self.evidence)[1]
        with suppress(Failure, OSError):
            self.poll(force=True)

    def execute(self):
        matches = legacy.game_processes()
        if matches:
            raise Failure("environment_unavailable", "Another game, editor or launcher process is active", matches)
        host, argv, env = legacy.host_settings(self.evidence, self.profile, "game")
        self.result["client_argv"] = argv
        self.result["runtime_host_argv"] = [str(part) for part in host]
        self.save()
        try:
            job = OwnedJob(host, self.profile, self.result["desktop"], self.evidence, env)
        except OSError as error:
            raise Failure("startup_failed", f"Cannot launch the isolated runtime: {error}") from error
        with job:
            self.job = job
            self.result["host_pid"] = job.pid
            try:
                try:
                    self.result["game_pid"] = legacy.wait_pid(self.job, self.evidence,
                                                              min(HOST_TIMEOUT, self.remaining(self.deadline)))
                except (OSError, RuntimeError) as error:
                    self.remaining(self.deadline)
                    raise Failure("startup_failed", str(error)) from error
                self.result["initial_job_members"] = self.job.pids()
                for number, step in enumerate(self.config["steps"], 1):
                    self.apply_step(step, number)
                # A naturally closed game is part of every passing scenario, even if omitted from its steps.
                self.natural_exit(min(self.deadline, time.monotonic() + 2))
                self.result["status"] = "passed"
            except Failure as error:
                self.result.update(status=error.status, error=str(error), error_details=error.details)
            except Exception as error:
                self.result.update(status="execution_failed", error=repr(error), traceback=traceback.format_exc())
                if self.current:
                    self.result["failed_step"] = self.current["id"]
            finally:
                self.close_job()


def run_scenario(evidence, runtime, config, result):
    build = ROOT / "codexwork/build/war3-test"
    profile = build / f"profile-{uuid.uuid4().hex}"
    result.update(profile=str(profile), started_utc=legacy.utc(), mode="private-desktop",
                  phase="preflight", map_sha256=config["map"]["sha256"], steps=[], actions=[], events=[], failed_step=None,
                  cleanup={"desktop_opened": False, "desktop_closed": False, "profile_removed": False})
    trial = None
    manifest = None
    staged_identity = None
    try:
        legacy.write_json(evidence / "result.json", result)
        build.mkdir(parents=True, exist_ok=True)
        if build.resolve(strict=True) != build:
            raise Failure("environment_unavailable", "Build directory resolved outside its project path")
        result["input_desktop_before"] = input_name()
        with legacy.exclusive_game():
            matches = legacy.game_processes()
            if matches:
                raise Failure("environment_unavailable", "Another game, editor or launcher process is active", matches)
            deferred = None
            with PrivateDesktop() as desktop:
                result["desktop"] = desktop
                result["cleanup"]["desktop_opened"] = True
                try:
                    if desktop.split("\\")[-1] == result["input_desktop_before"]:
                        raise Failure("environment_unavailable", "Private test desktop is the active input desktop")
                    try:
                        result["phase"] = "staging"
                        legacy.write_json(evidence / "result.json", result)
                        result["map_source_before_sha256"] = digest(Path(config["map"]["path"]))
                        if result["map_source_before_sha256"] != config["map"]["sha256"]:
                            raise RuntimeError("Source map changed since config validation")
                        manifest, staged_identity = stage(runtime, config["map"], profile)
                    except (RuntimeError, OSError, ValueError, KeyError, TypeError) as error:
                        raise Failure("environment_unavailable", f"Cannot stage verified cold-start inputs: {error}") from error
                    result["identity"] = staged_identity
                    result["runtime_manifest_sha256"] = digest(runtime / "inputs.json")
                    result["phase"] = "game"
                    trial = Trial(evidence, profile, config, result)
                    trial.execute()
                except Failure as error:
                    deferred = error
            result["cleanup"]["desktop_closed"] = True
            if deferred:
                raise deferred
    except Failure as error:
        result.update(status=error.status, error=str(error), error_details=error.details)
    except (RuntimeError, OSError) as error:
        result.update(status="execution_failed" if trial else "environment_unavailable",
                      error=repr(error), traceback=traceback.format_exc())
    finally:
        result["phase"] = "cleanup"
        finalize(evidence, build, profile, manifest, staged_identity, result, config, trial)
    return result


def finalize(evidence, build, profile, manifest, staged_identity, result, config, trial):
    cleanup = result["cleanup"]
    errors = cleanup.setdefault("errors", [])
    result["finished_utc"] = legacy.utc()
    if trial:
        result["elapsed_seconds"] = trial.elapsed()
    try:
        result["input_desktop_after"] = input_name()
        if result.get("input_desktop_before") and result["input_desktop_after"] != result["input_desktop_before"]:
            errors.append("Input desktop changed")
        result["map_source_after_sha256"] = digest(Path(config["map"]["path"]))
        result["hashes_after_match"] = result["map_source_after_sha256"] == config["map"]["sha256"]
        if manifest is not None:
            result["hashes_after_match"] &= staged_identity == identity(profile, manifest, config["map"]["sha256"])
        if not result["hashes_after_match"]:
            errors.append("Map or staged input hashes changed")
    except (RuntimeError, OSError) as error:
        result["hashes_after_match"] = False
        errors.append(str(error))
    try:
        if cleanup["desktop_opened"] and not cleanup["desktop_closed"]:
            errors.append("Private desktop close was not confirmed")
        if result.get("status") == "passed" and result.get("forced_job_reap"):
            errors.append("Natural exit left owned child processes requiring reap")
        if profile.exists():
            raw = {}
            for part in ("Logs", "Replay", "Errors", "Screenshots"):
                folder = profile / "bin" / part
                if folder.exists():
                    if is_reparse_point(folder):
                        raise RuntimeError(f"Cannot archive a reparse point: {folder}")
                    raw.update({f"{part}/{name}": value for name, value in archive_inventory(folder).items()})
            result["raw_evidence"] = legacy.archive_game_outputs(evidence, profile)
            temporary = profile / "bin/TempReplay.w3g"
            if temporary.is_file():
                if is_reparse_point(temporary):
                    raise RuntimeError(f"Cannot archive a reparse point: {temporary}")
                raw[temporary.name] = digest(temporary)
                shutil.copy2(temporary, evidence / "game-output/TempReplay.w3g")
            if raw != archive_inventory(evidence / "game-output"):
                raise RuntimeError("Archive copy failed content verification")
            cleanup["archive_verified_files"] = len(raw)
        baseline = set(result.get("initial_job_members", [])) | {result.get("game_pid"), result.get("host_pid")}
        result["remaining_game_processes"] = [row for row in process_snapshot() if row["pid"] in baseline]
        if result["remaining_game_processes"] or result.get("members_after"):
            errors.append("Owned processes remain after supervision")
        if profile.exists() and not result["remaining_game_processes"] and not result.get("members_after"):
            resolved = profile.resolve(strict=True)
            if resolved.parent != build.resolve(strict=True) or resolved.name != profile.name:
                raise RuntimeError("Refusing cleanup outside the new isolated profile")
            if is_reparse_point(profile) or any(is_reparse_point(path) for path in profile.rglob("*")):
                raise RuntimeError("Refusing cleanup with a symlink or other reparse point")
            shutil.rmtree(resolved)
            cleanup["profile_removed"] = not profile.exists()
    except (RuntimeError, OSError) as error:
        errors.append(str(error))
    if errors:
        result.update(primary_status=result.get("status"), status="cleanup_failed")
    if trial and config["steps"][-1]["op"] == "route_verdict" and result.get("raw_evidence"):
        try:
            from route_verdict import evaluate

            verdict = result["route_verdict"] = evaluate(result, evidence)
            if result["status"] == "passed":
                row = result["steps"][-1]
                row["details"] = verdict
                row["status"] = "passed" if verdict["passed"] else "assertion_failed"
                if not verdict["passed"]:
                    result.update(status="assertion_failed", failed_step=row["id"],
                                  error="Strict native route evidence was incomplete")
        except (OSError, RuntimeError, ValueError, KeyError, ImportError) as error:
            result["route_verdict_error"] = repr(error)
            if result["status"] == "passed":
                row = result["steps"][-1]
                row.update(status="execution_failed", error=repr(error))
                result.update(status="execution_failed", failed_step=row["id"], error=repr(error))
    result["exit_code"] = EXIT_CODES[result["status"]]
    result["phase"] = "finished"
    result["terminal"] = True
    legacy.write_json(evidence / "result.json", result)
