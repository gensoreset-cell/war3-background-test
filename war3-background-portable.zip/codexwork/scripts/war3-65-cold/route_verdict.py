"""Read a sealed Warcraft III 65 route and report which acceptance checks passed."""

import argparse
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
import json
from pathlib import Path
import re


NATIVE_LOG = re.compile(rb'^\s*call Preload\(\s*"AB65\|([^"\r\n]+)"\s*\)', re.M)
HOST_PID = re.compile(rb"^M1_LEGACY_JAPI_OWNED_PID\t(\d+)\r?$", re.M)
HOST_EXIT = re.compile(rb"^M1_LEGACY_JAPI_OWNED_EXIT\t([^\t\r\n]+)\t(\d+)\r?$", re.M)
MENU_KEYS = (0x79, 0x45, 0x58, 0x58)
MENU_NAMES = ("f10", "e", "x", "x")
MAX_HEARTBEAT_GAP_NS = 2_800_000_000  # Same one-second heartbeat tolerance as dialog_trial.py.
MIN_HEARTBEAT_SPAN_NS = 60_000_000_000


@dataclass(frozen=True)
class Receipt:
    path: Path
    stamp_ns: int
    fields: dict[str, str]

    def matches(self, **expected):
        return all(self.fields.get(name) == value for name, value in expected.items())

    def game_time(self):
        tick = self.fields.get("tick", "")
        fraction = self.fields.get("fraction", "")
        if not tick.isdecimal() or not re.fullmatch(r"(?:0\.\d{3}|1\.000)", fraction):
            return None
        return Decimal(tick) + Decimal(fraction)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_receipts(logs):
    receipts = {}
    for path in logs.glob("*.pld"):
        messages = NATIVE_LOG.findall(path.read_bytes())
        if len(messages) != 1:
            continue
        name, *parts = messages[0].decode("ascii").split("|")
        expected = path.stem.removeprefix("desktop-ab-")
        if name != expected or not all("=" in part for part in parts):
            continue
        pairs = [part.split("=", 1) for part in parts]
        fields = dict(pairs)
        if len(fields) == len(parts):
            receipts[name] = Receipt(path, path.stat().st_mtime_ns, fields)
    return receipts


def numbered(receipts, prefix):
    rows = []
    for name, receipt in receipts.items():
        if name.startswith(prefix) and (suffix := name[len(prefix):]).isdecimal():
            rows.append((int(suffix), receipt))
    return sorted(rows, key=lambda row: row[0])


def same_unit(first, second):
    unit_id = first.fields.get("id", "")
    return unit_id.isdecimal() and second.matches(type="H005", owner="15", id=unit_id)


def nearest_coordinates(receipt, x, y):
    # Warcraft snaps the generated coordinates to the map's unit placement grid.
    fields = receipt.fields
    if not all(re.fullmatch(r"-?\d+(?:\.\d+)?", fields.get(axis, "")) for axis in ("x", "y")):
        return False
    return abs(Decimal(fields["x"]) - x) <= 1 and abs(Decimal(fields["y"]) - y) <= 1


def selection_checks(receipts, difficulty):
    selections = numbered(receipts, "route-selection-")
    arms = [record for _, record in numbered(receipts, "route-selection-arm-")]
    expiry = [record for _, record in numbered(receipts, "route-selection-expired-")]
    candidates = [record for _, record in selections if record.matches(source="unit-selection", mode="select")
                  and (difficulty is None or record.stamp_ns >= difficulty.stamp_ns)]
    neutral = next((record for record in candidates if record.matches(type="H005", owner="15")), None)
    pair = None
    confirmation = None
    for first, second in zip(candidates, candidates[1:]):
        begin, end = first.game_time(), second.game_time()
        if not first.matches(type="H005", owner="15") or not same_unit(first, second):
            continue
        if begin is None or end is None or not 0 <= end - begin <= Decimal("0.500"):
            continue
        pair = pair or (first, second)
        for arm in arms:
            timer = arm.fields.get("timer", "")
            if not (timer.isdecimal() and arm.matches(source="hero-selection") and same_unit(first, arm)
                    and arm.game_time() == begin):
                continue
            for expired in expiry:
                if not (expired.matches(source="hero-timer", timer=timer, committed="1")
                        and same_unit(first, expired) and expired.game_time() is not None):
                    continue
                # Game timestamps print three fractional digits. Check the timer to that precision.
                duration = expired.game_time() - begin
                if Decimal("0.499") <= duration <= Decimal("0.501") and end <= expired.game_time():
                    confirmation = (first, second, arm, expired)
                    return neutral, (first, second), confirmation, selections
    return neutral, pair, confirmation, selections


def heartbeat_after_spawn(receipts, spawn):
    if spawn is None:
        return [], 0
    best = []
    current = []
    best_span = 0
    for tick, receipt in numbered(receipts, "HEARTBEAT-"):
        if not receipt.matches(tick=str(tick)) or receipt.stamp_ns < spawn.stamp_ns:
            continue
        if current:
            previous_tick, previous = current[-1]
            gap = receipt.stamp_ns - previous.stamp_ns
            if tick != previous_tick + 1 or not 0 < gap <= MAX_HEARTBEAT_GAP_NS:
                current.clear()
        current.append((tick, receipt))
        span = receipt.stamp_ns - current[0][1].stamp_ns
        if not best or span > best_span:
            best = current.copy()
            best_span = span
    return best, best_span


def background_desktop(trial):
    mode = trial.get("mode")
    start, end, desktop = (trial.get(name) for name in ("input_desktop_before", "input_desktop_after", "desktop"))
    if desktop == r"WinSta0\Default" or mode == "manual-default":
        return "foreground"
    if mode in (None, "private-desktop") and start and start == end and isinstance(desktop, str):
        station, _, name = desktop.partition("\\")
        if station.casefold() == "winsta0" and name and name.casefold() != start.casefold():
            return "background"
    return "unverified"


def posted_keys(trial, action):
    game_pid = trial.get("game_pid")
    for request in trial.get("actions", []):
        worker = request.get("worker") or {}
        if request.get("action") != action or request.get("code") != 0 or worker.get("pid") != game_pid:
            continue
        messages = worker.get("posted", [])
        if messages and all(message.get("ok") is True for message in messages):
            down = tuple(message.get("virtual_key") for message in messages if message.get("message") == 0x100)
            up = tuple(message.get("virtual_key") for message in messages if message.get("message") == 0x101)
            if down == up:
                yield down, request.get("elapsed")


def foreground_keys(run, trial):
    log = run / "foreground-actions.jsonl"
    if background_desktop(trial) != "foreground" or not log.is_file():
        return []
    started = datetime.fromisoformat(trial["started_utc"])
    finished = datetime.fromisoformat(trial["finished_utc"])
    keys = []
    for line in log.read_text(encoding="utf-8-sig").splitlines():
        row = json.loads(line)
        if row.get("type") == "key" and row.get("phase") == "returned":
            stamp = datetime.fromisoformat(row["utc"])
            if started <= stamp <= finished:
                keys.append((row["key"].casefold(), round(stamp.timestamp() * 1_000_000_000)))
    return keys


def input_evidence(run, trial, shown, portaled):
    keys = foreground_keys(run, trial)
    names = [key for key, _ in keys]
    has_menu = (any(sequence == MENU_KEYS for sequence, _ in posted_keys(trial, "menu"))
                or tuple(names[-4:]) == MENU_NAMES)
    if shown is None or portaled is None:
        return False, has_menu
    observed = {event.get("file"): event.get("elapsed") for event in trial.get("events", [])}
    dialog_at = observed.get(shown.path.name)
    teleport_at = observed.get(portaled.path.name)
    has_posted_q = (dialog_at is not None and teleport_at is not None
                    and any(sequence == (0x51,) and at is not None and dialog_at <= at <= teleport_at
                            for sequence, at in posted_keys(trial, "portal-q")))
    has_q = has_posted_q or any(key == "q" and shown.stamp_ns <= stamp <= portaled.stamp_ns for key, stamp in keys)
    return has_q, has_menu


def process_evidence(run, trial):
    log = run / "host-stdout.log"
    owned = run / "owned-pid.txt"
    raw = log.read_bytes() if log.is_file() else b""
    pids = HOST_PID.findall(raw)
    exits = HOST_EXIT.findall(raw)
    game_pid = trial.get("game_pid")
    host_pid = trial.get("host_pid")
    initial = trial.get("initial_job_members") or []
    host_exit = [exits[0][0].decode("ascii"), int(exits[0][1])] if len(exits) == 1 else None
    identity = (
        isinstance(game_pid, int) and game_pid > 0 and len(pids) == 1 and int(pids[0]) == game_pid
        and owned.is_file() and owned.read_text(encoding="ascii").strip() == str(game_pid)
        and isinstance(host_pid, int) and host_pid > 0 and host_pid != game_pid
        and game_pid in initial and host_pid in initial
    )
    clean = (identity and trial.get("members_after") == [] and trial.get("remaining_game_processes") == []
             and not trial.get("forced_job_reap"))
    return host_exit, clean


def evaluate(trial, run):
    """Evaluate a closed run with original logs archived at game-output/Logs."""
    if not trial.get("finished_utc"):
        raise ValueError("Trial must be sealed and have finished_utc")
    receipts = read_receipts(run / "game-output" / "Logs")
    difficulty = receipts.get("dialog-chosen")
    hard = difficulty is not None and difficulty.matches(source="dialog", index="2", value="5")
    neutral, pair, confirmation, selections = selection_checks(receipts, difficulty)
    chosen = receipts.get("route-hero-chosen")
    chose_hero = chosen is not None and chosen.matches(source="selection", type="H005")
    spawn = None
    if chose_hero and confirmation:
        second_select = confirmation[1]
        spawn = next((record for _, record in selections
                      if record.matches(source="unit-selection", mode="select", type="H005", owner="0")
                      and record.stamp_ns >= max(chosen.stamp_ns, second_select.stamp_ns)
                      and record.fields.get("id", "").isdecimal()
                      and record.fields["id"] != second_select.fields["id"]
                      and nearest_coordinates(record, Decimal("29109.70"), Decimal("-30405.00"))), None)
    shown = receipts.get("route-portal-shown")
    region = (spawn is not None and shown is not None and shown.stamp_ns >= spawn.stamp_ns
              and shown.matches(source="region", region="035"))
    portaled = receipts.get("route-portal-q")
    arrival = (region and portaled is not None and portaled.stamp_ns >= shown.stamp_ns
               and portaled.matches(source="dialog", index="1")
               and nearest_coordinates(portaled, Decimal("29110"), Decimal("-25253")))
    has_q, has_menu = input_evidence(run, trial, shown, portaled)
    wolf = None
    if arrival and has_q:
        for _, record in numbered(receipts, "route-gray-wolf-"):
            before, after = (record.fields.get(name, "") for name in ("before", "after"))
            if (record.stamp_ns >= portaled.stamp_ns and record.matches(source="death", victim="n03X", killer="H005", task="1")
                    and before.isdecimal() and after.isdecimal() and int(after) > int(before)):
                wolf = record
                break
    beats, span_ns = heartbeat_after_spawn(receipts, spawn)
    host_exit, clean = process_evidence(run, trial)
    exit_ok = (has_menu and trial.get("game_exit") == host_exit == ["natural", 0]
               and trial.get("host_exit") == 0 and not trial.get("timeout_sent"))
    desktop = background_desktop(trial)
    isolated_inputs = trial.get("hashes_after_match") is True

    checks = {}

    def check(name, passed, *records, **detail):
        paths = [record.path.relative_to(run).as_posix() for record in records if record is not None]
        checks[name] = {"passed": bool(passed), "receipts": paths, **detail}

    check("native_hard_difficulty", hard, difficulty)
    check("first_neutral_h005_selection", neutral is not None, neutral)
    check("second_neutral_h005_within_window", pair is not None, *(pair or ()),
          game_seconds=float(pair[1].game_time() - pair[0].game_time()) if pair else None)
    expiration = [row for _, row in numbered(receipts, "route-selection-expired-")]
    timer_receipts = confirmation[2:] if confirmation else expiration
    check("native_selection_committed", confirmation is not None, *timer_receipts,
          observed_committed=[row.fields.get("committed") for row in expiration])
    check("player_zero_h005_spawned", spawn is not None, chosen, spawn)
    check("entered_region_035", region, shown)
    check("native_q_teleport", arrival and has_q, portaled, q_input_observed=has_q)
    check("gray_wolf_death_and_task_one_increment", wolf is not None, wolf,
          before=int(wolf.fields["before"]) if wolf else None, after=int(wolf.fields["after"]) if wolf else None)
    check("post_spawn_heartbeat_60_seconds", span_ns >= MIN_HEARTBEAT_SPAN_NS,
          *(row for _, row in beats), count=len(beats), first_tick=beats[0][0] if beats else None,
          last_tick=beats[-1][0] if beats else None, seconds=round(span_ns / 1_000_000_000, 3))
    check("native_menu_exit", exit_ok, menu_input_observed=has_menu, trial_game_exit=trial.get("game_exit"),
          raw_game_exit=host_exit, host_exit=trial.get("host_exit"), timeout_sent=trial.get("timeout_sent", False))
    check("owned_processes_exited", clean, members_after=trial.get("members_after"),
          remaining_game_processes=trial.get("remaining_game_processes"))
    check("isolated_background_desktop", desktop == "background", desktop_type=desktop,
          desktop=trial.get("desktop"), input_before=trial.get("input_desktop_before"),
          input_after=trial.get("input_desktop_after"))
    check("staged_inputs_unchanged", isolated_inputs, map_sha256=trial.get("map_sha256"))
    first_missing = next((name for name, detail in checks.items() if not detail["passed"]), None)
    return {"run": str(run), "passed": first_missing is None, "first_missing": first_missing, "checks": checks}


def verdict(run):
    historical = run / "trial.json"
    summary = historical if historical.is_file() else run / "result.json"
    return evaluate(read_json(summary), run)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path, help="sealed run directory containing trial.json or result.json, and game-output")
    args = parser.parse_args()
    try:
        result = verdict(args.run.resolve())
    except (OSError, ValueError, KeyError) as error:
        parser.exit(2, f"Cannot read sealed route: {error}\n")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
