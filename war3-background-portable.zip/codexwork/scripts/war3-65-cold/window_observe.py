"""Read the geometry, GUI thread state and optional client pixels of owned War3."""

import argparse
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
from pathlib import Path
import struct
import time

from directed_confirm import desktop_name, input_name, war3_windows
from owned_process import bind, bind_user, require


class GuiThreadInfo(c.Structure):
    _fields_ = [("size", w.DWORD), ("flags", w.DWORD)] + [
        (name, w.HWND) for name in ("active", "focus", "capture", "menu_owner", "move_size", "caret")
    ] + [("caret_rect", w.RECT)]


class ThumbnailProperties(c.Structure):
    _fields_ = [("flags", w.DWORD), ("destination", w.RECT), ("source", w.RECT),
                ("opacity", w.BYTE), ("visible", w.BOOL), ("client_only", w.BOOL)]


def window_state(hwnd, thread):
    get_client_rect = bind_user("GetClientRect", w.BOOL, w.HWND, c.POINTER(w.RECT))
    get_window_rect = bind_user("GetWindowRect", w.BOOL, w.HWND, c.POINTER(w.RECT))
    client_to_screen = bind_user("ClientToScreen", w.BOOL, w.HWND, c.POINTER(w.POINT))
    get_dpi = bind_user("GetDpiForWindow", w.UINT, w.HWND)
    get_thread_dpi = bind_user("GetThreadDpiAwarenessContext", w.HANDLE)
    get_window_dpi = bind_user("GetWindowDpiAwarenessContext", w.HANDLE, w.HWND)
    dpi_awareness = bind_user("GetAwarenessFromDpiAwarenessContext", c.c_int, w.HANDLE)
    get_gui = bind_user("GetGUIThreadInfo", w.BOOL, w.DWORD, c.POINTER(GuiThreadInfo))
    get_cursor = bind_user("GetCursorPos", w.BOOL, c.POINTER(w.POINT))
    foreground = bind_user("GetForegroundWindow", w.HWND)
    get_class = bind_user("GetClassNameW", c.c_int, w.HWND, w.LPWSTR, c.c_int)
    callback_type = c.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
    enum_children = bind_user("EnumChildWindows", w.BOOL, w.HWND, callback_type, w.LPARAM)
    window, client, origin = w.RECT(), w.RECT(), w.POINT()
    require(get_window_rect(hwnd, c.byref(window)), "GetWindowRect")
    require(get_client_rect(hwnd, c.byref(client)), "GetClientRect")
    require(client_to_screen(hwnd, c.byref(origin)), "ClientToScreen")
    gui = GuiThreadInfo(size=c.sizeof(GuiThreadInfo))
    c.set_last_error(0)
    gui_ok = bool(get_gui(thread, c.byref(gui)))
    gui_error = c.get_last_error() if not gui_ok else None
    cursor = w.POINT()
    c.set_last_error(0)
    cursor_ok = bool(get_cursor(c.byref(cursor)))
    cursor_error = c.get_last_error() if not cursor_ok else None
    children = []

    @callback_type
    def collect(child, _):
        name = c.create_unicode_buffer(128)
        get_class(child, name, len(name))
        children.append({"hwnd": child, "class": name.value})
        return True

    enum_children(hwnd, collect, 0)
    return {
        "window_rect": [window.left, window.top, window.right, window.bottom],
        "client_origin": [origin.x, origin.y], "client_size": [client.right, client.bottom],
        "dpi": {"window": get_dpi(hwnd), "window_awareness": dpi_awareness(get_window_dpi(hwnd)),
                "worker_awareness": dpi_awareness(get_thread_dpi())},
        "private_desktop_foreground": foreground(),
        "cursor_query": {"ok": cursor_ok, "win32_error": cursor_error},
        "gui_thread": ({name: getattr(gui, name) for name in
                        ("flags", "active", "focus", "capture", "menu_owner", "move_size", "caret")}
                       if gui_ok else {"win32_error": gui_error}),
        "child_windows": children,
    }


def pixel_summary(pixels, width, height, client=None):
    # In an outer-window bitmap, ignore nonclient pixels such as the title bar.
    left, top, right, bottom = client if client is not None else (0, 0, width, height)
    samples = []
    for row in range(top, bottom, max(1, (bottom - top) // 48)):
        for col in range(left, right, max(1, (right - left) // 64)):
            offset = ((height - 1 - row) * width + col) * 4
            samples.append(pixels[offset:offset + 3])
    colors = set(samples)
    sentinel = b"\xa5\xa5\xa5"
    untouched = sum(color == sentinel for color in samples) / len(samples)
    black = sum(max(color) < 8 for color in samples) / len(samples)
    return {
        "sha256_bgra": hashlib.sha256(pixels).hexdigest(),
        "sampled_pixels": len(samples), "unique_rgb": len(colors),
        "black_fraction": round(black, 4), "sentinel_fraction": round(untouched, 4),
        "nonblank_client": len(colors) >= 12 and black + untouched < 0.98,
    }


def capture_frame(hwnd, size, mode, client=None):
    get_dc = bind_user("GetWindowDC" if mode == "print-window" else "GetDC", w.HDC, w.HWND)
    release_dc = bind_user("ReleaseDC", c.c_int, w.HWND, w.HDC)
    print_window = bind_user("PrintWindow", w.BOOL, w.HWND, w.HDC, w.UINT)
    gdi = c.WinDLL("gdi32", use_last_error=True)

    def bind_gdi(name, result, *args):
        fn = getattr(gdi, name)
        fn.restype, fn.argtypes = result, args
        return fn

    create_dc = bind_gdi("CreateCompatibleDC", w.HDC, w.HDC)
    delete_dc = bind_gdi("DeleteDC", w.BOOL, w.HDC)
    create_dib = bind_gdi("CreateDIBSection", w.HANDLE, w.HDC, c.c_void_p, w.UINT,
                          c.POINTER(c.c_void_p), w.HANDLE, w.DWORD)
    select = bind_gdi("SelectObject", w.HANDLE, w.HDC, w.HANDLE)
    delete_object = bind_gdi("DeleteObject", w.BOOL, w.HANDLE)
    copy_dc = bind_gdi("BitBlt", w.BOOL, w.HDC, c.c_int, c.c_int, c.c_int, c.c_int,
                       w.HDC, c.c_int, c.c_int, w.DWORD)
    flush = bind_gdi("GdiFlush", w.BOOL)

    width, height = size
    if not (1 <= width <= 3840 and 1 <= height <= 2160):
        raise ValueError(f"Client capture size outside bounds: {width}x{height}")
    pixel_bytes = width * height * 4
    header = struct.pack("<IiiHHIIiiII", 40, width, height, 1, 32, 0, pixel_bytes, 0, 0, 0, 0)
    source = require(get_dc(hwnd), "Get device context of owned game window")
    try:
        destination = require(create_dc(source), "CreateCompatibleDC")
        try:
            bits = c.c_void_p()
            bitmap = require(create_dib(destination, c.create_string_buffer(header), 0,
                                        c.byref(bits), None, 0), "CreateDIBSection")
            try:
                previous = require(select(destination, bitmap), "SelectObject")
                try:
                    c.memset(bits, 0xA5, pixel_bytes)
                    c.set_last_error(0)
                    if mode == "bitblt":
                        ok = copy_dc(destination, 0, 0, width, height, source, 0, 0, 0x00CC0020)
                    else:
                        flags = {"print": 1, "print-full": 3, "print-window": 2}[mode]
                        ok = print_window(hwnd, destination, flags)
                    error = c.get_last_error() if not ok else None
                    flush()
                    pixels = c.string_at(bits, pixel_bytes)
                finally:
                    select(destination, previous)
            finally:
                delete_object(bitmap)
        finally:
            delete_dc(destination)
    finally:
        release_dc(hwnd, source)
    file_header = struct.pack("<2sIHHI", b"BM", len(pixels) + 54, 0, 0, 54)
    return {"api_ok": bool(ok), "win32_error": error, "frame_size": [width, height],
            "client_region": client, **pixel_summary(pixels, width, height, client)}, file_header + header + pixels


def dwm_thumbnail(hwnd, size, expected_desktop):
    """Try live DWM composition onto an owned nonactivating window in the same private desktop."""
    dwm = c.WinDLL("dwmapi", use_last_error=True)

    def bind_dwm(name, *args):
        fn = getattr(dwm, name)
        fn.restype, fn.argtypes = w.LONG, args
        return fn

    is_enabled = bind_dwm("DwmIsCompositionEnabled", c.POINTER(w.BOOL))
    attribute = bind_dwm("DwmGetWindowAttribute", w.HWND, w.DWORD, c.c_void_p, w.DWORD)
    register = bind_dwm("DwmRegisterThumbnail", w.HWND, w.HWND, c.POINTER(w.HANDLE))
    query_size = bind_dwm("DwmQueryThumbnailSourceSize", w.HANDLE, c.POINTER(w.SIZE))
    update = bind_dwm("DwmUpdateThumbnailProperties", w.HANDLE, c.POINTER(ThumbnailProperties))
    unregister = bind_dwm("DwmUnregisterThumbnail", w.HANDLE)
    create = bind_user("CreateWindowExW", w.HWND, w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD,
                       c.c_int, c.c_int, c.c_int, c.c_int, w.HWND, w.HMENU, w.HINSTANCE, w.LPVOID)
    show = bind_user("ShowWindow", w.BOOL, w.HWND, c.c_int)
    paint = bind_user("UpdateWindow", w.BOOL, w.HWND)
    destroy = bind_user("DestroyWindow", w.BOOL, w.HWND)
    get_instance = bind("GetModuleHandleW", w.HMODULE, w.LPCWSTR)
    peek = bind_user("PeekMessageW", w.BOOL, c.POINTER(w.MSG), w.HWND, w.UINT, w.UINT, w.UINT)
    dispatch = bind_user("DispatchMessageW", w.LPARAM, c.POINTER(w.MSG))
    width, height = min(size[0], 640), min(size[1], 360)
    composition, cloaked = w.BOOL(), w.DWORD()
    info = {"composition_hresult": f"0x{is_enabled(c.byref(composition)) & 0xffffffff:08x}",
            "composition_enabled": bool(composition.value),
            "source_cloak_hresult": f"0x{attribute(hwnd, 14, c.byref(cloaked), c.sizeof(cloaked)) & 0xffffffff:08x}",
            "source_cloaked": cloaked.value, "api_ok": False, "nonblank_client": False}
    if not composition.value or input_name() == expected_desktop:
        return info, None

    # WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE. All output stays on this private desktop.
    receiver = require(create(0x08000080, "Static", "War3 private capture receiver", 0x80000000,
                              0, 0, width, height, None, None, get_instance(None), None), "Create private DWM receiver")
    try:
        show(receiver, 4)  # SW_SHOWNOACTIVATE
        paint(receiver)
        before, _ = capture_frame(receiver, (width, height), "bitblt")
        info["receiver_before"] = before
        handle = w.HANDLE()
        result = register(receiver, hwnd, c.byref(handle))
        info["registration_hresult"] = f"0x{result & 0xffffffff:08x}"
        if result < 0:
            return info, None
        try:
            source_size = w.SIZE()
            info["source_size_hresult"] = f"0x{query_size(handle, c.byref(source_size)) & 0xffffffff:08x}"
            info["source_size"] = [source_size.cx, source_size.cy]
            props = ThumbnailProperties(flags=0x1D, destination=w.RECT(0, 0, width, height),
                                        opacity=255, visible=True, client_only=True)
            result = update(handle, c.byref(props))
            info["update_hresult"] = f"0x{result & 0xffffffff:08x}"
            if result < 0:
                return info, None
            message = w.MSG()
            deadline = time.monotonic() + 0.65
            while time.monotonic() < deadline:
                if input_name() == expected_desktop:
                    raise RuntimeError("Private capture desktop became the input desktop")
                while peek(c.byref(message), receiver, 0, 0, 1):
                    dispatch(c.byref(message))
                time.sleep(0.03)
            after, bitmap = capture_frame(receiver, (width, height), "bitblt")
            info["receiver_after"] = after
            info["receiver_pixels_changed"] = before["sha256_bgra"] != after["sha256_bgra"]
            info["api_ok"] = after["api_ok"]
            info["nonblank_client"] = info["receiver_pixels_changed"] and after["nonblank_client"]
            return info, bitmap
        finally:
            unregister(handle)
    finally:
        destroy(receiver)


def inspect_tga(path, bitmap_path=None):
    """Validate a War3 true-color screenshot and optionally export a viewable BMP."""
    with path.open("rb") as source:
        raw = source.read(64 * 1024 * 1024 + 1)
    if not 18 <= len(raw) <= 64 * 1024 * 1024:
        raise ValueError("Invalid TGA byte count")
    id_length, palette, kind, _, _, _, _, _, width, height, bits, descriptor = struct.unpack_from(
        "<BBBHHBHHHHBB", raw
    )
    if (palette or kind not in (2, 10) or bits not in (24, 32) or descriptor & 0xC0
            or not (1 <= width <= 3840 and 1 <= height <= 2160)):
        raise ValueError(f"Unsupported TGA format: {width}x{height}, type {kind}, depth {bits}, palette {palette}")
    bytes_per_pixel = bits // 8
    count = width * height
    offset = 18 + id_length
    if offset > len(raw):
        raise ValueError("Truncated TGA image ID")
    if kind == 2:
        payload = raw[offset:offset + count * bytes_per_pixel]
    else:
        output = bytearray()
        while len(output) < count * bytes_per_pixel:
            if offset >= len(raw):
                raise ValueError("Truncated TGA run-length packet")
            packet = raw[offset]
            length = (packet & 0x7F) + 1
            repeated = bool(packet & 0x80)
            packet_bytes = bytes_per_pixel if repeated else length * bytes_per_pixel
            offset += 1
            if offset + packet_bytes > len(raw) or len(output) + length * bytes_per_pixel > count * bytes_per_pixel:
                raise ValueError("Invalid TGA run-length packet")
            data = raw[offset:offset + packet_bytes]
            output.extend(data * length if repeated else data)
            offset += packet_bytes
        payload = bytes(output)
    if len(payload) != count * bytes_per_pixel:
        raise ValueError("Truncated TGA pixel data")

    rows = [payload[row:row + width * bytes_per_pixel]
            for row in range(0, len(payload), width * bytes_per_pixel)]
    if descriptor & 0x20:  # Convert top-down TGA to bottom-up BMP.
        rows.reverse()
    pixels = bytearray()
    for row in rows:
        if descriptor & 0x10:  # Convert right-to-left pixels to left-to-right.
            row = b"".join(row[index:index + bytes_per_pixel]
                           for index in range(len(row) - bytes_per_pixel, -1, -bytes_per_pixel))
        if bits == 32:
            pixels.extend(row)
        else:
            expanded = bytearray(width * 4)
            for channel in range(3):
                expanded[channel::4] = row[channel::3]
            pixels.extend(expanded)
    info = {"file": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw),
            "width": width, "height": height, "bits": bits, "tga_type": kind,
            **pixel_summary(bytes(pixels), width, height)}
    if bitmap_path and info["nonblank_client"]:
        header = struct.pack("<IiiHHIIiiII", 40, width, height, 1, 32, 0, len(pixels), 0, 0, 0, 0)
        file_header = struct.pack("<2sIHHI", b"BM", len(pixels) + 54, 0, 0, 54)
        with bitmap_path.open("xb") as bitmap:
            bitmap.write(file_header + header + pixels)
        info["bmp"] = str(bitmap_path)
    return info


def observe(args):
    if args.pid <= 0 or not args.desktop.startswith("War3Cold-"):
        raise ValueError("Expected a positive owned PID and a named War3Cold private desktop")
    if args.pid_file and args.pid_file.read_text(encoding="utf-8-sig").strip() != str(args.pid):
        raise ValueError("PID does not match the supervisor receipt")
    station = bind_user("GetProcessWindowStation", w.HANDLE)
    current_id = bind("GetCurrentThreadId", w.DWORD)
    thread_desktop = bind_user("GetThreadDesktop", w.HANDLE, w.DWORD)
    window_thread = bind_user("GetWindowThreadProcessId", w.DWORD, w.HWND, c.POINTER(w.DWORD))
    info = {"pid": args.pid, "mode": args.mode, "input_before": input_name(),
            "station": desktop_name(station()), "worker_desktop": desktop_name(thread_desktop(current_id()))}
    if info["station"] != "WinSta0" or info["worker_desktop"] != args.desktop or info["input_before"] == args.desktop:
        raise RuntimeError("Worker is outside the expected non-input desktop")
    matches = war3_windows(args.pid)
    if len(matches) != 1:
        raise RuntimeError(f"Expected one visible owned Warcraft III window, found {len(matches)}")
    hwnd = matches[0]
    owner = w.DWORD()
    thread = require(window_thread(hwnd, c.byref(owner)), "GetWindowThreadProcessId")
    target_desktop = desktop_name(thread_desktop(thread))
    if owner.value != args.pid or target_desktop != args.desktop:
        raise RuntimeError("Target PID or thread desktop changed")
    info.update(hwnd=hwnd, target_gui_thread=thread, target_desktop=target_desktop)
    info.update(window_state(hwnd, thread))
    if args.mode == "dwm-thumbnail":
        info["capture"], bitmap = dwm_thumbnail(hwnd, info["client_size"], args.desktop)
    elif args.mode == "print-window":
        left, top, right, bottom = info["window_rect"]
        width, height = right - left, bottom - top
        x, y = info["client_origin"]
        x, y = x - left, y - top
        cw, ch = info["client_size"]
        if not (0 <= x < x + cw <= width and 0 <= y < y + ch <= height):
            raise RuntimeError("Client coordinates fall outside the outer-window capture")
        info["capture"], bitmap = capture_frame(hwnd, (width, height), args.mode, (x, y, x + cw, y + ch))
    elif args.mode != "info":
        info["capture"], bitmap = capture_frame(hwnd, info["client_size"], args.mode)
    info["input_after"] = input_name()
    if info["input_before"] != info["input_after"] or war3_windows(args.pid) != [hwnd]:
        raise RuntimeError("Input desktop or target window changed while observing")
    if args.mode != "info" and info["capture"]["api_ok"] and info["capture"]["nonblank_client"]:
        path = args.output_dir / f"{args.mode}.bmp"
        with path.open("xb") as image:
            image.write(bitmap)
        info["capture"]["file"] = path.name
    return info


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pid", type=int, nargs="?")
    parser.add_argument("desktop", nargs="?", help="Private desktop name, without the WinSta0 prefix")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--pid-file", type=Path)
    parser.add_argument("--mode", choices=("info", "print", "print-full", "print-window", "bitblt", "dwm-thumbnail"),
                        default="info")
    parser.add_argument("--tga", type=Path, help="Inspect an existing game screenshot without calling window APIs")
    parser.add_argument("--tga-bmp", type=Path, help="Export validated nonblank TGA pixels to a new BMP")
    args = parser.parse_args()
    if args.tga:
        if args.pid is not None or args.desktop or args.output_dir or args.pid_file or args.mode != "info":
            parser.error("--tga is independent of window observation")
        try:
            info = inspect_tga(args.tga, args.tga_bmp)
        except (OSError, ValueError, struct.error) as exc:
            print(json.dumps({"file": str(args.tga), "error": str(exc)}), flush=True)
            return 2
        print(json.dumps(info), flush=True)
        return 0 if info["nonblank_client"] else 2
    if args.pid is None or not args.desktop or not args.output_dir or args.tga_bmp:
        parser.error("window observation requires pid, desktop and --output-dir")
    try:
        info = observe(args)
    except (OSError, RuntimeError, ValueError) as exc:
        info = {"pid": args.pid, "mode": args.mode, "error": str(exc),
                "win32_error": getattr(exc, "winerror", None)}
    print(json.dumps(info), flush=True)
    return 2 if "error" in info else 0


if __name__ == "__main__":
    raise SystemExit(main())
