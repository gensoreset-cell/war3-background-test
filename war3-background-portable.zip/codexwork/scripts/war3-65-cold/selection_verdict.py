"""Verify the sealed fixed-fixture native H005 selection and input receipts."""

import argparse
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
from pathlib import Path
import re

from route_verdict import (
    MENU_KEYS, background_desktop, nearest_coordinates, numbered, posted_keys,
    process_evidence, read_json, read_receipts, selection_checks,
)


FIXTURE_SHA = "51d86a9532ba5f92f583a7f61762cdcd1a1985c241747baba6697e0655154c86"
GUEST_RUNTIME_SHA = "074a112812d69e23aef982aabece74e1cbee31946d8c62956ef3a71518cdf3df"
SHA = re.compile(r"[0-9a-fA-F]{64}\Z")


def delivered_click_pair(trial):
    desktop = trial.get("desktop", "").partition("\\")[2]
    current_input = trial.get("input_desktop_before")
    for action in trial.get("actions", []):
        worker = action.get("worker") or {}
        window = worker.get("hwnd")
        if (action.get("action") != "hero-double-select" or action.get("code") != 0
                or worker.get("pid") != trial.get("game_pid") or not window
                or worker.get("thread_desktop") != desktop or worker.get("station") != "WinSta0"
                or worker.get("input_before") != current_input or worker.get("input_after") != current_input
                or worker.get("foreground_unchanged") is not True):
            continue
        posted = worker.get("posted", [])
        buttons = [row for row in posted if row.get("message") in (0x201, 0x202, 0x203)]
        sequence = [row["message"] for row in buttons]
        if sequence not in ([0x201, 0x202, 0x201, 0x202], [0x201, 0x202, 0x203, 0x202]):
            continue
        point = worker.get("client_point")
        started = action.get("elapsed")
        first_press, second_press = (row.get("elapsed_seconds") for row in buttons[::2])
        if (not all(row.get("ok") is True for row in posted) or not isinstance(point, list) or len(point) != 2
                or not all(type(coordinate) is int and 0 <= coordinate < 32768 for coordinate in point)
                or any(row.get("lparam") != ((point[1] << 16) | point[0]) for row in buttons)
                or not all(type(value) in (int, float) for value in (started, first_press, second_press))
                or not 0 <= first_press <= second_press):
            continue
        return {"window": window, "pid": worker["pid"], "transport": worker.get("transport"),
                "client_point": point, "presses": buttons[::2],
                "first_press_elapsed": round(started + first_press, 3),
                "second_press_elapsed": round(started + second_press, 3),
                "input_state_before": worker.get("input_state_before"),
                "input_state_after": worker.get("input_state_after"), "stdout": action.get("stdout")}
    return None


def was_observed_after(trial, records, minimum):
    if minimum is None:
        return False
    events = {event.get("file"): event for event in trial.get("events", [])}
    for record in records:
        event = events.get(record.path.name, {})
        observed = event.get("elapsed")
        expected = "AB65|" + record.path.stem + "|" + "|".join(f"{key}={value}" for key, value in record.fields.items())
        if event.get("message") != expected or type(observed) not in (int, float) or not observed >= minimum:
            return False
    return True


def in_game_click_pair(trial, left_down, delivery):
    if delivery is None:
        return ()
    x, y = map(str, delivery["client_point"])
    candidates = [(number, record) for number, record in left_down
                  if record.matches(event="left-down", sequence=str(number), client_x=x, client_y=y, active="1")]
    for (number, first), (next_number, second) in zip(candidates, candidates[1:]):
        if (next_number == number + 1 and second.stamp_ns >= first.stamp_ns
                and was_observed_after(trial, (first,), delivery["first_press_elapsed"])
                and was_observed_after(trial, (second,), delivery["second_press_elapsed"])):
            return first, second
    return ()


def native_menu_input(trial):
    if any(sequence == MENU_KEYS for sequence, _ in posted_keys(trial, "menu")):
        return True
    for action in trial.get("actions", []):
        worker = action.get("worker") or {}
        if (action.get("action") != "menu" or worker.get("pid") != trial.get("game_pid")
                or worker.get("window_outcome") != "disappeared_during_delivery"
                or action.get("terminal_reconciliation") != {"game_exit": ["natural", 0], "host_exit": 0}):
            continue
        events = [(row.get("message"), row.get("virtual_key")) for row in worker.get("posted", []) if row.get("ok") is True]
        expected = [(event, key) for key in MENU_KEYS for event in (0x100, 0x101)]
        if events in (expected[:-1], expected):
            return True
    return False


def guest_runtime_identity(trial):
    manifest = trial.get("runtime_manifest_sha256")
    identity = trial.get("identity")
    if not isinstance(manifest, str) or not SHA.fullmatch(manifest) or not isinstance(identity, dict):
        return False
    normalized = {}
    for name, checksum in identity.items():
        if not isinstance(name, str) or not isinstance(checksum, str) or not SHA.fullmatch(checksum):
            return False
        relative = name.replace("\\", "/").casefold()
        if relative in normalized:
            return False
        normalized[relative] = checksum.lower()
    if len(normalized) != 32 or normalized.pop("bin/maps/ab65.w3x", None) != FIXTURE_SHA:
        return False
    serialized = json.dumps(normalized, sort_keys=True, separators=(",", ":")).encode("ascii")
    return hashlib.sha256(serialized).hexdigest() == GUEST_RUNTIME_SHA


def guest_receipt_event(trial, record, focused=False):
    rows = [event for event in trial.get("events", []) if event.get("file") == record.path.name]
    if len(rows) != 1:
        return None
    event = rows[0]
    expected = "AB65|" + record.path.stem + "|" + "|".join(f"{key}={value}" for key, value in record.fields.items())
    elapsed = event.get("elapsed")
    if (event.get("message") != expected or event.get("file_mtime_ns") != record.stamp_ns
            or type(elapsed) not in (int, float) or not math.isfinite(elapsed)
            or not trial["guest_window"]["elapsed"] <= elapsed <= trial["elapsed_seconds"]):
        return None
    if focused and event.get("focused_hwnd") != trial["guest_window"]["hwnd"]:
        return None
    try:
        started = datetime.fromisoformat(trial["started_utc"]).astimezone(timezone.utc)
        ended = datetime.fromisoformat(trial["finished_utc"]).astimezone(timezone.utc)
    except (KeyError, TypeError, ValueError):
        return None
    if not round(started.timestamp() * 1e9) <= record.stamp_ns <= round(ended.timestamp() * 1e9):
        return None
    return elapsed


def guest_mouse_pair(trial, difficulty, left_down):
    if difficulty is None or guest_receipt_event(trial, difficulty) is None:
        return ()
    width, height = trial["guest_window"]["client_size"]
    for (index, first), (next_index, second) in zip(left_down, left_down[1:]):
        if next_index != index + 1 or not difficulty.stamp_ns < first.stamp_ns <= second.stamp_ns:
            continue
        if not second.matches(unit="H005") or not all(row.matches(event="left-down", active="1", sequence=str(number))
                for number, row in ((index, first), (next_index, second))):
            continue
        point = (first.fields.get("client_x", ""), first.fields.get("client_y", ""))
        if not all(value.isascii() and value.isdecimal() for value in point) or not second.matches(client_x=point[0], client_y=point[1]):
            continue
        if not (0 <= int(point[0]) < width and 0 <= int(point[1]) < height):
            continue
        try:
            terrain = [tuple(Decimal(row.fields.get(f"terrain_{axis}", "")) for axis in ("x", "y")) for row in (first, second)]
        except InvalidOperation:
            continue
        if any(not all(value.is_finite() for value in coords) or coords == (0, 0) for coords in terrain):
            continue
        if all(guest_receipt_event(trial, row, focused=True) is not None for row in (first, second)):
            return first, second
    return ()


def evaluate_guest(trial, run, receipts):
    canary = trial.get("guest_canary") or {}
    window = trial.get("guest_window") or {}
    window_elapsed, run_elapsed = window.get("elapsed"), trial.get("elapsed_seconds")
    size = window.get("client_size")
    ready = (trial.get("desktop") == r"WinSta0\Default" and trial.get("input_desktop_before") == trial.get("input_desktop_after") == "Default"
             and canary.get("station") == "WinSta0" and canary.get("thread_desktop") == canary.get("input_desktop")
             == canary.get("input_desktop_after") == "Default" and canary.get("cursor_query_succeeded") is True
             and canary.get("pass") is True and window.get("desktop") == "Default" and window.get("pid") == trial.get("game_pid")
             and all(type(window.get(key)) is int and window[key] > 0 for key in ("hwnd", "thread_id", "pid"))
             and isinstance(size, list) and len(size) == 2 and all(type(n) is int and n > 0 for n in size)
             and all(type(n) in (int, float) and math.isfinite(n) for n in (window_elapsed, run_elapsed))
             and 0 <= window_elapsed <= run_elapsed and trial.get("actions") == [])
    difficulty = receipts.get("dialog-chosen")
    neutral, pair, confirmation, selections = selection_checks(receipts, difficulty)
    chosen = receipts.get("route-hero-chosen")
    expiry = [record for _, record in numbered(receipts, "route-selection-expired-")]
    left_down = numbered(receipts, "route-mouse-left-down-")
    mouse_pair = guest_mouse_pair(trial, difficulty, left_down) if ready else ()
    bound_pair = False
    if pair and mouse_pair:
        # Windows file enumeration can deliver completed receipts in one poll
        # and in an order unrelated to the two original game timestamps.
        bound_pair = (all(guest_receipt_event(trial, row) is not None for row in pair)
                      and mouse_pair[0].stamp_ns <= pair[0].stamp_ns <= pair[1].stamp_ns
                      and mouse_pair[1].stamp_ns <= pair[1].stamp_ns)
    bound_timer = False
    spawn = None
    if confirmation and bound_pair:
        first, second, arm, expired = confirmation
        bound_timer = (all(guest_receipt_event(trial, row) is not None for row in (arm, expired))
                       and mouse_pair[0].stamp_ns <= arm.stamp_ns <= expired.stamp_ns
                       and second.stamp_ns <= expired.stamp_ns)
        # The chosen and second-select file writes can be reordered by the
        # engine (including E21); the final player-owned selection follows both.
        if (chosen is not None and chosen.matches(source="selection", type="H005")
                and chosen.stamp_ns >= mouse_pair[1].stamp_ns and guest_receipt_event(trial, chosen) is not None):
            spawn = next((record for _, record in selections
                          if record.matches(source="unit-selection", mode="select", type="H005", owner="0")
                          and record.stamp_ns >= max(chosen.stamp_ns, second.stamp_ns) and record.fields.get("id", "").isdecimal()
                          and record.fields["id"] != first.fields["id"]
                          and nearest_coordinates(record, Decimal("29109.70"), Decimal("-30405.00"))
                          and guest_receipt_event(trial, record) is not None), None)
    game_exit, clean = process_evidence(run, trial)
    cleanup = trial.get("cleanup", {})
    checks = {}

    def check(name, passed, *records, **details):
        checks[name] = {"passed": bool(passed), "receipts": [record.path.relative_to(run).as_posix()
                                                            for record in records if record is not None], **details}

    check("fixed_fixture_and_guest_desktop", ready and trial.get("hashes_after_match") is True
          and all(trial.get(key) == FIXTURE_SHA for key in ("map_sha256", "map_source_before_sha256", "map_source_after_sha256")))
    check("frozen_guest_runtime", guest_runtime_identity(trial), non_map_fingerprint=GUEST_RUNTIME_SHA)
    check("native_hard", ready and difficulty is not None and difficulty.matches(source="dialog", index="2", value="5")
          and guest_receipt_event(trial, difficulty) is not None, difficulty)
    check("first_neutral_h005", ready and neutral is not None and guest_receipt_event(trial, neutral) is not None, neutral)
    check("both_presses_seen_in_game", mouse_pair, *mouse_pair, owned_hwnd=window.get("hwnd"),
          transport="operator on guest input desktop; game PLD and observed foreground")
    check("second_same_neutral_h005", bound_pair, *(pair or ()),
          gap_game_seconds=str(pair[1].game_time() - pair[0].game_time()) if pair else None)
    check("original_timer_committed", bound_timer, *(confirmation[2:] if confirmation else expiry),
          observed_committed=[row.fields.get("committed") for row in expiry])
    check("player_zero_h005_spawned", spawn is not None, chosen, spawn)
    check("natural_exit_and_owned_job_clean", clean and trial.get("game_exit") == game_exit == ["natural", 0]
          and trial.get("host_exit") == 0 and not trial.get("timeout_sent")
          and trial.get("guest_operator_menu") == ["F10", "E", "X", "X"] and not cleanup.get("errors")
          and cleanup.get("profile_removed") is True and cleanup.get("job_accounting", {}).get("active") == 0,
          operator_instructions=trial.get("guest_operator_menu"), exit_evidence="owned host and game terminal; menu keys not recorded")
    first_missing = next((name for name, detail in checks.items() if not detail["passed"]), None)
    return {"run": str(run), "scope": "native_h005_guest_selection_only", "passed": first_missing is None,
            "first_missing": first_missing, "runner_status": trial.get("status"), "checks": checks,
            "hashes_after_match": trial.get("hashes_after_match"),
            "game_mouse_left_down": [{"file": record.path.name, **record.fields} for _, record in left_down]}


def evaluate(trial, run):
    if not trial.get("finished_utc"):
        raise ValueError("Selection verdict requires a sealed run")
    receipts = read_receipts(run / "game-output/Logs")
    if trial.get("mode") == "manual-guest":
        return evaluate_guest(trial, run, receipts)
    difficulty = receipts.get("dialog-chosen")
    neutral, pair, confirmation, selections = selection_checks(receipts, difficulty)
    chosen = receipts.get("route-hero-chosen")
    spawn = None
    if confirmation and chosen is not None and chosen.matches(source="selection", type="H005"):
        second = confirmation[1]
        spawn = next((record for _, record in selections
                      if record.matches(source="unit-selection", mode="select", type="H005", owner="0")
                      and record.stamp_ns >= max(chosen.stamp_ns, second.stamp_ns)
                      and record.fields.get("id", "").isdecimal()
                      and record.fields["id"] != second.fields["id"]
                      and nearest_coordinates(record, Decimal("29109.70"), Decimal("-30405.00"))), None)
    delivery = delivered_click_pair(trial)
    host_exit, clean = process_evidence(run, trial)
    menu = native_menu_input(trial)
    expiry = [record for _, record in numbered(receipts, "route-selection-expired-")]
    left_down = numbered(receipts, "route-mouse-left-down-")
    mouse_pair = in_game_click_pair(trial, left_down, delivery)
    checks = {}

    def check(name, passed, *records, **details):
        checks[name] = {"passed": bool(passed), "receipts": [record.path.relative_to(run).as_posix()
                                                            for record in records if record is not None], **details}

    check("fixed_fixture_and_private_desktop", background_desktop(trial) == "background"
          and trial.get("hashes_after_match") is True
          and all(trial.get(key) == FIXTURE_SHA for key in ("map_sha256", "map_source_before_sha256",
                                                           "map_source_after_sha256")))
    check("native_hard", difficulty is not None and difficulty.matches(source="dialog", index="2", value="5"), difficulty)
    check("two_clicks_delivered", delivery is not None, delivery=delivery)
    check("first_neutral_h005", neutral is not None, neutral)
    pair_after_input = (pair is not None and delivery is not None
                        and was_observed_after(trial, pair[:1], delivery["first_press_elapsed"])
                        and was_observed_after(trial, pair[1:], delivery["second_press_elapsed"]))
    check("second_same_neutral_h005", pair_after_input, *(pair or ()),
          gap_game_seconds=str(pair[1].game_time() - pair[0].game_time()) if pair else None,
          raw_pair_found=pair is not None, archived_pair_matches_live_events=pair_after_input)
    check("both_presses_seen_in_game", bool(mouse_pair), *mouse_pair)
    check("original_timer_committed", confirmation is not None and pair_after_input
          and was_observed_after(trial, confirmation[2:], delivery["first_press_elapsed"]),
          *(confirmation[2:] if confirmation else expiry),
          observed_committed=[row.fields.get("committed") for row in expiry])
    check("player_zero_h005_spawned", spawn is not None and pair_after_input
          and was_observed_after(trial, (chosen, spawn), delivery["second_press_elapsed"]), chosen, spawn)
    check("natural_exit_and_owned_job_clean", menu and clean and trial.get("game_exit") == host_exit == ["natural", 0]
          and trial.get("host_exit") == 0 and not trial.get("timeout_sent")
          and trial.get("cleanup", {}).get("job_accounting", {}).get("active") == 0)
    first_missing = next((name for name, detail in checks.items() if not detail["passed"]), None)
    return {"run": str(run), "scope": "native_h005_selection_only", "passed": first_missing is None,
            "first_missing": first_missing, "runner_status": trial.get("status"), "checks": checks,
            "game_mouse_left_down": [{"file": record.path.name, **record.fields} for _, record in left_down]}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("run", type=Path)
    args = cli.parse_args()
    try:
        run = args.run.resolve(strict=True)
        trial = read_json(run / "result.json")
        if trial.get("terminal") is not True:
            raise ValueError("result.json has not reached its terminal state")
        result = evaluate(trial, run)
    except (OSError, ValueError, KeyError) as error:
        cli.exit(2, f"Cannot verify selection: {error}\n")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return int(not result["passed"])


if __name__ == "__main__":
    raise SystemExit(main())
