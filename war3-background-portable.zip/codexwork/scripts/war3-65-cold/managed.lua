-- The supervisor prepends the input table. Lua module search paths use the
-- Windows ANSI code page. Other strings use UTF-8 for the KKWE bindings.
package.path = input.script_path .. '\\?.lua'
package.cpath = input.native_path .. '\\modules\\?.dll;' .. input.native_path .. '\\?.dll'
assert(package.loadlib(input.native_path .. '\\ydbase.dll', '*'))

local function emit(...)
    print(...)
    assert(io.stdout:flush())
end

log = {debug = emit, error = emit, trace = emit}
require 'util'

assert(input.action == 'launch-managed' or input.action == 'probe-child', 'unsupported launcher action')
local config = assert(sys.ini_load(fs.path(input.plugin_config)))
local expected = {}
local required = 0
for name in string.gmatch(input.expected_plugins, '[^,]+') do
    assert(not expected[name], 'duplicate plug-in in launch profile')
    expected[name] = true
    required = required + 1
end
local enabled = 0
for name, value in pairs(config.Enable or {}) do
    if value == '1' then
        assert(expected[name], 'unexpected game plug-in: ' .. name)
        enabled = enabled + 1
    end
end
assert(required > 0 and enabled == required and type(sys.spawn_inject) == 'function', 'test entrance or plug-in selection missing')
emit('M1_LEGACY_JAPI_PREFLIGHT_OK')

local function publish_pid(pid)
    local target = fs.path(input.pid_file)
    local staging = fs.path(input.pid_file .. '.pending')
    local file = assert(io.open(staging, 'wb'))
    local written, write_error = file:write(tostring(pid))
    local closed, close_error = file:close()
    assert(written, write_error)
    assert(closed, close_error)
    assert(os.rename(__(staging:string()), __(target:string())))
    emit('M1_LEGACY_JAPI_OWNED_PID', pid)
end

local owned = sys.process()

local function start_child()
    if input.action == 'probe-child' then
        owned:hide_window()
        assert(owned:create(nil, input.command_line, input.client_dir), 'could not create probe child')
        return
    end

    -- Keep the exact handle opened by the release's editor test helper.
    local factory = sys.process
    local supplied = false
    sys.process = function()
        assert(not supplied, 'legacy test entrance requested another process handle')
        supplied = true
        return setmetatable({close = function() end}, {__index = function(_, name)
            local method = owned[name]
            return function(_, ...) return method(owned, ...) end
        end})
    end
    local ok, started = pcall(function()
        return sys.spawn_inject(nil, input.command_line, fs.path(input.client_dir), fs.path(input.loader))
    end)
    sys.process = factory
    assert(ok, started)
    assert(started and supplied, 'legacy test entrance failed')
end

local function stop_child(reason)
    if owned:is_running() then
        if owned:kill() then
            return reason
        end
        assert(not owned:is_running(), 'owned child rejected termination')
    end
    return 'natural'
end

local function finish_child(reason)
    local exit_code = owned:wait()
    assert(type(exit_code) == 'number' and not owned:is_running(), 'owned child exit could not be verified')
    owned:close()
    emit('M1_LEGACY_JAPI_OWNED_EXIT', reason, exit_code)
end

local function run_child()
    start_child()
    local pid = owned:id()
    assert(type(pid) == 'number' and pid > 0, 'owned child has no valid PID')
    publish_pid(pid)

    while owned:is_running() do
        local command, read_error = io.read('*l')
        assert(not read_error, read_error)
        if command == 'timeout-stop' then
            emit('A1_TIMEOUT_RECEIVED', command, pid, owned:is_running())
            return stop_child('timeout_terminated')
        elseif command == nil then
            emit('A1_SUPERVISOR_EOF', pid, owned:is_running())
            return stop_child('eof_terminated')
        end
        assert(command == 'poll', 'unexpected supervisor command')
        if owned:is_running() then
            emit('M1_LEGACY_JAPI_OWNED_RUNNING', pid)
        end
    end
    return 'natural'
end

local ok, result = pcall(run_child)
if not ok then
    local reaped, cleanup_error = pcall(function()
        local pid = owned:id()
        if type(pid) == 'number' and pid > 0 then
            finish_child(stop_child('error_terminated'))
        else
            owned:close()
        end
    end)
    io.stderr:write('A1_LAUNCHER_ERROR\t', tostring(result), '\n')
    if not reaped then
        io.stderr:write('A1_CLEANUP_ERROR\t', tostring(cleanup_error), '\n')
    end
    io.stderr:flush()
    error(result)
end
finish_child(result)
