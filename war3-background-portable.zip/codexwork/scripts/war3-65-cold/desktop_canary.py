"""Verify the Win32 desktop available to this process without injecting input."""

import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
import os
import threading
import time


def bind(library, name, result, *arguments):
    function = getattr(library, name)
    function.restype = result
    function.argtypes = arguments
    return function


def inspect_messages(user32, hwnd, desktop_name, get_thread_id, get_desktop, name_of):
    win = wintypes
    post_id, send_id = 0x8041, 0x8042  # Private WM_APP messages.
    nonce, reply = 0x3456, 0x7654
    result = {"received": []}

    class Message(ctypes.Structure):
        _fields_ = [("hwnd", win.HWND), ("message", win.UINT), ("wParam", win.WPARAM),
                    ("lParam", win.LPARAM), ("time", win.DWORD), ("point", win.POINT),
                    ("private", win.DWORD)]

    wndproc_type = ctypes.WINFUNCTYPE(win.LPARAM, win.HWND, win.UINT, win.WPARAM, win.LPARAM)
    set_window_proc = bind(user32, "SetWindowLongPtrW" if ctypes.sizeof(ctypes.c_void_p) == 8
                           else "SetWindowLongW", ctypes.c_ssize_t, win.HWND, ctypes.c_int,
                           ctypes.c_ssize_t)
    call_window_proc = bind(user32, "CallWindowProcW", win.LPARAM, ctypes.c_void_p, win.HWND,
                            win.UINT, win.WPARAM, win.LPARAM)
    post = bind(user32, "PostMessageW", win.BOOL, win.HWND, win.UINT, win.WPARAM, win.LPARAM)
    send_timeout = bind(user32, "SendMessageTimeoutW", win.LPARAM, win.HWND, win.UINT,
                        win.WPARAM, win.LPARAM, win.UINT, win.UINT,
                        ctypes.POINTER(ctypes.c_size_t))
    peek = bind(user32, "PeekMessageW", win.BOOL, ctypes.POINTER(Message), win.HWND, win.UINT,
                win.UINT, win.UINT)
    dispatch = bind(user32, "DispatchMessageW", win.LPARAM, ctypes.POINTER(Message))

    @wndproc_type
    def receive(window, message, wparam, lparam):
        if message in (post_id, send_id):
            result["received"].append({"message": message, "wparam": wparam, "lparam": lparam,
                                       "thread_id": get_thread_id()})
            return reply if message == send_id else 0
        return call_window_proc(previous, window, message, wparam, lparam)

    finished = threading.Event()

    def sender():
        try:
            thread_id = get_thread_id()
            result["sender_thread_id"] = thread_id
            result["sender_desktop"] = name_of(get_desktop(thread_id))
            if result["sender_desktop"] != desktop_name:
                return

            ctypes.set_last_error(0)
            result["post_succeeded"] = bool(post(hwnd, post_id, nonce, 1))
            if not result["post_succeeded"]:
                result["post_error"] = ctypes.get_last_error()

            value = ctypes.c_size_t()
            ctypes.set_last_error(0)
            result["send_succeeded"] = bool(send_timeout(hwnd, send_id, nonce, 2, 0x0022, 750,
                                                         ctypes.byref(value)))
            if not result["send_succeeded"]:
                result["send_error"] = ctypes.get_last_error()
            result["send_result"] = value.value
        except OSError as error:
            result["sender_error"] = {"code": error.winerror, "message": str(error)}
        finally:
            finished.set()

    callback_address = ctypes.cast(receive, ctypes.c_void_p).value
    ctypes.set_last_error(0)
    previous = set_window_proc(hwnd, -4, callback_address)  # GWLP_WNDPROC
    if not previous:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        receiver_thread_id = get_thread_id()
        worker = threading.Thread(target=sender, name="desktop-canary-sender", daemon=True)
        worker.start()
        message = Message()
        deadline = time.monotonic() + 2.0
        while time.monotonic() < deadline:
            # Peek also services synchronous sends to this window's owner thread.
            if peek(ctypes.byref(message), hwnd, post_id, post_id, 1):
                dispatch(ctypes.byref(message))
            if finished.is_set() and (not result.get("post_succeeded") or len(result["received"]) >= 2):
                break
            time.sleep(0.005)
        worker.join(1.0)
        result["sender_finished"] = not worker.is_alive()
        expected = [(post_id, nonce, 1, receiver_thread_id), (send_id, nonce, 2, receiver_thread_id)]
        received = [(item["message"], item["wparam"], item["lparam"], item["thread_id"])
                    for item in result["received"]]
        result["pass"] = (result["sender_finished"] and result.get("post_succeeded") is True
                          and result.get("send_succeeded") is True
                          and result.get("send_result") == reply and sorted(received) == expected
                          and result["sender_thread_id"] != receiver_thread_id)
    finally:
        ctypes.set_last_error(0)
        if not set_window_proc(hwnd, -4, previous):
            raise ctypes.WinError(ctypes.get_last_error())
    return result


def inspect_desktop(receipt, message_probe):
    win = wintypes
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    current_thread_id = bind(kernel32, "GetCurrentThreadId", win.DWORD)
    session_of_process = bind(kernel32, "ProcessIdToSessionId", win.BOOL, win.DWORD,
                              ctypes.POINTER(win.DWORD))
    current_station = bind(user32, "GetProcessWindowStation", win.HANDLE)
    thread_desktop = bind(user32, "GetThreadDesktop", win.HANDLE, win.DWORD)
    open_input = bind(user32, "OpenInputDesktop", win.HANDLE, win.DWORD, win.BOOL, win.DWORD)
    close_desktop = bind(user32, "CloseDesktop", win.BOOL, win.HANDLE)
    object_information = bind(user32, "GetUserObjectInformationW", win.BOOL, win.HANDLE,
                              ctypes.c_int, win.LPVOID, win.DWORD, ctypes.POINTER(win.DWORD))
    get_cursor = bind(user32, "GetCursorPos", win.BOOL, ctypes.POINTER(win.POINT))
    get_foreground = bind(user32, "GetForegroundWindow", win.HWND)

    def name_of(handle):
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        name = ctypes.create_unicode_buffer(256)
        needed = win.DWORD()
        if not object_information(handle, 2, name, ctypes.sizeof(name), ctypes.byref(needed)):
            raise ctypes.WinError(ctypes.get_last_error())
        return name.value

    session_id = win.DWORD()
    if not session_of_process(receipt["pid"], ctypes.byref(session_id)):
        raise ctypes.WinError(ctypes.get_last_error())
    receipt["session_id"] = session_id.value
    receipt["thread_id"] = current_thread_id()
    receipt["station"] = name_of(current_station())
    desktop = thread_desktop(receipt["thread_id"])
    receipt["thread_desktop"] = name_of(desktop)
    def read_input():
        handle = open_input(0, False, 0x0001)  # DESKTOP_READOBJECTS
        if not handle:
            return None, ctypes.get_last_error()
        try:
            return name_of(handle), None
        finally:
            close_desktop(handle)

    receipt["input_desktop"], input_error = read_input()
    if input_error is not None:
        receipt["input_desktop_error"] = input_error
    receipt["is_input_desktop"] = receipt["thread_desktop"] == receipt["input_desktop"]

    cursor = win.POINT()
    receipt["cursor_query_succeeded"] = bool(get_cursor(ctypes.byref(cursor)))
    if not receipt["cursor_query_succeeded"]:
        receipt["cursor_query_error"] = ctypes.get_last_error()
    foreground_before = get_foreground()
    receipt["foreground_handle_available"] = bool(foreground_before)

    callback_type = ctypes.WINFUNCTYPE(win.BOOL, win.HWND, win.LPARAM)
    enumerate_windows = bind(user32, "EnumDesktopWindows", win.BOOL, win.HANDLE,
                             callback_type, win.LPARAM)
    create_window = bind(user32, "CreateWindowExW", win.HWND, win.DWORD, win.LPCWSTR,
                         win.LPCWSTR, win.DWORD, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                         ctypes.c_int, win.HWND, win.HMENU, win.HINSTANCE, win.LPVOID)
    window_owner = bind(user32, "GetWindowThreadProcessId", win.DWORD, win.HWND,
                        ctypes.POINTER(win.DWORD))
    is_visible = bind(user32, "IsWindowVisible", win.BOOL, win.HWND)
    is_window = bind(user32, "IsWindow", win.BOOL, win.HWND)
    destroy_window = bind(user32, "DestroyWindow", win.BOOL, win.HWND)

    # A hidden, nonactivating top-level system window requires no registered class.
    hwnd = create_window(0x08000080, "STATIC", "Warcraft III desktop canary", 0,
                         0, 0, 1, 1, None, None, None, None)
    if not hwnd:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        owner = win.DWORD()
        owner_thread = window_owner(hwnd, ctypes.byref(owner))
        receipt["synthetic_window_owned"] = (
            owner.value == receipt["pid"] and owner_thread == receipt["thread_id"]
        )
        receipt["synthetic_window_visible"] = bool(is_visible(hwnd))
        receipt["synthetic_window_foreground"] = get_foreground() == hwnd
        receipt["synthetic_window_enumerated"] = False

        @callback_type
        def inspect_window(candidate, _):
            if candidate == hwnd:
                receipt["synthetic_window_enumerated"] = True
            return True

        if not enumerate_windows(desktop, inspect_window, 0):
            raise ctypes.WinError(ctypes.get_last_error())
        if message_probe and receipt["synthetic_window_owned"] and not receipt["synthetic_window_visible"]:
            receipt["message_probe"] = inspect_messages(user32, hwnd, receipt["thread_desktop"],
                                                        current_thread_id, thread_desktop, name_of)
    finally:
        receipt["synthetic_window_destroyed"] = bool(destroy_window(hwnd)) and not is_window(hwnd)
    receipt["input_desktop_after"], input_error = read_input()
    if input_error is not None:
        receipt["input_desktop_after_error"] = input_error
    receipt["input_desktop_unchanged"] = (receipt["input_desktop"] is not None
                                          and receipt["input_desktop"] == receipt["input_desktop_after"])
    receipt["foreground_unchanged"] = get_foreground() == foreground_before


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-desktop", help="Required thread desktop name, such as Default")
    desktop_requirement = parser.add_mutually_exclusive_group()
    desktop_requirement.add_argument("--require-input", action="store_true",
                                     help="Require the thread on the input desktop and a readable cursor")
    desktop_requirement.add_argument("--require-non-input", action="store_true",
                                     help="Require a different and unchanged input desktop")
    parser.add_argument("--message-probe", action="store_true",
                        help="Send private messages from another thread to the synthetic window")
    arguments = parser.parse_args()
    receipt = {"pid": os.getpid(), "started_utc": datetime.now(timezone.utc).isoformat()}
    try:
        inspect_desktop(receipt, arguments.message_probe)
        failures = []
        if arguments.expect_desktop and receipt["thread_desktop"] != arguments.expect_desktop:
            failures.append("unexpected_thread_desktop")
        if arguments.require_input and not (receipt["is_input_desktop"] and
                                            receipt["cursor_query_succeeded"]):
            failures.append("input_desktop_unavailable")
        if arguments.require_non_input and (receipt["is_input_desktop"] or
                                            not receipt["input_desktop_unchanged"]):
            failures.append("non_input_desktop_unverified")
        if arguments.message_probe and not receipt.get("message_probe", {}).get("pass"):
            failures.append("directed_message_probe_failed")
        if arguments.message_probe and not receipt["foreground_unchanged"]:
            failures.append("foreground_changed_during_probe")
        if not all(receipt[key] for key in ("synthetic_window_owned", "synthetic_window_enumerated",
                                           "synthetic_window_destroyed")):
            failures.append("synthetic_window_lifecycle_failed")
        if receipt["synthetic_window_visible"] or receipt["synthetic_window_foreground"]:
            failures.append("synthetic_window_became_visible_or_foreground")
        receipt["failures"] = failures
    except OSError as error:
        receipt["failures"] = ["win32_error"]
        receipt["win32_error"] = {"code": error.winerror, "message": str(error)}
    receipt["pass"] = not receipt["failures"]
    print(json.dumps(receipt), flush=True)
    return 0 if receipt["pass"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
