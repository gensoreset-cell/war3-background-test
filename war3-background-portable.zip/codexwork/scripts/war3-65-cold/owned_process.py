"""Create a Windows process inside a private kill-on-close job from birth."""

import _winapi
import ctypes as c
from ctypes import wintypes as w
import msvcrt
import os
from pathlib import Path
import subprocess
import time
import uuid


kernel = c.WinDLL("kernel32", use_last_error=True)
user = c.WinDLL("user32", use_last_error=True)


def bind(name, result, *arguments):
    call = getattr(kernel, name)
    call.restype, call.argtypes = result, arguments
    return call


def bind_user(name, result, *arguments):
    call = getattr(user, name)
    call.restype, call.argtypes = result, arguments
    return call


class Startup(c.Structure):
    _fields_ = [("size", w.DWORD), ("reserved", w.LPWSTR), ("desktop", w.LPWSTR),
                ("title", w.LPWSTR)] + [(name, w.DWORD) for name in
                ("x", "y", "cx", "cy", "columns", "rows", "fill", "flags")] + [
                ("show", w.WORD), ("extra_size", w.WORD), ("extra", c.c_void_p),
                ("stdin", w.HANDLE), ("stdout", w.HANDLE), ("stderr", w.HANDLE)]


class StartupEx(c.Structure):
    _fields_ = [("startup", Startup), ("attributes", c.c_void_p)]


class ProcessInfo(c.Structure):
    _fields_ = [("process", w.HANDLE), ("thread", w.HANDLE),
                ("pid", w.DWORD), ("tid", w.DWORD)]


class BasicLimits(c.Structure):
    _fields_ = [("process_time", c.c_int64), ("job_time", c.c_int64),
                ("flags", w.DWORD), ("min_working", c.c_size_t),
                ("max_working", c.c_size_t), ("active_limit", w.DWORD),
                ("affinity", c.c_size_t), ("priority", w.DWORD), ("scheduling", w.DWORD)]


class ExtendedLimits(c.Structure):
    _fields_ = [("basic", BasicLimits), ("io", c.c_uint64 * 6),
                ("process_memory", c.c_size_t), ("job_memory", c.c_size_t),
                ("peak_process_memory", c.c_size_t), ("peak_job_memory", c.c_size_t)]


class JobAccounting(c.Structure):
    _fields_ = [(name, c.c_int64) for name in ("user", "kernel", "period_user", "period_kernel")] + [
        (name, w.DWORD) for name in ("faults", "total", "active", "terminated")]


class JobPids(c.Structure):
    _fields_ = [("assigned", w.DWORD), ("listed", w.DWORD), ("pids", c.c_size_t * 64)]


class ProcessEntry(c.Structure):
    _fields_ = [("size", w.DWORD), ("usage", w.DWORD), ("pid", w.DWORD),
                ("heap", c.c_size_t), ("module", w.DWORD), ("threads", w.DWORD),
                ("parent", w.DWORD), ("priority", w.LONG), ("flags", w.DWORD),
                ("name", w.WCHAR * 260)]


create_job = bind("CreateJobObjectW", w.HANDLE, c.c_void_p, w.LPCWSTR)
set_job = bind("SetInformationJobObject", w.BOOL, w.HANDLE, c.c_int, c.c_void_p, w.DWORD)
query_job = bind("QueryInformationJobObject", w.BOOL, w.HANDLE, c.c_int, c.c_void_p,
                 w.DWORD, c.POINTER(w.DWORD))
terminate_job = bind("TerminateJobObject", w.BOOL, w.HANDLE, w.UINT)
init_attrs = bind("InitializeProcThreadAttributeList", w.BOOL, c.c_void_p, w.DWORD,
                  w.DWORD, c.POINTER(c.c_size_t))
update_attrs = bind("UpdateProcThreadAttribute", w.BOOL, c.c_void_p, w.DWORD, c.c_size_t,
                    c.c_void_p, c.c_size_t, c.c_void_p, c.c_void_p)
delete_attrs = bind("DeleteProcThreadAttributeList", None, c.c_void_p)
create_process = bind("CreateProcessW", w.BOOL, w.LPCWSTR, w.LPWSTR, c.c_void_p,
                      c.c_void_p, w.BOOL, w.DWORD, c.c_void_p, w.LPCWSTR,
                      c.POINTER(StartupEx), c.POINTER(ProcessInfo))
open_process = bind("OpenProcess", w.HANDLE, w.DWORD, w.BOOL, w.DWORD)
snapshot = bind("CreateToolhelp32Snapshot", w.HANDLE, w.DWORD, w.DWORD)
first_entry = bind("Process32FirstW", w.BOOL, w.HANDLE, c.POINTER(ProcessEntry))
next_entry = bind("Process32NextW", w.BOOL, w.HANDLE, c.POINTER(ProcessEntry))
create_desktop = bind_user("CreateDesktopW", w.HANDLE, w.LPCWSTR, w.LPCWSTR, c.c_void_p,
                           w.DWORD, w.DWORD, c.c_void_p)
close_desktop = bind_user("CloseDesktop", w.BOOL, w.HANDLE)


def require(result, operation):
    if not result:
        code = c.get_last_error()
        raise OSError(code, f"{operation}: {c.FormatError(code).strip()}")
    return result


def process_snapshot():
    handle = snapshot(0x2, 0)  # TH32CS_SNAPPROCESS
    require(handle != c.c_void_p(-1).value, "CreateToolhelp32Snapshot")
    try:
        entry = ProcessEntry(size=c.sizeof(ProcessEntry))
        require(first_entry(handle, c.byref(entry)), "Process32FirstW")
        rows = []
        while True:
            rows.append({"name": entry.name, "pid": entry.pid, "parent": entry.parent})
            if not next_entry(handle, c.byref(entry)):
                if c.get_last_error() != 18:  # ERROR_NO_MORE_FILES
                    require(False, "Process32NextW")
                return rows
    finally:
        _winapi.CloseHandle(handle)


class PrivateDesktop:
    def __enter__(self):
        name = f"War3Cold-{uuid.uuid4().hex[:12]}"
        self.handle = require(create_desktop(name, None, None, 0, 0x43, None),
                              "CreateDesktopW for the private test desktop")
        return fr"WinSta0\{name}"

    def __exit__(self, *exception):
        require(close_desktop(self.handle), "CloseDesktop for the private test desktop")


class OwnedJob:
    def __init__(self, argv, cwd, desktop, output, env=None, label="host"):
        self.process = self.job = self.stdin = None
        self.output = Path(output)
        self.job = require(create_job(None, None), "CreateJobObjectW")
        try:
            limits = ExtendedLimits()
            limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            require(set_job(self.job, 9, c.byref(limits), c.sizeof(limits)),
                    "SetInformationJobObject(KILL_ON_JOB_CLOSE)")
            self.start(argv, cwd, desktop, env, label)
        except BaseException:
            self.close()
            raise

    def start(self, argv, cwd, desktop, env, label):
        read, write = os.pipe()
        try:
            with (self.output / f"{label}-stdout.log").open("xb", buffering=0) as out, \
                    (self.output / f"{label}-stderr.log").open("xb", buffering=0) as err:
                handles = (w.HANDLE * 3)(*(msvcrt.get_osfhandle(fd) for fd in
                                           (read, out.fileno(), err.fileno())))
                for handle in handles:
                    os.set_handle_inheritable(handle, True)
                info = self.create(argv, cwd, desktop, env, handles)
            self.pid, self.process = info.pid, info.process
            _winapi.CloseHandle(info.thread)
            self.stdin = os.fdopen(write, "wb", buffering=0)
            write = None
        finally:
            os.close(read)
            if write is not None:
                os.close(write)

    def create(self, argv, cwd, desktop, env, handles):
        size = c.c_size_t()
        init_attrs(None, 2, 0, c.byref(size))
        attributes = c.create_string_buffer(size.value)
        require(init_attrs(attributes, 2, 0, c.byref(size)), "InitializeProcThreadAttributeList")
        try:
            jobs = (w.HANDLE * 1)(self.job)
            # Job membership is set before user code runs. Only the listed streams inherit.
            require(update_attrs(attributes, 0, 0x2000D, jobs, c.sizeof(jobs), None, None),
                    "UpdateProcThreadAttribute(JOB_LIST)")
            require(update_attrs(attributes, 0, 0x20002, handles, c.sizeof(handles), None, None),
                    "UpdateProcThreadAttribute(HANDLE_LIST)")
            info = ProcessInfo()
            startup = StartupEx()
            startup.attributes = c.addressof(attributes)
            startup.startup.size = c.sizeof(startup)
            startup.startup.desktop = desktop
            startup.startup.flags = 0x100  # STARTF_USESTDHANDLES
            startup.startup.stdin, startup.startup.stdout, startup.startup.stderr = handles
            argv = [os.fspath(arg) for arg in argv]
            command = c.create_unicode_buffer(subprocess.list2cmdline(argv))
            environment = None if env is None else c.create_unicode_buffer("\0".join(
                f"{key}={value}" for key, value in sorted(env.items(), key=lambda pair: pair[0].upper())) + "\0")
            flags = 0x08000000 | 0x00080000 | 0x00000400  # no window, startup ex, unicode env
            require(create_process(argv[0], command, None, None, True, flags, environment,
                                   os.fspath(cwd), c.byref(startup), c.byref(info)),
                    "CreateProcessW with job and desktop")
            return info
        finally:
            delete_attrs(attributes)

    def send(self, command):
        self.stdin.write(command.encode("ascii") + b"\n")

    def close_stdin(self):
        if self.stdin is not None:
            self.stdin.close()
            self.stdin = None

    def poll(self, seconds=0):
        wait = _winapi.WaitForSingleObject(self.process, round(seconds * 1000))
        return None if wait == _winapi.WAIT_TIMEOUT else _winapi.GetExitCodeProcess(self.process)

    def pids(self):
        data = JobPids()
        require(query_job(self.job, 3, c.byref(data), c.sizeof(data), None), "Job process list")
        return list(data.pids[:data.listed])

    def accounting(self):
        data = JobAccounting()
        require(query_job(self.job, 1, c.byref(data), c.sizeof(data), None), "Job accounting")
        return {"total": data.total, "active": data.active, "terminated": data.terminated}

    def reap(self, seconds=10):
        require(terminate_job(self.job, 1460), "TerminateJobObject for the owned test tree")
        deadline = time.monotonic() + seconds
        while self.accounting()["active"] and time.monotonic() < deadline:
            time.sleep(0.05)
        return self.accounting()

    def close_job(self):
        if self.job is not None:
            _winapi.CloseHandle(self.job)
            self.job = None

    def close(self):
        try:
            self.close_job()
        finally:
            try:
                self.close_stdin()
            finally:
                if self.process is not None:
                    _winapi.CloseHandle(self.process)
                    self.process = None

    def __enter__(self):
        return self

    def __exit__(self, *exception):
        self.close()
