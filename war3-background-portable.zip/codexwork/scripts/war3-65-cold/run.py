"""Isolated Warcraft III cold-start supervisor and no-game preflight."""

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import traceback
import ctypes as c
from ctypes import wintypes as w

from owned_process import OwnedJob, PrivateDesktop, bind, open_process, process_snapshot, require, _winapi
from directed_confirm import input_name


SCRIPTS = Path(__file__).resolve().parent
WORK = SCRIPTS.parents[1]
FROZEN = Path(r"D:\魔兽文档\自制地图\大姐头\65.w3x")
SOURCE = WORK / "temp/w3-cold-a-reclaim-20261113-01"
SMOKE_MAP = WORK / "temp/w3-cold-a-stage-20261113-01/profile-background-smoke/bin/Maps/ab65.w3x"
SMOKE_HASH = "0dabb52059e6f40a6302b47770e780ca3ec298c69c3748fceea7542b0424bca5"
CHAT_MAP = WORK / "temp/w3-cold-a-stage-20261113-01/profile-background-dialog-test/bin/Maps/ab65.w3x"
CHAT_HASH = "e28435dc4cfb042b434f1606cbb01b88a03aa5b6016fb3e0565f20ba8fbbb760"
DEFAULT = r"WinSta0\Default"
PLUGINS = "kkapi_local_plugin.dll,yd_jass_api.dll,yd_lua_engine.dll"
PID = re.compile(rb"^M1_LEGACY_JAPI_OWNED_PID\t(\d+)\r?$", re.M)
EXIT = re.compile(rb"^M1_LEGACY_JAPI_OWNED_EXIT\t([^\t]+)\t(\d+)\r?$", re.M)
GAME_TASKS = {"war3.exe", "warcraft iii.exe", "worldedit.exe", "worldeditydwe.exe",
              "kkwe.exe", "w3l.exe", "lua53host.exe", "diagnosticsupervisor.exe", "isolatedsupervisor.exe"}


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, data):
    temp = path.with_suffix(".pending")
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            temp.replace(path)
            return
        except PermissionError:
            # A concurrent Windows reader can briefly deny replacement of the evidence file.
            if attempt == 5:
                raise
            time.sleep(0.08)


def lua_bytes(value, encoding="utf-8"):
    return '"' + ''.join(f"\\{number:03d}" for number in str(value).encode(encoding)) + '"'


def game_processes():
    return [row for row in process_snapshot() if row["name"].lower() in GAME_TASKS]


@contextmanager
def exclusive_game():
    create = bind("CreateMutexW", w.HANDLE, c.c_void_p, w.BOOL, w.LPCWSTR)
    c.set_last_error(0)
    mutex = create(None, False, r"Local\WarcraftIII65ColdTest")
    existing = c.get_last_error() == 183
    require(mutex, "CreateMutexW")
    try:
        if existing:
            raise RuntimeError("Another Warcraft III 65 test supervisor is active in this session")
        yield
    finally:
        _winapi.CloseHandle(mutex)


def run_one_game(args, run):
    with exclusive_game():
        if args.mode == "game":
            return foreground(run, args.profile.resolve(), args.desktop or None)
        with PrivateDesktop() as desktop:
            return background(run, args.profile.resolve(), desktop, args.mode)


def verify(profile, map_variant=None):
    identity = {}
    manifest = json.loads((SOURCE / "inputs.json").read_text(encoding="utf-8-sig"))
    for row in manifest:
        file = profile / row["path"]
        if file.is_symlink() or not file.resolve().is_relative_to(profile):
            raise RuntimeError(f"Input escapes isolated profile: {file}")
        is_variant_map = map_variant is not None and row["path"] == r"bin\Maps\ab65.w3x"
        if not is_variant_map and file.stat().st_size != row["length"]:
            raise RuntimeError(f"Frozen input length differs: {file}")
        with file.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        if digest != (map_variant[1] if is_variant_map else row["sha256"].lower()):
            raise RuntimeError(f"Frozen input hash differs: {file}")
        identity[row["path"]] = digest
    with FROZEN.open("rb") as stream:
        identity["original_map"] = hashlib.file_digest(stream, "sha256").hexdigest()
    if identity["original_map"] != "cc8fe6f073184751571db8f53cac0e78645523429b4ea0136f70c13dd023b346":
        raise RuntimeError("Original map differs from the historical hash")
    return identity


def stage(profile, map_variant=None):
    profile = profile.resolve()
    profile.relative_to((WORK / "build/war3-65-cold").resolve())
    profile.mkdir()
    manifest = json.loads((SOURCE / "inputs.json").read_text(encoding="utf-8-sig"))
    for row in manifest:
        rel = Path(row["path"])
        destination = profile / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        original = map_variant[0] if map_variant and row["path"] == r"bin\Maps\ab65.w3x" else SOURCE / "profile" / rel
        shutil.copy2(original, destination)
    return verify(profile, map_variant)


def host_settings(run, profile, mode, renderer="opengl"):
    bin_dir = profile / "bin"
    plugin = profile / "plugin/warcraft3"
    if mode == "game":
        argv = [bin_dir / "War3.exe", "-loadfile", r"Maps\ab65.w3x", "-window"]
        if renderer == "opengl":
            argv.append("-opengl")
        argv.extend(["-kkwe", profile, "-fastload"])
    else:
        argv = [Path(sys.executable), "-IB", "-c", "import time; time.sleep(30)"]
    argv = [str(arg) for arg in argv]
    settings = dict(native_path=bin_dir, script_path=profile / "share/script",
                    plugin_config=plugin / "config.cfg", expected_plugins=PLUGINS,
                    action="launch-managed" if mode == "game" else "probe-child",
                    command_line=subprocess.list2cmdline(argv),
                    client_dir=bin_dir if mode == "game" else run,
                    loader=plugin / "yd_loader.dll", pid_file=run / "owned-pid.txt")
    receipt = run / "execute.lua"
    header = ", ".join(f"{name}={lua_bytes(value, 'mbcs' if name in {'native_path', 'script_path'} else 'utf-8')}"
                       for name, value in settings.items())
    receipt.write_text("local input = {" + header + "}\n" +
                       (SCRIPTS / "managed.lua").read_text(encoding="utf-8"), encoding="utf-8")
    env = dict(os.environ, PATH=str(bin_dir) + os.pathsep + os.environ.get("PATH", ""))
    return [bin_dir / "Lua53Host.exe", bin_dir, receipt], argv, env


def read_receipts(run):
    log = (run / "host-stdout.log").read_bytes()
    pid = PID.search(log)
    exit_match = EXIT.search(log)
    return (int(pid.group(1)) if pid else None,
            [exit_match.group(1).decode("ascii"), int(exit_match.group(2))] if exit_match else None)


def wait_pid(job, run, seconds=8):
    deadline = time.monotonic() + seconds
    marker = run / "owned-pid.txt"
    while time.monotonic() < deadline:
        pid, _ = read_receipts(run)
        if pid is not None and marker.exists() and int(marker.read_text()) == pid:
            if pid not in job.pids() or pid == job.pid:
                raise RuntimeError(f"PID {pid} is absent from the owned job")
            return pid
        if job.poll(0.1) is not None:
            break
    raise RuntimeError("Owned child PID receipt missing")


def idle(job, seconds=4):
    deadline = time.monotonic() + seconds
    while job.accounting()["active"] and time.monotonic() < deadline:
        time.sleep(0.05)
    return job.accounting()


def desktop_probe(run, desktop, private=False):
    cmd = [sys.executable, "-IB", SCRIPTS / "desktop_canary.py"]
    if desktop:
        cmd += ["--expect-desktop", desktop.split("\\")[-1]]
        if desktop == DEFAULT:
            cmd += ["--require-input"]
    if private:
        cmd += ["--require-non-input", "--message-probe"]
    with OwnedJob(cmd, run, desktop, run, label="desktop") as worker:
        result = {"pid": worker.pid, "code": worker.poll(8), "job": idle(worker),
                  "members_after": worker.pids()}
    result["worker"] = json.loads((run / "desktop-stdout.log").read_text(encoding="utf-8"))
    return result


def lifecycle_probe(run, profile, mode, desktop):
    host, argv, env = host_settings(run, profile, mode)
    result = {"desktop": desktop, "child_argv": argv, "mode": mode}
    with OwnedJob(host, profile, desktop, run, env) as job:
        result["host_pid"] = job.pid
        pid = wait_pid(job, run)
        result.update(child_pid=pid, members_before=job.pids())
        if mode == "eof":
            job.close_stdin()
            result["host_exit"] = job.poll(6)
            result["job_after"] = idle(job)
            result["child_exit"] = read_receipts(run)[1]
            result["passed"] = (result["host_exit"] == 0 and result["job_after"]["active"] == 0
                                and result["child_exit"] is not None
                                and result["child_exit"][0] == "eof_terminated")
        else:
            child = require(open_process(0x00100000 | 0x1000, False, pid), "Open owned probe handle")
            try:
                result["child_live_before"] = _winapi.WaitForSingleObject(child, 0) == _winapi.WAIT_TIMEOUT
                # This is the same last-handle close Windows performs on supervisor death.
                job.close_job()
                result["host_exit"] = job.poll(6)
                result["child_signaled"] = _winapi.WaitForSingleObject(child, 6000) == 0
                result["child_exit"] = _winapi.GetExitCodeProcess(child)
                result["passed"] = (result["child_live_before"] and result["child_signaled"]
                                    and result["host_exit"] is not None)
            finally:
                _winapi.CloseHandle(child)
    return result


def current_logs(profile, skip=()):
    folder = profile / "bin/Logs"
    observed = {}
    for path in folder.glob("*"):
        if path.name in skip or not path.name.endswith((".pld", ".pld.start")):
            continue
        try:
            raw = path.read_bytes()
        except OSError as exc:
            if getattr(exc, "winerror", None) in (2, 32, 33):
                continue  # The game can still be publishing this file.
            raise
        msg = re.search(rb"(?:AB65|Q65)\|[^\r\n\"]+", raw)
        if msg:
            observed[path.name] = msg.group().decode("ascii", errors="replace")
    return observed


def archive_game_outputs(run, profile):
    """Keep the small original evidence files beside the supervisor receipts."""
    output = run / "game-output"
    output.mkdir()
    for name in ("Logs", "Replay", "Errors", "Screenshots"):
        source = profile / "bin" / name
        if source.is_dir():
            shutil.copytree(source, output / name)
    return str(output.relative_to(run))


def contiguous(rows):
    run = []
    for tick, seen in sorted(rows.items()):
        if run and (tick != run[-1][0] + 1 or not 0 <= seen - run[-1][1] <= 2.8):
            run.clear()
        run.append((tick, seen))
    return {"count": len(run), "first_tick": run[0][0] if run else None,
            "last_tick": run[-1][0] if run else None,
            "seconds": round(run[-1][1] - run[0][1], 3) if run else 0}


def ui(run, profile, desktop, pid, step, number):
    output = run / f"ui-{number:02d}-{step}"
    output.mkdir()
    argv = [sys.executable, "-B", SCRIPTS / "foreground.py", "--pid", str(pid),
            "--output-dir", output, "--step", step, "--logs-dir", profile / "bin/Logs",
            "--pid-file", run / "owned-pid.txt"]
    return OwnedJob(argv, run, desktop, output, label="ui"), output


def prepare_game(run, profile, map_variant=None, renderer="opengl"):
    matches = game_processes()
    if matches:
        raise RuntimeError(f"Other game/editor/launcher process present: {matches}")
    profile.relative_to((WORK / "build/war3-65-cold").resolve())
    if any((profile / "bin" / part).exists() for part in
           ("Logs", "Save", "Errors", "Replay", "TempReplay.w3g", "dz_w3_plugin.ini")):
        raise RuntimeError("Game output locations are not empty")
    identity = verify(profile, map_variant)
    host, argv, env = host_settings(run, profile, "game", renderer)
    if game_processes():
        raise RuntimeError("Game or editor appeared during preflight")
    return identity, host, argv, env


def directed_action(run, desktop, pid, action):
    worker = [sys.executable, "-B", SCRIPTS / "directed_confirm.py", str(pid),
              desktop.split("\\")[-1], "--action", action]
    label = f"directed-{action}"
    with OwnedJob(worker, run, desktop, run, label=label) as probe:
        code = probe.poll(8)
    text = (run / f"{label}-stdout.log").read_text(encoding="utf-8")
    return {"code": code, "worker": json.loads(text) if text else None}


def background(run, profile, desktop, mode):
    smoke = mode == "background-close"
    route = mode == "background-route"
    menu = mode == "background-menu"
    chat = mode == "background-chat" or menu
    map_variant = (SMOKE_MAP, SMOKE_HASH) if smoke else (CHAT_MAP, CHAT_HASH) if chat else None
    identity, host, argv, env = prepare_game(run, profile, map_variant)
    result = {"mode": mode, "desktop": desktop, "profile": str(profile),
              "argv": argv, "identity": identity, "start_utc": utc(), "passed": False,
              "total_limit_seconds": 155 if route or chat else 120, "post_wait_seconds": 30, "events": [],
              "input_desktop_before": input_name(), "input_desktop_samples": []}
    write_json(run / "game.json", result)
    began = time.monotonic()
    with OwnedJob(host, profile, desktop, run, env) as job:
        try:
            result["host_pid"] = job.pid
            result["game_pid"] = pid = wait_pid(job, run)
            result["members_initial"] = job.pids()
            seen = set()
            beats = {}
            end_seen = None
            next_desktop_sample = 0
            next_action = None
            actions = {}
            if route or chat:
                result["actions"] = actions
            while job.poll(0.25) is None:
                seconds = time.monotonic() - began
                if seconds >= next_desktop_sample:
                    current = input_name()
                    result["input_desktop_samples"].append([round(seconds, 3), current])
                    if current != result["input_desktop_before"]:
                        raise RuntimeError("User input desktop changed during private run")
                    next_desktop_sample = seconds + 2
                if seconds >= result["total_limit_seconds"]:
                    result["finding"] = "Background probe reached its total timeout"
                    break
                try:
                    job.send("poll")
                except BrokenPipeError:
                    break
                    logs = current_logs(profile, skip=seen)
                for name, message in logs.items():
                    if name not in seen:
                        seen.add(name)
                        result["events"].append({"file": name, "message": message, "utc": utc(),
                                                 "seconds": round(seconds, 3)})
                        tick = re.fullmatch(r"desktop-ab-HEARTBEAT-(\d+)\.pld", name)
                        if tick and message.endswith("|tick=" + tick[1]):
                            beats[int(tick[1])] = seconds
                result["heartbeats"] = contiguous(beats)
                if not (smoke or route or chat) and "desktop-ab-HEARTBEAT-1.pld" in seen:
                    result["finding"] = ("Heartbeat after directed Space" if "input_test" in result
                                         else "Heartbeat before directed input")
                    break
                if smoke and "desktop-ab-BG-EXIT.pld" in seen and end_seen is None:
                    end_seen = seconds
                due = (end_seen is not None and seconds > end_seen + 5 if smoke
                       else "desktop-ab-TIMER_ARMED.pld" in seen)
                if route or chat:
                    if route and due and "confirm" not in actions:
                        next_action = "confirm"
                    elif route and "desktop-ab-HEARTBEAT-1.pld" in seen and "easy" not in actions \
                            and seconds >= actions["confirm"]["seconds"] + 1.8:
                        next_action = "easy"
                    elif len(beats) >= (6 if chat else 4) and (chat or "easy" in actions) and "ready" not in actions:
                        next_action = "ready"
                    elif "desktop-ab-READY.pld" in seen and "ready" in actions and "mutate" not in actions:
                        next_action = "mutate"
                    elif "desktop-ab-MUTATED.pld" in seen and result["heartbeats"]["count"] >= 61 \
                            and result["heartbeats"]["seconds"] >= 60 \
                            and "close" not in actions:
                        next_action = "close"
                    if next_action:
                        if pid not in job.pids():
                            raise RuntimeError("War3 PID is outside its owned job")
                        action = "menu" if next_action == "close" and menu else next_action
                        receipt = directed_action(run, desktop, pid, action)
                        receipt["seconds"] = round(time.monotonic() - began, 3)
                        actions[next_action] = receipt
                        if receipt["code"] != 0:
                            result["finding"] = f"Directed {next_action} worker rejected the attempt"
                            break
                        next_action = None
                    deadlines = (("confirm", bool(beats), 15), ("easy", len(beats) >= 4, 12),
                                 ("ready", "desktop-ab-READY.pld" in seen, 12),
                                 ("mutate", "desktop-ab-MUTATED.pld" in seen, 12), ("close", False, 10))
                    expired = next((name for name, achieved, grace in deadlines
                                    if name in actions and not achieved and
                                    seconds > actions[name]["seconds"] + grace), None)
                    if expired:
                        result["finding"] = f"Expected game response absent after {expired}"
                        break
                elif "input_test" not in result and due:
                    if pid not in job.pids():
                        raise RuntimeError("War3 PID is outside its owned job")
                    result["input_test"] = directed_action(run, desktop, pid, "close" if smoke else "confirm")
                    result["input_test"]["seconds"] = round(time.monotonic() - began, 3)
                    if result["input_test"]["code"] != 0:
                        result["finding"] = "Directed input worker rejected the attempt"
                        break
                post_wait = 10 if smoke else result["post_wait_seconds"]
                if "input_test" in result and seconds > result["input_test"]["seconds"] + post_wait:
                    result["finding"] = "Application remained after WM_CLOSE" if smoke else "No first heartbeat after directed Space"
                    break
                write_json(run / "game.json", result)
        except Exception as exc:
            result["error"] = repr(exc)
            result["traceback"] = traceback.format_exc()
        finally:
            if job.poll() is None:
                try:
                    job.send("timeout-stop")
                    result["timeout_sent"] = True
                except BrokenPipeError:
                    pass
            result["host_exit"] = job.poll(8)
            result["job_after"] = idle(job, 2)
            if result["job_after"]["active"]:
                result["forced_job_reap"] = job.reap()
            result["members_after"] = job.pids()
            result["game_exit"] = read_receipts(run)[1]
            result["elapsed_seconds"] = round(time.monotonic() - began, 3)
            result["finish_utc"] = utc()
            result["crashes"] = [p.name for p in (profile / "bin/Errors").glob("*")]
            write_json(run / "game.json", result)
    result["hashes_after_match"] = identity == verify(profile, map_variant)
    result["remaining_game_processes"] = game_processes()
    result["input_desktop_after"] = input_name()
    result["original_game_output"] = archive_game_outputs(run, profile)
    result["probe_completed"] = (result["host_exit"] == 0 and not result["members_after"]
                                 and result["hashes_after_match"] and not result["remaining_game_processes"]
                                 and result["input_desktop_before"] == result["input_desktop_after"]
                                 and not result["crashes"] and "error" not in result)
    if smoke or route or chat:
        markers = {event["file"]: event["message"] for event in result["events"]}
        checks = [("READY", "unit=313|hp=313.000|gold=1234"), ("MUTATED", "unit=999|hp=140.000|gold=567")]
        if smoke:
            checks.extend([("BG-DIFFICULTY", "easy=1"), ("BG-EXIT", "tick=68")])
        result["state_passed"] = all(required in markers.get(f"desktop-ab-{name}.pld", "")
                                     for name, required in checks)
        close_receipt = result.get("input_test", {}) if smoke else result.get("actions", {}).get("close", {})
        if close_receipt.get("code") == 0:
            result["exit_request"] = "menu_keys" if menu else "window_close"
        heartbeats = result.get("heartbeats", {})
        result["passed"] = (result["probe_completed"] and result["state_passed"]
                            and heartbeats.get("count", 0) >= 61 and heartbeats.get("seconds", 0) >= 60
                            and close_receipt.get("code") == 0
                            and result["game_exit"] == ["natural", 0] and not result.get("timeout_sent"))
    else:
        result["passed"] = result["probe_completed"] and result.get("finding") == "Heartbeat after directed Space"
    write_json(run / "game.json", result)
    return result


def foreground(run, profile, desktop):
    if desktop != DEFAULT:
        raise ValueError("Foreground run requires the verified Default desktop")
    if not (SCRIPTS / "foreground.py").is_file():
        raise RuntimeError("Missing guarded foreground helper")
    identity, host, argv, env = prepare_game(run, profile)
    result = {"mode": "game", "desktop": desktop, "profile": str(profile), "argv": argv,
              "start_utc": utc(), "identity": identity, "events": [], "ui": [], "passed": False,
              "startup_limit_seconds": 105, "total_limit_seconds": 245}
    write_json(run / "game.json", result)
    seen, beats = {}, {}
    start = time.monotonic()
    steps = ["confirm", "easy", "ready", "mutate", "quit"]
    with OwnedJob(host, profile, desktop, run, env) as job:
        pending_ui = None
        try:
            result["host_pid"] = job.pid
            result["game_pid"] = pid = wait_pid(job, run)
            result["members_initial"] = job.pids()
            next_ui = 0.0
            with (run / "heartbeats.jsonl").open("x", encoding="utf-8", buffering=1) as heartbeat_log:
                while job.poll(0.2) is None:
                    seconds = time.monotonic() - start
                    try:
                        job.send("poll")
                    except BrokenPipeError:
                        break
                    for file, message in current_logs(profile).items():
                        if file in seen:
                            continue
                        seen[file] = message
                        tick = re.fullmatch(r"desktop-ab-HEARTBEAT-(\d+)\.pld", file)
                        event = {"seconds": round(seconds, 3), "utc": utc(), "file": file,
                                 "message": message}
                        if tick and message.endswith("|tick=" + tick[1]):
                            beats[int(tick[1])] = seconds
                            heartbeat_log.write(json.dumps(event) + "\n")
                        else:
                            result["events"].append(event)
                    result["heartbeats"] = contiguous(beats)
                    if seconds > result["total_limit_seconds"]:
                        raise RuntimeError("Total game timeout")
                    armed = "desktop-ab-TIMER_ARMED.pld" in seen
                    if seconds > result["startup_limit_seconds"] and (not armed or "confirm" in steps):
                        raise RuntimeError("Cold loading and guarded confirmation timeout")
                    ready = seen.get("desktop-ab-READY.pld", "")
                    mutated = seen.get("desktop-ab-MUTATED.pld", "")
                    result["ready_state"] = "unit=313|hp=313.000|gold=1234|tick=" in ready
                    result["mutated_state"] = "unit=999|hp=140.000|gold=567|tick=" in mutated
                    if not result.get("heartbeat_passed") and result["heartbeats"]["count"] >= 61 \
                            and result["heartbeats"]["seconds"] >= 60:
                        result["heartbeat_passed"] = result["heartbeats"].copy()
                    if pending_ui:
                        helper, output, step, started = pending_ui
                        code = helper.poll()
                        if code is None and seconds > started + 10:
                            raise RuntimeError(f"Foreground helper hung at {step}")
                        if code is not None:
                            helper.close()
                            pending_ui = None
                            receipt = {"code": code, "step": step, "at_seconds": round(seconds, 3),
                                       "evidence": str(output.relative_to(run))}
                            result["ui"].append(receipt)
                            if code == 0:
                                if step != "capture":
                                    steps.pop(0)
                            elif code != 2:
                                raise RuntimeError(f"Foreground helper failed at {step}")
                            next_ui = seconds + (8 if step == "capture" else 1.5 if code == 0 else 4)
                    if steps and pending_ui is None and seconds >= next_ui and (armed or seconds >= 12):
                        if pid not in job.pids():
                            raise RuntimeError("Game PID left its owned job before UI action")
                        step = steps[0] if armed else "capture"
                        allowed = (step != "mutate" or result["ready_state"]) and (
                            step != "quit" or result.get("heartbeat_passed") and result["mutated_state"])
                        if allowed:
                            helper, output = ui(run, profile, desktop, pid, step, len(result["ui"]) + 1)
                            pending_ui = helper, output, step, seconds
                    if not steps and "normal_exit_deadline" not in result:
                        result["normal_exit_deadline"] = seconds + 15
                    if seconds > result.get("normal_exit_deadline", float("inf")):
                        raise RuntimeError("Normal menu quit did not exit within 15 seconds")
                    write_json(run / "game.json", result)
        except BaseException as exc:
            result["error"] = repr(exc)
            result["traceback"] = traceback.format_exc()
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                raise
        finally:
            if pending_ui:
                helper, output, step, _ = pending_ui
                code = helper.poll(1) if step == "quit" else helper.poll()
                if code is not None:
                    result["ui"].append({"code": code, "step": step,
                                         "evidence": str(output.relative_to(run))})
                    if code == 0 and step == "quit" and steps == ["quit"]:
                        steps.clear()
                helper.close()
            if job.poll() is None:
                try:
                    job.send("timeout-stop")
                    result["timeout_sent"] = True
                except BrokenPipeError:
                    pass
            result["host_exit"] = job.poll(8)
            result["job_after"] = idle(job, 2)
            if result["job_after"]["active"]:
                result["forced_job_reap"] = job.reap()
            result["members_after"] = job.pids()
            result["game_exit"] = read_receipts(run)[1]
            result["finish_utc"] = utc()
            result["elapsed_seconds"] = round(time.monotonic() - start, 3)
            result["errors"] = [p.name for p in (profile / "bin/Errors").glob("*")]
            result["remaining_steps"] = steps
            result["passed"] = (not steps and result["game_exit"] == ["natural", 0]
                                and result["host_exit"] == 0 and not result["members_after"]
                                and not result["errors"] and "error" not in result
                                and "timeout_sent" not in result and "forced_job_reap" not in result)
            write_json(run / "game.json", result)
    result["hashes_after_match"] = identity == verify(profile)
    result["remaining_game_processes"] = game_processes()
    result["original_game_output"] = archive_game_outputs(run, profile)
    result["passed"] &= result["hashes_after_match"] and not result["remaining_game_processes"]
    write_json(run / "game.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["desktop", "private-desktop", "eof", "job-close", "stage", "stage-smoke", "stage-chat",
                                        "game", "background-confirm", "background-close", "background-route", "background-chat",
                                        "background-menu",
                                        "processes"])
    parser.add_argument("run", type=Path)
    parser.add_argument("--desktop", default=DEFAULT)
    parser.add_argument("--profile", type=Path, default=SOURCE / "profile")
    parser.add_argument("--experimental-foreground", action="store_true",
                        help="Allow the uncalibrated, interactive foreground diagnostic helper")
    args = parser.parse_args()
    if args.mode == "game" and not args.experimental_foreground:
        parser.error("game is an experimental foreground diagnostic and needs --experimental-foreground")
    run = args.run.resolve()
    run.relative_to((WORK / "logs/war3-65-cold").resolve())
    run.mkdir()
    result = {"start_utc": utc(), "mode": args.mode, "desktop": args.desktop}
    began = time.monotonic()
    try:
        if args.mode == "processes":
            result.update(passed=True, processes=game_processes())
        elif args.mode == "desktop":
            result.update(desktop_probe(run, args.desktop or None))
            result["passed"] = result["code"] == 0 and result["job"]["active"] == 0
        elif args.mode == "private-desktop":
            with PrivateDesktop() as desktop:
                result["desktop"] = desktop
                result.update(desktop_probe(run, desktop, private=True))
            result["passed"] = result["code"] == 0 and result["job"]["active"] == 0
        elif args.mode in ("stage", "stage-smoke", "stage-chat"):
            variant = {"stage-smoke": (SMOKE_MAP, SMOKE_HASH), "stage-chat": (CHAT_MAP, CHAT_HASH)}.get(args.mode)
            result.update(passed=True, profile=str(args.profile.resolve()),
                          identity=stage(args.profile, variant))
        elif args.mode == "game" or args.mode.startswith("background-"):
            result.update(run_one_game(args, run))
        else:
            result.update(lifecycle_probe(run, args.profile.resolve(), args.mode, args.desktop or None))
    except Exception as exc:
        result.update(passed=False, error=repr(exc), traceback=traceback.format_exc())
    result.update(finish_utc=utc(), elapsed_seconds=round(time.monotonic() - began, 3))
    write_json(run / "result.json", result)
    print(json.dumps(result, ensure_ascii=True))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
