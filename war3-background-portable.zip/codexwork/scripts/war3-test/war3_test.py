"""Run a declared Warcraft III scenario and publish machine-readable evidence."""

import argparse
import json
from pathlib import Path
import sys
import time

from war3_test_config import InvalidConfig, LEGACY, RUNTIME, ROOT, SCENARIOS, VERSION, digest, load, scenario_file, validate_transport
from war3_test_runner import EXIT_CODES, Failure, environment, legacy, run_pair, run_scenario


def parser():
    command = argparse.ArgumentParser(description=__doc__)
    command.add_argument("--version", action="version", version=VERSION)
    modes = command.add_subparsers(dest="mode", required=True)
    inspect = modes.add_parser("env", help="Check the runtime and private desktop without starting the game")
    inspect.add_argument("--runtime", type=Path, default=RUNTIME)
    inspect.add_argument("--canary-evidence-dir", type=Path)
    discover = modes.add_parser("list", help="List available scenario descriptions and fixtures")
    discover.add_argument("--scenario-dir", type=Path, default=SCENARIOS)
    pair = modes.add_parser("run-pair", help="Run two games on separate private desktops")
    pair.add_argument("--scenario", nargs=2, required=True, metavar=("FIRST", "SECOND"),
                      help="Two registered scenario names or JSON files, in run order")
    pair.add_argument("--scenario-dir", type=Path, default=SCENARIOS)
    pair.add_argument("--runtime", type=Path, default=RUNTIME)
    pair.add_argument("--evidence-dir", required=True, type=Path, help="Fresh parent for run-1 and run-2")
    for name in ("validate", "run"):
        mode = modes.add_parser(name, help="Validate configuration" if name == "validate" else "Cold-start an isolated game")
        mode.add_argument("--scenario", required=True, help="Registered scenario name or JSON file")
        mode.add_argument("--scenario-dir", type=Path, default=SCENARIOS)
        mode.add_argument("--map", type=Path, help="Override the fixture with a .w3x or .w3m archive")
        mode.add_argument("--sha256", help="Expected SHA-256 for the override map")
        mode.add_argument("--timeout", type=float, help="Override the overall game run deadline in seconds")
        mode.add_argument("--manual-guest", action="store_true",
                          help="Observe manual H005 input on a dedicated Windows guest's active desktop")
        if name == "run":
            mode.add_argument("--runtime", type=Path, default=RUNTIME)
            mode.add_argument("--evidence-dir", required=True, type=Path, help="Fresh directory for this run")
            mode.add_argument("--cache-base-mpqs", action="store_true",
                              help="Reuse guarded copies of the four base game archives on local NTFS")
    return command


def discover(directory):
    rows = []
    for file in sorted(directory.glob("*.json")):
        try:
            data = json.loads(file.read_text(encoding="utf-8-sig"))
            rows.append({"name": file.stem, "scenario_path": str(file), "description": data.get("description"),
                         "map": data.get("map"), "scenario_version": data.get("version")})
        except (OSError, ValueError, AttributeError) as error:
            rows.append({"name": file.stem, "scenario_path": str(file), "error": str(error)})
    if not directory.is_dir():
        raise InvalidConfig(f"Scenario directory missing: {directory}")
    return {"tool_version": VERSION, "status": "passed", "scenario_directory": str(directory), "scenarios": rows}


def show(result):
    print(json.dumps(result, ensure_ascii=True))
    return EXIT_CODES[result["status"]]


def source_fingerprints():
    cli = Path(__file__).resolve().parent
    dependencies = ("run.py", "owned_process.py", "directed_confirm.py", "managed.lua",
                    "desktop_canary.py", "window_observe.py", "route_verdict.py", "selection_verdict.py")
    sources = sorted(cli.glob("war3_test*.py")) + [LEGACY / name for name in dependencies]
    return {path.relative_to(ROOT).as_posix(): digest(path) for path in sources}


def paired_run(args, invocation, started):
    summary = {**invocation, "mode": "run-pair", "terminal": True, "status": "passed", "runs": []}
    evidence = None
    try:
        destination = args.evidence_dir.resolve()
        destination.mkdir(parents=True)
        evidence = destination
        summary["result"] = str(evidence / "result.json")
        runtime = args.runtime.resolve()
        directory = args.scenario_dir.resolve()
        fingerprints = source_fingerprints()
        runs = []
        for index, request in enumerate(args.scenario, 1):
            scenario = scenario_file(request, directory)
            config, config_hash = load(scenario)
            validate_transport(config, False)
            child = evidence / f"run-{index}"
            record = {**invocation, "pair_index": index, "evidence_dir": str(child), "runtime": str(runtime),
                      "scenario_path": str(scenario), "scenario_sha256": config_hash, "config": config,
                      "source_sha256": fingerprints, "status": "running", "terminal": False}
            runs.append((child, config, record))
        for child, _, record in runs:
            child.mkdir()
            record["configuration_wall_seconds"] = round(time.monotonic() - started, 3)
            legacy.write_json(child / "config.json", record)
    except (InvalidConfig, OSError, ValueError, KeyError, TypeError) as error:
        summary.update(status="invalid_config", error=str(error))
    else:
        try:
            results = run_pair(runtime, runs)
        except Failure as error:
            summary.update(status=error.status, error=str(error), error_details=error.details)
        except (RuntimeError, OSError) as error:
            summary.update(status="environment_unavailable", error=str(error))
        else:
            summary["runs"] = [{"result": str(child / "result.json"), "scenario": record["config"]["name"],
                                "status": record["status"], "exit_code": record["exit_code"],
                                "game_pid": record.get("game_pid")}
                               for (child, _, _), record in zip(runs, results)]
            summary["status"] = next((run["status"] for run in summary["runs"] if run["status"] != "passed"), "passed")
    summary["exit_code"] = EXIT_CODES[summary["status"]]
    if evidence is not None:
        legacy.write_json(evidence / "result.json", summary)
    return show(summary)


def main():
    started = time.monotonic()
    args = parser().parse_args()
    result = {"tool_version": VERSION, "invocation": sys.argv[1:], "working_directory": str(Path.cwd())}
    evidence = None
    if args.mode == "run-pair":
        return paired_run(args, result, started)
    if args.mode == "env":
        try:
            return show(environment(args.runtime.resolve(), args.canary_evidence_dir.resolve()
                                    if args.canary_evidence_dir else None))
        except (OSError, RuntimeError, KeyError, TypeError, ValueError) as error:
            return show({**result, "status": "environment_unavailable", "error": str(error)})
    try:
        if args.mode == "list":
            return show(discover(args.scenario_dir.resolve()))
        if args.mode == "run":
            candidate = args.evidence_dir.resolve()
            candidate.mkdir(parents=True)
            evidence = candidate
            result.update(evidence_dir=str(evidence), runtime=str(args.runtime.resolve()))
        scenario = scenario_file(args.scenario, args.scenario_dir.resolve())
        config, config_hash = load(scenario, args.map, args.sha256, args.timeout)
        validate_transport(config, args.manual_guest)
        result.update(scenario_path=str(scenario), scenario_sha256=config_hash, config=config, status="passed",
                      source_sha256=source_fingerprints())
        result["configuration_wall_seconds"] = round(time.monotonic() - started, 3)
        if args.mode == "validate":
            return show(result)
    except (InvalidConfig, OSError, ValueError, KeyError, TypeError) as error:
        result.update(status="invalid_config", terminal=True, error=str(error), exit_code=EXIT_CODES["invalid_config"])
        if evidence is not None:
            legacy.write_json(evidence / "result.json", result)
        return show(result)
    result.update(status="running", terminal=False)
    legacy.write_json(evidence / "config.json", result)
    result = run_scenario(evidence, args.runtime.resolve(), config, result, manual_guest=args.manual_guest,
                          cache_base_mpqs=args.cache_base_mpqs)
    keys = ("tool_version", "status", "terminal", "primary_status", "exit_code", "failed_step", "error", "error_details",
            "evidence_dir", "game_exit", "host_exit", "timeout_sent", "hashes_after_match", "cleanup")
    return show({"result": str(evidence / "result.json"), **{key: result[key] for key in keys if key in result}})


if __name__ == "__main__":
    raise SystemExit(main())
