"""Cold-start supervision and evidence collection on a non-input desktop."""

from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack, contextmanager, nullcontext, suppress
from ctypes import wintypes
import hashlib
import json
from ntpath import isreserved
import os
from pathlib import Path
import re
import shutil
import stat
import sys
from threading import Barrier, BrokenBarrierError, Lock
import time
import traceback
import uuid
import _winapi

from war3_test_config import FINAL_VERDICTS, LEGACY, ROOT, SHA, VERSION, digest

sys.path.insert(0, str(LEGACY))
import run as legacy
from desktop_canary import inspect_desktop
from directed_confirm import checked_window, input_name, war3_windows
from owned_process import OwnedJob, PrivateDesktop, bind_user, process_snapshot
from window_observe import inspect_tga


EXIT_CODES = {"passed": 0, "assertion_failed": 10, "input_invalid": 11, "startup_failed": 12,
              "timeout": 13, "environment_unavailable": 14, "execution_failed": 15,
              "cleanup_failed": 16, "invalid_config": 17, "input_no_effect": 18}
MAP_INPUT = r"bin\Maps\ab65.w3x"
BASE_MPQS = frozenset(f"bin\\{name}.mpq".casefold() for name in ("War3", "War3x", "War3Patch", "War3xLocal"))
OUTPUT_LOCATIONS = ("Logs", "Screenshots", "Replay", "Errors", "Save", "TempReplay.w3g", "dz_w3_plugin.ini")
OUTPUT_NAMES = frozenset(name.casefold() for name in OUTPUT_LOCATIONS)
RECEIPT_TICK = re.compile(r"desktop-ab-HEARTBEAT-(\d+)\.pld\Z")
HOST_TIMEOUT = 8
ACTION_TIMEOUT = 9
STEP_TIMEOUT = 15
PRELOAD = re.compile(rb'^\s*call\s+Preload\(\s*"((?:[^"\\]|\\.)*)"\s*\)', re.M)
FATAL_REPORT = re.compile(rb'^Exception:\s*(0x[0-9A-Fa-f]+)[^\r\n]*', re.M)
MENU_EVENTS = [(message, key) for key in (0x79, 0x45, 0x58, 0x58) for message in (0x100, 0x101)]


class Failure(Exception):
    def __init__(self, status, message, details=None):
        super().__init__(message)
        self.status = status
        self.details = {} if details is None else details


def require_game_idle(owned_jobs=()):
    matches = legacy.game_processes()
    owned_pids = {pid for job in owned_jobs for pid in job.pids()}
    matches = [row for row in matches if row["pid"] not in owned_pids]
    if matches:
        raise Failure("environment_unavailable", "Another game, editor or launcher process is active", matches)


class PairedGames:
    def __init__(self):
        self.lock = Lock()
        self.jobs = set()
        self.staged = Barrier(2)

    def run(self, evidence, runtime, config, result):
        try:
            return run_scenario(evidence, runtime, config, result, pair=self)
        finally:
            # If preparation failed, the other run can still exercise its own scenario.
            self.staged.abort()

    def await_peer(self):
        with suppress(BrokenBarrierError):
            self.staged.wait()

    @contextmanager
    def open_job(self, *args):
        with self.lock:
            require_game_idle(self.jobs)
            job = OwnedJob(*args)
            self.jobs.add(job)
        try:
            yield job
        finally:
            with self.lock:
                try:
                    job.close()
                finally:
                    self.jobs.remove(job)


def guest_desktop():
    receipt = {"pid": os.getpid(), "started_utc": legacy.utc()}
    inspect_desktop(receipt, False)
    receipt["pass"] = (
        (receipt["station"], receipt["thread_desktop"], receipt["input_desktop"],
         receipt["input_desktop_after"]) == ("WinSta0", "Default", "Default", "Default")
        and receipt["cursor_query_succeeded"] and receipt["input_desktop_unchanged"] and receipt["foreground_unchanged"]
        and receipt["synthetic_window_owned"] and receipt["synthetic_window_enumerated"]
        and receipt["synthetic_window_destroyed"] and not receipt["synthetic_window_visible"]
        and not receipt["synthetic_window_foreground"])
    return receipt


def runtime_manifest(runtime):
    profile = (runtime / "profile").resolve(strict=True)
    manifest_path = runtime / "inputs.json"
    rows = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    return profile, parse_runtime_inputs(rows)


def parse_runtime_inputs(rows):
    if not isinstance(rows, list) or not rows:
        raise RuntimeError("Runtime inputs.json must be a nonempty manifest")
    manifest = {}
    unique = set()
    canonical = {name.casefold(): name for name in (MAP_INPUT, r"bin\War3.exe", r"bin\Game.dll",
                 r"bin\Lua53Host.exe", r"plugin\warcraft3\yd_loader.dll", r"plugin\warcraft3\config.cfg")}
    for row in rows:
        raw = row["path"]
        parts = re.split(r"[/\\]", raw)
        if any(part in {"", ".", ".."} or ":" in part or isreserved(part) for part in parts):
            raise RuntimeError(f"Invalid relative runtime input: {raw}")
        normalized = tuple(part.casefold() for part in parts)
        if len(normalized) >= 2 and normalized[0] == "bin" and normalized[1] in OUTPUT_NAMES:
            raise RuntimeError(f"Runtime manifest must not seed generated game output: {raw}")
        key = "\\".join(normalized)
        path = canonical.get(key, "\\".join(parts))
        if key in unique or not SHA.fullmatch(row["sha256"]) or type(row["length"]) is not int:
            raise RuntimeError(f"Invalid or duplicate runtime manifest entry: {path}")
        unique.add(key)
        manifest[path] = (row["length"], row["sha256"].lower())
    if not canonical.keys() <= unique:
        raise RuntimeError("Missing mapped archive, client, launcher or KKWE loader manifest entry")
    return manifest


def file_in(root, relative):
    path = root / relative
    if not path.resolve(strict=True).is_relative_to(root) or not path.is_file():
        raise RuntimeError(f"Invalid input file path: {path}")
    for item in (path, *path.parents):
        if item == root:
            break
        if is_reparse_point(item):
            raise RuntimeError(f"Runtime input uses a reparse point: {item}")
    return path


def identity(profile, manifest, map_hash=None):
    values = {}
    for relative, (length, expected) in manifest.items():
        path = file_in(profile, relative)
        if relative == MAP_INPUT and map_hash is not None:
            expected = map_hash
        elif path.stat().st_size != length:
            raise RuntimeError(f"Runtime input size differs: {path}")
        actual = digest(path)
        if actual != expected:
            raise RuntimeError(f"Runtime input SHA-256 differs: {path}")
        values[relative] = actual
    return values


def cached_mpq(cache, origin, target, length, expected, guards):
    # The cache owns a physical copy. Only the disposable run path aliases it.
    shared = cache / f"{expected}.mpq"
    if not shared.exists():
        pending = cache / f"{uuid.uuid4().hex}.pending"
        pending.touch(exist_ok=False)
        try:
            shutil.copyfile(origin, pending)
            if pending.stat().st_size != length or digest(pending) != expected:
                raise RuntimeError(f"Cannot seed the MPQ cache from {origin}")
            pending.rename(shared)
        finally:
            pending.unlink(missing_ok=True)
    shared = file_in(cache, shared.name)
    before = shared.stat()
    if before.st_nlink != 1 or before.st_size != length or shared.samefile(origin):
        raise RuntimeError(f"Unexpected cache file identity: {shared}")
    os.link(shared, target)
    # GENERIC_READ, FILE_SHARE_READ, OPEN_EXISTING. Lock the staged pathname.
    handle = _winapi.CreateFile(str(target), 0x80000000, 1, 0, 3, 0, 0)
    guards.callback(_winapi.CloseHandle, handle)
    current = target.stat()
    if not os.path.samestat(before, current) or not target.samefile(shared) or current.st_nlink != 2:
        raise RuntimeError(f"MPQ cache alias changed during staging: {target}")


def stage(runtime, map_spec, profile, timings, *, cache_root=None, guards=None, created=None):
    source, manifest = runtime_manifest(runtime)
    # A fresh profile is deliberately populated from the manifest only.
    # Existing saves, logs, replays and launcher settings never enter a cold start.
    path = Path(map_spec["path"])
    profile.mkdir()
    if created is not None:
        created["profile_created"] = True
    cache = None
    if cache_root is not None:
        entries = sorted((name.casefold(), length, sha) for name, (length, sha) in manifest.items()
                         if name.casefold() in BASE_MPQS)
        if {name for name, _, _ in entries} != BASE_MPQS:
            raise RuntimeError("MPQ cache requires all four base archives")
        key = hashlib.sha256(json.dumps(entries).encode("ascii")).hexdigest()
        cache_root.mkdir(exist_ok=True)
        if cache_root.resolve(strict=True) != cache_root or is_reparse_point(cache_root):
            raise RuntimeError("MPQ cache root must be an ordinary project directory")
        cache = cache_root / key
        cache.mkdir(exist_ok=True)
        if cache.resolve(strict=True) != cache or is_reparse_point(cache):
            raise RuntimeError("MPQ cache must be an ordinary project directory")
    started = time.monotonic()
    for relative in manifest:
        origin = path if relative == MAP_INPUT else file_in(source, relative)
        target = profile / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if cache is not None and relative.casefold() in BASE_MPQS:
            cached_mpq(cache, origin, target, *manifest[relative], guards)
        else:
            shutil.copy2(origin, target)
    timings["copy_inputs"] = round(time.monotonic() - started, 3)
    for name in OUTPUT_LOCATIONS:
        destination = profile / "bin" / name
        if destination.exists() or destination.is_symlink():
            raise RuntimeError(f"Cold-start output path already exists: {destination}")
    started = time.monotonic()
    hashes = identity(profile, manifest, map_spec["sha256"])
    timings["verify_staged_inputs"] = round(time.monotonic() - started, 3)
    return manifest, hashes


def environment(runtime, canary=None):
    profile, manifest = runtime_manifest(runtime)
    hashes = identity(profile, manifest)
    active = input_name()
    result = {"tool_version": VERSION, "status": "passed", "mode": "private-desktop", "runtime": str(runtime),
              "runtime_manifest_sha256": digest(runtime / "inputs.json"), "identity": hashes, "input_desktop": active,
              "existing_game_processes": legacy.game_processes(),
              "independent_interactive_cursor": {"available": False,
                                                  "reason": "This transport runs on a Win32 non-input desktop."}}
    with PrivateDesktop() as desktop:
        result["private_desktop"] = {"available": True, "name": desktop, "is_input": desktop.split("\\")[-1] == active}
        if canary is not None:
            canary.mkdir()
            result["canary"] = legacy.desktop_probe(canary, desktop, private=True)
            result["independent_interactive_cursor"]["canary_get_cursor_pos"] = result["canary"]["worker"].get(
                "cursor_query_succeeded")
            result["independent_interactive_cursor"]["canary_win32_error"] = result["canary"]["worker"].get(
                "cursor_query_error")
            if result["canary"]["code"] != 0 or result["canary"]["members_after"]:
                result["status"] = "environment_unavailable"
    result["input_desktop_after"] = input_name()
    if result["input_desktop_after"] != active or result["private_desktop"]["is_input"]:
        result["status"] = "environment_unavailable"
    return result


def current_receipts(profile, skip):
    for path in (profile / "bin/Logs").glob("*.pld*"):
        if path.name in skip or not path.name.endswith((".pld", ".pld.start")):
            continue
        try:
            stamp = path.stat().st_mtime_ns
            with path.open("rb") as stream:
                data = stream.read(1024 * 1024 + 1)
        except OSError as error:
            if getattr(error, "winerror", None) in (2, 32, 33):
                continue
            raise
        # Wait for Warcraft's PreloadGen output to be complete before locking in the receipt.
        if len(data) <= 1024 * 1024 and b"endfunction" in data:
            payloads = PRELOAD.findall(data)
            if payloads:
                decoded = [part.decode("utf-8", errors="replace") for part in payloads]
                yield path.name, "\n".join(decoded), stamp


def is_reparse_point(path):
    return bool(getattr(path.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT)


def archive_inventory(root):
    checks = {}
    for path in root.rglob("*"):
        if is_reparse_point(path):
            raise RuntimeError(f"Cannot archive or remove a reparse point: {path}")
        if path.is_file():
            checks[path.relative_to(root).as_posix()] = digest(path)
    return checks


def heartbeat_span(profile, since_ns):
    samples = {}
    for path in (profile / "bin/Logs").glob("desktop-ab-HEARTBEAT-*.pld"):
        match = RECEIPT_TICK.fullmatch(path.name)
        try:
            stamp = path.stat().st_mtime_ns
            if match and stamp >= since_ns and (b"|tick=" + match[1].encode("ascii") + b'"') in path.read_bytes():
                samples[int(match[1])] = stamp
        except OSError as error:
            if getattr(error, "winerror", None) not in (2, 32, 33):
                raise
    longest, previous_tick, previous_ns = [], None, None
    current = []
    for tick, stamp in sorted(samples.items()):
        if previous_tick is not None and (tick != previous_tick + 1 or not 0 < stamp - previous_ns <= 2_800_000_000):
            current = []
        current.append((tick, stamp))
        if len(current) > len(longest):
            longest = current.copy()
        previous_tick, previous_ns = tick, stamp
    span = (longest[-1][1] - longest[0][1]) / 1_000_000_000 if longest else 0
    return {"samples": len(longest), "seconds": span, "first_tick": longest[0][0] if longest else None,
            "last_tick": longest[-1][0] if longest else None, "max_gap_seconds": 2.8}


class Trial:
    def __init__(self, evidence, profile, config, result):
        self.evidence, self.profile, self.config, self.result = evidence, profile, config, result
        self.started = time.monotonic()
        self.deadline = self.started + config["timeout_seconds"]
        self.receipts = {}
        self.observed_utc = {}
        self.last_poll = self.last_scan = 0
        self.current = None
        self.manual_guest = result.get("mode") == "manual-guest"
        self.foreground = bind_user("GetForegroundWindow", wintypes.HWND) if self.manual_guest else None

    def elapsed(self):
        return round(time.monotonic() - self.started, 3)

    def save(self):
        legacy.write_json(self.evidence / "result.json", self.result)

    def poll(self, force=False):
        now = time.monotonic()
        if input_name() != self.result["input_desktop_before"]:
            raise Failure("environment_unavailable", "Windows input desktop changed during the run")
        if self.job.poll() is None and (force or now - self.last_poll >= 0.2):
            with suppress(BrokenPipeError):
                self.job.send("poll")
            self.last_poll = now
        if force or now - self.last_scan >= 0.2:
            for name, message, stamp in current_receipts(self.profile, self.receipts):
                self.receipts[name] = message
                self.observed_utc[name] = stamp
                event = {"file": name, "message": message, "elapsed": self.elapsed(), "file_mtime_ns": stamp}
                if self.manual_guest:
                    event["focused_hwnd"] = self.foreground()
                self.result["events"].append(event)
            self.last_scan = now

    def remaining(self, limit):
        remain = limit - time.monotonic()
        if remain <= 0:
            if time.monotonic() >= self.deadline:
                self.result["global_timeout"] = True
                raise Failure("timeout", "Cold-start run deadline expired")
        return remain

    def until(self, limit, probe, status, reason, details=None, allow_exit=False):
        while self.remaining(limit) > 0:
            self.poll()
            answer = probe()
            if answer is not None:
                return answer
            if not allow_exit and (fatal := self.fatal_report()) is not None:
                self.result["native_fatal"] = fatal
                raise Failure("startup_failed" if not self.receipts else "execution_failed",
                              "Owned game wrote a native fatal error report", fatal)
            if not allow_exit and self.job.poll() is not None:
                self.poll(force=True)
                answer = probe()
                if answer is not None:
                    return answer
                raise Failure("startup_failed" if not self.result["actions"] else "execution_failed",
                              "Owned game exited before the requested step completed",
                              {"game_exit": legacy.read_receipts(self.evidence)[1], "host_exit": self.job.poll()})
            time.sleep(min(0.15, max(0, limit - time.monotonic())))
        raise Failure(status, reason, details() if callable(details) else details)

    def fatal_report(self):
        folder = self.profile / "bin/Errors"
        if not folder.is_dir() or is_reparse_point(folder):
            return None
        for path in sorted(folder.glob("* Crash.txt")):
            try:
                if not path.is_file() or is_reparse_point(path):
                    continue
                with path.open("rb") as stream:
                    exception = FATAL_REPORT.search(stream.read(32 * 1024))
                if exception:
                    return {"file": f"game-output/Errors/{path.name}",
                            "exception": exception[1].decode("ascii"),
                            "line": exception[0].decode("ascii", errors="backslashreplace")}
            except OSError:
                continue  # The game may still be creating the report.
        return None

    def action(self, step, limit, label):
        if self.manual_guest:
            raise Failure("input_invalid", "Manual guest runs do not send any game input")
        pid = self.result["game_pid"]
        if pid not in self.job.pids():
            raise Failure("input_invalid", "The target game PID has left its owning job")
        remaining = self.remaining(limit)
        if remaining <= 0:
            raise Failure("timeout", "No time remains for the guarded window worker")
        command = [sys.executable, "-B", LEGACY / "directed_confirm.py", str(pid),
                   self.result["desktop"].split("\\")[-1], "--action", step["action"],
                   "--window-wait-seconds", str(min(15.0, max(0.0, remaining - 0.5)))]
        for field in ("point", "clear_point", "neutral_client", "second_point", "second_delay_ms"):
            if field in step:
                value = step[field]
                command.extend([f"--{field.replace('_', '-')}", *(str(n) for n in value)] if isinstance(value, list)
                               else [f"--{field.replace('_', '-')}", str(value)])
        for flag in ("sync", "double_message"):
            if step.get(flag):
                command.append(f"--{flag.replace('_', '-')}")
        started = self.elapsed()
        with OwnedJob(command, self.evidence, self.result["desktop"], self.evidence, label=label) as worker:
            code = worker.poll(max(0.01, self.remaining(limit)))
            worker_members = worker.pids()
            if worker_members:
                worker.reap(2)
            worker_members_after = worker.pids()
        stdout = self.evidence / f"{label}-stdout.log"
        raw = stdout.read_text(encoding="utf-8")
        with suppress(json.JSONDecodeError):
            raw = json.loads(raw)
        record = {"action": step["action"], "elapsed": started, "finished_elapsed": self.elapsed(),
                  "code": code, "worker": raw if isinstance(raw, dict) else None,
                  "worker_members_after": worker_members_after,
                  "stdout": stdout.name, "stderr": f"{label}-stderr.log"}
        self.result["actions"].append(record)
        if worker_members_after:
            raise Failure("cleanup_failed", "Owned input worker still has live processes", record)
        if self.remaining(limit) <= 0 and code is None:
            raise Failure("timeout", "The guarded input worker exceeded its step budget", record)
        if code != 0 or not record["worker"]:
            payload = record["worker"] or {}
            delivered = [(item.get("message"), item.get("virtual_key")) for item in payload.get("posted", [])
                         if item.get("ok") is True]
            if (step["action"] == "menu" and payload.get("pid") == pid
                    and payload.get("window_outcome") == "disappeared_during_delivery"
                    and delivered in (MENU_EVENTS[:-1], MENU_EVENTS)):
                # The native quit menu can destroy its own window during delivery.
                record["terminal_reconciliation"] = self.natural_exit(limit)
                return record
            if payload.get("window_outcome") == "not_ready":
                raise Failure("timeout", "The owned game window did not become ready", record)
            raise Failure("input_invalid", "The guarded input worker could not deliver the action", record)
        if step.get("settle_seconds"):
            target = time.monotonic() + step["settle_seconds"]
            self.until(limit, lambda: True if time.monotonic() >= target else None,
                       "timeout", "Input settling period exceeded the step budget")
        return record

    def wait_window(self, limit, label):
        if self.manual_guest:
            pid = self.result["game_pid"]

            def observed():
                if pid not in self.job.pids():
                    return None
                matches = war3_windows(pid)
                if len(matches) > 1:
                    raise Failure("input_invalid", "More than one window matched the owned game")
                if matches and (window := checked_window(matches[0], pid, "Default")):
                    return {**window, "elapsed": self.elapsed()}
                return None

            window = self.until(limit, observed, "timeout", "The owned guest game window did not appear")
            self.result["guest_window"] = window
            print(f"自有游戏窗口已就绪，PID {pid}，HWND {window['hwnd']}。请在测试机中操作游戏。", file=sys.stderr, flush=True)
            return window
        record = self.action({"action": "window-ready"}, limit, label)
        worker = record["worker"]
        if (worker.get("pid") != self.result["game_pid"] or worker.get("window_outcome") != "ready"
                or not worker.get("hwnd") or worker.get("posted") != []):
            raise Failure("input_invalid", "Window readiness did not bind to the owned game", record)
        return record

    def receipt(self, step, limit):
        filename = step["file"]
        expected = step.get("contains", [])

        def observed():
            if filename not in self.receipts:
                self.retry_continue(filename, limit)
                return None
            actual = self.receipts[filename]
            details = {"file": filename, "actual": actual, "expected_fragments": expected,
                       "receipt_state": "observed"}
            if any(fragment not in actual for fragment in expected):
                details["receipt_state"] = "mismatch"
                raise Failure("assertion_failed", "The native receipt did not match", details)
            return details

        status = "assertion_failed" if step["op"] == "assert_receipt" else "timeout"
        missing = {"file": filename, "expected_fragments": expected, "receipt_state": "missing"}
        if step.get("on_missing") == "input_no_effect":
            previous = next(row for row in self.result["steps"] if row["id"] == step["after_input"])
            action = previous.get("details", {})
            worker = action.get("worker", {})
            posted = worker.get("posted", [])
            if (previous["status"] == "passed" and action.get("code") == 0 and
                    worker.get("pid") == self.result["game_pid"] and posted and all(item["ok"] for item in posted)):
                status = "input_no_effect"
                missing.update(after_input_step=previous["id"], delivered_action=action["action"],
                               input_worker_stdout=action["stdout"])
        try:
            return self.until(limit, observed, status, f"Missing native receipt {filename}", missing)
        except Failure as error:
            if self.result.get("global_timeout") and filename not in self.receipts:
                error.details.update(missing)
            raise

    def retry_continue(self, filename, limit):
        if self.manual_guest:
            return
        # The legacy loader can accept a first Space before the prompt becomes actionable.
        # Only retry once while both post-load signals are still absent.
        actions = self.result["actions"]
        if (filename not in {"dialog-shown.pld", "desktop-ab-HEARTBEAT-1.pld"} or not actions
                or actions[-1]["action"] != "confirm" or any(row.get("automatic_retry") for row in actions)
                or "dialog-shown.pld" in self.receipts or "desktop-ab-HEARTBEAT-1.pld" in self.receipts
                or self.elapsed() - actions[-1]["finished_elapsed"] < 4 or limit - time.monotonic() < 1):
            return
        self.poll(force=True)
        if "dialog-shown.pld" not in self.receipts and "desktop-ab-HEARTBEAT-1.pld" not in self.receipts:
            record = self.action({"action": "confirm"}, min(limit, time.monotonic() + 2), "retry-continue")
            record["automatic_retry"] = True

    def capture(self, step, limit, label):
        folder = self.profile / "bin/Screenshots"
        old = {path.name for path in folder.glob("*.tga")}
        self.action({"action": "game-screenshot"}, limit, label)

        def observed():
            for path in sorted(folder.glob("*.tga")):
                if path.name in old:
                    continue
                try:
                    info = inspect_tga(path, self.evidence / f"{step['id']}.bmp")
                except (ValueError, OSError):
                    continue
                if info["nonblank_client"]:
                    info["file"] = f"game-output/Screenshots/{path.name}"
                    return info
            return None

        return self.until(limit, observed, "assertion_failed", "No valid nonblank native screenshot")

    def natural_exit(self, limit, verify=True):
        def exited():
            code = self.job.poll()
            if code is None:
                return None
            return {"game_exit": legacy.read_receipts(self.evidence)[1], "host_exit": code}

        details = self.until(limit, exited, "timeout", "The game did not exit through the native menu", allow_exit=True)
        if verify and not (details["game_exit"] == ["natural", 0] and details["host_exit"] == 0):
            raise Failure("assertion_failed", "Natural zero-code game and host exit required", details)
        return details

    def apply_step(self, step, number):
        op = step["op"]
        label = f"step-{number:03d}-{step['id']}"
        default = ACTION_TIMEOUT if op in {"input", "capture"} else STEP_TIMEOUT
        limit = min(self.deadline, time.monotonic() + step.get("timeout_seconds", default))
        row = {"id": step["id"], "op": op, "status": "running", "started_elapsed": self.elapsed()}
        self.current = step
        self.result["steps"].append(row)
        self.save()
        try:
            if op in {"wait_receipt", "assert_receipt"}:
                row["details"] = self.receipt(step, limit)
            elif op == "input":
                row["details"] = self.action(step, limit, label)
            elif op == "wait_window":
                row["details"] = self.wait_window(limit, label)
            elif op == "capture":
                row["details"] = self.capture(step, limit, label)
            elif op == "heartbeat":
                after = time.time_ns()

                def sample():
                    best = heartbeat_span(self.profile, after)
                    return best if best["seconds"] >= step["seconds"] else None

                row["details"] = self.until(limit, sample, "assertion_failed", "Continuous heartbeat below target",
                                            lambda: heartbeat_span(self.profile, after))
            elif op == "wait_exit":
                row["details"] = self.natural_exit(limit)
            else:
                row["status"] = "pending_finalization"
                return
            row["status"] = "passed"
        except Failure as error:
            row.update(status=error.status, error=str(error), details=error.details)
            self.result["failed_step"] = step["id"]
            raise
        finally:
            row["finished_elapsed"] = self.elapsed()
            self.save()

    def close_job(self):
        cleanup = self.result["cleanup"]
        if not self.manual_guest and self.job.poll() is None and self.result.get("status") in {
                "assertion_failed", "input_invalid", "input_no_effect", "timeout"}:
            menu_already_sent = any(row["action"] == "menu" for row in self.result["actions"])
            heartbeat = max((stamp for name, stamp in self.observed_utc.items() if RECEIPT_TICK.fullmatch(name)), default=0)
            budget = min(self.deadline - time.monotonic(), 8)
            if not menu_already_sent and (time.time_ns() - heartbeat) < 3_000_000_000 and budget >= 3.5:
                try:
                    limit = time.monotonic() + budget
                    self.action({"action": "menu"}, limit, "cleanup-menu")
                    cleanup["menu"] = self.natural_exit(limit)
                except (Failure, OSError) as error:
                    cleanup["menu_error"] = str(error)
        if self.job.poll() is None:
            try:
                self.job.send("timeout-stop")
                self.result["timeout_sent"] = True
                cleanup["timeout_stop"] = True
            except BrokenPipeError:
                cleanup["timeout_stop"] = False
        self.result["host_exit"] = self.job.poll(8)
        if legacy.idle(self.job, 2)["active"]:
            cleanup["forced_owned_job_reap"] = self.job.reap(2)
            self.result["forced_job_reap"] = cleanup["forced_owned_job_reap"]
        self.result["members_after"] = self.job.pids()
        cleanup["job_accounting"] = self.job.accounting()
        self.result["game_exit"] = legacy.read_receipts(self.evidence)[1]
        with suppress(Failure, OSError):
            self.poll(force=True)

    @contextmanager
    def launch(self, host, env, pair):
        args = (host, self.profile, self.result["desktop"], self.evidence, env)
        with ExitStack() as stack:
            try:
                if pair is None:
                    require_game_idle()
                    job = stack.enter_context(OwnedJob(*args))
                else:
                    job = stack.enter_context(pair.open_job(*args))
            except OSError as error:
                raise Failure("startup_failed", f"Cannot launch the isolated runtime: {error}") from error
            yield job

    def execute(self, pair=None):
        host, argv, env = legacy.host_settings(self.evidence, self.profile, "game")
        self.result["client_argv"] = argv
        self.result["runtime_host_argv"] = [str(part) for part in host]
        self.result["host_launch_elapsed"] = self.elapsed()
        self.save()
        with self.launch(host, env, pair) as job:
            self.job = job
            self.result["host_pid"] = job.pid
            try:
                try:
                    self.result["game_pid"] = legacy.wait_pid(self.job, self.evidence,
                                                              min(HOST_TIMEOUT, self.remaining(self.deadline)))
                except (OSError, RuntimeError) as error:
                    self.remaining(self.deadline)
                    raise Failure("startup_failed", str(error)) from error
                self.result["initial_job_members"] = self.job.pids()
                self.result["owned_pid_elapsed"] = self.elapsed()
                for number, step in enumerate(self.config["steps"], 1):
                    self.apply_step(step, number)
                # A naturally closed game is part of every passing scenario, even if omitted from its steps.
                self.natural_exit(min(self.deadline, time.monotonic() + 2))
                self.result["status"] = "passed"
            except Failure as error:
                self.result.update(status=error.status, error=str(error), error_details=error.details)
            except Exception as error:
                self.result.update(status="execution_failed", error=repr(error), traceback=traceback.format_exc())
                if self.current:
                    self.result["failed_step"] = self.current["id"]
            finally:
                self.close_job()


def run_pair(runtime, runs):
    pair = PairedGames()
    require_game_idle()
    with legacy.exclusive_game():
        require_game_idle()
        with ThreadPoolExecutor(max_workers=2) as workers:
            futures = [workers.submit(pair.run, evidence, runtime, config, result)
                       for evidence, config, result in runs]
            return [future.result() for future in futures]


def run_scenario(evidence, runtime, config, result, *, manual_guest=False, cache_base_mpqs=False, pair=None):
    started = time.monotonic()
    build = ROOT / "codexwork/build/war3-test"
    profile = build / f"profile-{uuid.uuid4().hex}"
    result.update(profile=str(profile), started_utc=legacy.utc(), mode="manual-guest" if manual_guest else "private-desktop",
                  phase="preflight", map_sha256=config["map"]["sha256"], steps=[], actions=[], events=[], failed_step=None,
                  phase_wall_seconds={}, staging_mode="guarded-mpq-cache" if cache_base_mpqs else "full-copy",
                  cleanup={"desktop_opened": False, "desktop_closed": False, "profile_created": False,
                           "profile_removed": False})
    trial = None
    manifest = None
    staged_identity = None
    with ExitStack() as ownership, ExitStack() as guards:
        try:
            legacy.write_json(evidence / "result.json", result)
            build.mkdir(parents=True, exist_ok=True)
            if build.resolve(strict=True) != build:
                raise Failure("environment_unavailable", "Build directory resolved outside its project path")
            result["input_desktop_before"] = input_name()
            if manual_guest:
                result["guest_canary"] = guest_desktop()
                if not result["guest_canary"]["pass"]:
                    raise Failure("environment_unavailable", "Manual guest requires an active Default desktop and readable cursor")
                result["guest_operator_menu"] = ["F10", "E", "X", "X"]
            if pair is None:
                require_game_idle()
                # Keep ownership until the old profile's guarded aliases are removed.
                ownership.enter_context(legacy.exclusive_game())
                require_game_idle()
            deferred = None
            target = nullcontext(legacy.DEFAULT) if manual_guest else PrivateDesktop()
            with target as desktop:
                result["desktop"] = desktop
                result["cleanup"]["desktop_opened"] = not manual_guest
                try:
                    if not manual_guest and desktop.split("\\")[-1] == result["input_desktop_before"]:
                        raise Failure("environment_unavailable", "Private test desktop is the active input desktop")
                    try:
                        result["phase"] = "staging"
                        legacy.write_json(evidence / "result.json", result)
                        timings = result["phase_wall_seconds"]
                        before_hash = time.monotonic()
                        result["map_source_before_sha256"] = digest(Path(config["map"]["path"]))
                        timings["verify_map_before"] = round(time.monotonic() - before_hash, 3)
                        if result["map_source_before_sha256"] != config["map"]["sha256"]:
                            raise RuntimeError("Source map changed since config validation")
                        manifest, staged_identity = stage(
                            runtime, config["map"], profile, timings, guards=guards, created=result["cleanup"],
                            cache_root=build / "base-mpq-cache" if cache_base_mpqs else None)
                    except (RuntimeError, OSError, ValueError, KeyError, TypeError) as error:
                        raise Failure("environment_unavailable", f"Cannot stage verified cold-start inputs: {error}") from error
                    result["identity"] = staged_identity
                    result["runtime_manifest_sha256"] = digest(runtime / "inputs.json")
                    result["staging_wall_seconds"] = round(time.monotonic() - started, 3)
                    if pair is not None:
                        pair.await_peer()
                    result["phase"] = "game"
                    trial = Trial(evidence, profile, config, result)
                    if pair is None:
                        trial.execute()
                    else:
                        trial.execute(pair)
                except Failure as error:
                    deferred = error
            result["cleanup"]["desktop_closed"] = not manual_guest
            if deferred:
                raise deferred
        except Failure as error:
            result.update(status=error.status, error=str(error), error_details=error.details)
        except (RuntimeError, OSError) as error:
            result.update(status="execution_failed" if trial else "environment_unavailable",
                          error=repr(error), traceback=traceback.format_exc())
        finally:
            result["phase"] = "cleanup"
            finalize(evidence, build, profile, manifest, staged_identity, result, config, trial, started, guards)
    return result


def finalize(evidence, build, profile, manifest, staged_identity, result, config, trial, started, guards):
    finalize_started = time.monotonic()
    timings = result["phase_wall_seconds"]
    cleanup = result["cleanup"]
    errors = cleanup.setdefault("errors", [])
    result["finished_utc"] = legacy.utc()
    if trial:
        result["elapsed_seconds"] = trial.elapsed()
    try:
        result["input_desktop_after"] = input_name()
        if result.get("input_desktop_before") and result["input_desktop_after"] != result["input_desktop_before"]:
            errors.append("Input desktop changed")
        result["map_source_after_sha256"] = digest(Path(config["map"]["path"]))
        result["hashes_after_match"] = result["map_source_after_sha256"] == config["map"]["sha256"]
        if manifest is not None:
            result["hashes_after_match"] &= staged_identity == identity(profile, manifest, config["map"]["sha256"])
        if not result["hashes_after_match"]:
            errors.append("Map or staged input hashes changed")
    except (RuntimeError, OSError) as error:
        result["hashes_after_match"] = False
        errors.append(str(error))
    timings["verify_inputs_after"] = round(time.monotonic() - finalize_started, 3)
    archive_started = time.monotonic()
    try:
        if cleanup["desktop_opened"] and not cleanup["desktop_closed"]:
            errors.append("Private desktop close was not confirmed")
        if result.get("status") == "passed" and result.get("forced_job_reap"):
            errors.append("Natural exit left owned child processes requiring reap")
        if cleanup["profile_created"] and profile.exists():
            raw = {}
            for part in ("Logs", "Replay", "Errors", "Screenshots"):
                folder = profile / "bin" / part
                if folder.exists():
                    if is_reparse_point(folder):
                        raise RuntimeError(f"Cannot archive a reparse point: {folder}")
                    raw.update({f"{part}/{name}": value for name, value in archive_inventory(folder).items()})
            result["raw_evidence"] = legacy.archive_game_outputs(evidence, profile)
            temporary = profile / "bin/TempReplay.w3g"
            if temporary.is_file():
                if is_reparse_point(temporary):
                    raise RuntimeError(f"Cannot archive a reparse point: {temporary}")
                raw[temporary.name] = digest(temporary)
                shutil.copy2(temporary, evidence / "game-output/TempReplay.w3g")
            if raw != archive_inventory(evidence / "game-output"):
                raise RuntimeError("Archive copy failed content verification")
            cleanup["archive_verified_files"] = len(raw)
        timings["archive_output"] = round(time.monotonic() - archive_started, 3)
        cleanup_started = time.monotonic()
        baseline = set(result.get("initial_job_members", [])) | {result.get("game_pid"), result.get("host_pid")}
        result["remaining_game_processes"] = [row for row in process_snapshot() if row["pid"] in baseline]
        if result["remaining_game_processes"] or result.get("members_after"):
            errors.append("Owned processes remain after supervision")
        guards.close()
        if cleanup["profile_created"] and profile.exists() and not result["remaining_game_processes"] and not result.get("members_after"):
            resolved = profile.resolve(strict=True)
            if resolved.parent != build.resolve(strict=True) or resolved.name != profile.name:
                raise RuntimeError("Refusing cleanup outside the new isolated profile")
            if is_reparse_point(profile) or any(is_reparse_point(path) for path in profile.rglob("*")):
                raise RuntimeError("Refusing cleanup with a symlink or other reparse point")
            shutil.rmtree(resolved)
            cleanup["profile_removed"] = not profile.exists()
        timings["check_processes_and_remove_profile"] = round(time.monotonic() - cleanup_started, 3)
    except (RuntimeError, OSError) as error:
        errors.append(str(error))
    if errors:
        result.update(primary_status=result.get("status"), status="cleanup_failed")
    verdict_name = config["steps"][-1]["op"]
    if trial and verdict_name in FINAL_VERDICTS and result.get("raw_evidence"):
        try:
            if verdict_name == "selection_verdict":
                from selection_verdict import evaluate
            else:
                from route_verdict import evaluate

            verdict = result[verdict_name] = evaluate(result, evidence)
            if result["status"] == "passed":
                row = result["steps"][-1]
                row["details"] = verdict
                row["status"] = "passed" if verdict["passed"] else "assertion_failed"
                if not verdict["passed"]:
                    result.update(status="assertion_failed", failed_step=row["id"],
                                  error=f"Strict native evidence was incomplete ({verdict_name})")
        except (OSError, RuntimeError, ValueError, KeyError, ImportError) as error:
            result[f"{verdict_name}_error"] = repr(error)
            if result["status"] == "passed":
                row = result["steps"][-1]
                row.update(status="execution_failed", error=repr(error))
                result.update(status="execution_failed", failed_step=row["id"], error=repr(error))
    result["exit_code"] = EXIT_CODES[result["status"]]
    result["phase"] = "finished"
    result["terminal"] = True
    result["wall_seconds"] = round(time.monotonic() - started, 3)
    timings["finalize"] = round(time.monotonic() - finalize_started, 3)
    legacy.write_json(evidence / "result.json", result)
