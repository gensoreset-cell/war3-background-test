"""Assemble a portable test runtime from the user's Warcraft III files and map."""

import argparse
import json
from pathlib import Path
import shutil
import struct
import sys
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parent / "war3-test"))
from war3_test_config import ROOT, RUNTIME, SCENARIOS, digest
from war3_test_runner import MAP_INPUT, parse_runtime_inputs


PAYLOAD = ROOT / "codexwork/assets/war3-runtime"
CLIENT_FILES = frozenset(f"bin\\{name}" for name in (
    "War3.exe", "Game.dll", "Storm.dll", "mss32.dll", "ijl15.dll",
    "War3.mpq", "War3x.mpq", "War3Patch.mpq", "War3xLocal.mpq",
))
SCENARIO = SCENARIOS / "map-window-smoke.json"


def write_json(path, value):
    with path.open("x", encoding="utf-8") as output:
        json.dump(value, output, indent=2, ensure_ascii=False)
        output.write("\n")


def install(war3_dir, map_path):
    if RUNTIME.exists() or SCENARIO.exists():
        raise ValueError("运行基线或 map-window-smoke.json 已存在。请将移植包解压到新的目录。")
    if map_path.suffix.lower() not in {".w3x", ".w3m"} or not map_path.is_file():
        raise ValueError("请指定可读的 .w3x 或 .w3m 地图文件。")
    baseline = parse_runtime_inputs(json.loads((PAYLOAD / "inputs.template.json").read_bytes()))
    inputs = []
    missing = []
    for name, (length, expected) in baseline.items():
        source = map_path if name == MAP_INPUT else (
            war3_dir / Path(name).name if name in CLIENT_FILES else PAYLOAD / "profile" / name)
        if not source.is_file():
            missing.append(source)
        inputs.append((name, source, length, expected))
    if missing:
        raise ValueError("缺少运行文件：\n" + "\n".join(map(str, missing)))
    for name in ("bin\\War3.exe", "bin\\Game.dll"):
        path = war3_dir / Path(name).name
        if digest(path) != baseline[name][1]:
            raise ValueError(f"{path} 与已验证的 War3 1.27.0.52240 客户端不匹配。请选择匹配的客户端目录。")

    RUNTIME.parent.mkdir(parents=True, exist_ok=True)
    SCENARIOS.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix="war3-portable-install-", dir=RUNTIME.parent) as scratch:
        staged = Path(scratch) / "runtime"
        manifest = []
        for name, source, length, expected in inputs:
            destination = staged / "profile" / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            size, checksum = destination.stat().st_size, digest(destination)
            if name not in CLIENT_FILES and name != MAP_INPUT and (size, checksum) != (length, expected):
                raise ValueError(f"移植包文件校验失败：{source}")
            manifest.append({"path": name, "length": size, "sha256": checksum})
        parse_runtime_inputs(manifest)
        write_json(staged / "inputs.json", manifest)
        staged.rename(RUNTIME)

    map_identity = next(row for row in manifest if row["path"] == MAP_INPUT)
    write_json(SCENARIO, {
        "version": 1, "name": "map-window-smoke",
        "description": "等待游戏窗口，尝试通过加载界面，截图并验证游戏菜单正常退出。按待测地图调整操作。",
        "map": {"path": (RUNTIME / "profile" / MAP_INPUT).relative_to(ROOT).as_posix(),
                "sha256": map_identity["sha256"]},
        "timeout_seconds": 180,
        "steps": [
            {"id": "owned-window", "op": "wait_window", "timeout_seconds": 45},
            {"id": "continue-loading", "op": "input", "action": "confirm", "settle_seconds": 15},
            {"id": "game-screenshot", "op": "capture", "timeout_seconds": 30},
            {"id": "native-quit-menu", "op": "input", "action": "menu"},
            {"id": "natural-exit", "op": "wait_exit", "timeout_seconds": 15},
        ],
    })
    print(json.dumps({"status": "installed", "runtime": str(RUNTIME), "scenario": str(SCENARIO),
                      "map_sha256": map_identity["sha256"]}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--war3-dir", required=True, type=Path, help="包含 War3.exe 和 MPQ 的目录")
    parser.add_argument("--map", required=True, type=Path, help="使用你自己的 .w3x 或 .w3m 地图")
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 13) or struct.calcsize("P") != 8:
        parser.error("请使用 Windows 上的 Python 3.13 x64。")
    try:
        install(args.war3_dir.resolve(strict=True), args.map.resolve(strict=True))
    except (ValueError, OSError) as error:
        parser.exit(1, f"{error}\n")


if __name__ == "__main__":
    main()
