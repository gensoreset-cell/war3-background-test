-- The Python entry point supplies this profile's paths as Lua byte literals.
package.path = input.script_path .. '\\?.lua'
package.cpath = input.native_path .. '\\modules\\?.dll;' .. input.native_path .. '\\?.dll'
assert(package.loadlib(input.native_path .. '\\ydbase.dll', '*'))

local function output(message)
    print(tostring(message))
end
log = {debug = output, error = output, trace = output}
__ = require('ffi.unicode').u2a
require 'util'

local cfg = assert(sys.ini_load(fs.path(input.plugin_config)))
local enabled = cfg.Enable or {}
local expected = {}
local required = 0
for name in string.gmatch(input.expected_plugins or 'yd_jass_api.dll', '[^,]+') do
    assert(not expected[name], 'duplicate plug-in in launch profile')
    expected[name] = true
    required = required + 1
end
local count = 0
for name, value in pairs(enabled) do
    if value == '1' then
        assert(expected[name], 'unexpected game plug-in: ' .. name)
        count = count + 1
    end
end
assert(required > 0 and count == required and type(sys.spawn_inject) == 'function', 'test entrance or plug-in selection missing')
print('M1_LEGACY_JAPI_PREFLIGHT_OK')

local function launch_with_retained_handle(command_line, current_dir, loader)
    -- Keep the handle which the release's test helper otherwise closes on return.
    local factory, owned = sys.process, nil
    sys.process = function()
        assert(not owned, 'legacy test entrance unexpectedly created two process objects')
        owned = factory()
        return setmetatable({close = function() end}, {__index = function(_, name)
            local method = owned[name]
            return function(_, ...) return method(owned, ...) end
        end})
    end
    local ok, started = pcall(sys.spawn_inject, nil, command_line, current_dir, loader)
    sys.process = factory
    if not ok or not started then
        if owned then owned:close() end
        error(ok and 'legacy test entrance failed' or started)
    end
    return assert(owned)
end

local function wait_for_owned_exit(owned, pid_file)
    local pid = assert(owned:id())
    local file = assert(io.open(pid_file, 'wb'))
    assert(file:write(tostring(pid)))
    assert(file:close())
    print('M1_LEGACY_JAPI_OWNED_PID', pid)
    io.stdout:flush()

    local exit_kind = 'natural'
    while input.wait_mode ~= 'normal-exit' and owned:is_running() do
        local command = io.read('*l')
        if command == 'timeout-stop' then
            if owned:is_running() then
                if owned:kill() then
                    exit_kind = 'timeout_terminated'
                elseif owned:is_running() then
                    owned:close()
                    error('owned process rejected timeout cleanup')
                end
            end
            break
        end
        if command == nil and owned:is_running() then
            owned:close()
            error('supervisor input closed before the owned process exited')
        end
        if owned:is_running() then
            print('M1_LEGACY_JAPI_OWNED_RUNNING', pid)
            io.stdout:flush()
        end
    end
    local exit_code = owned:wait()
    owned:close()
    assert(type(exit_code) == 'number', 'missing owned process exit code')
    print('M1_LEGACY_JAPI_OWNED_EXIT', exit_kind, exit_code)
    io.stdout:flush()
end

if input.action == 'launch' then
    -- The distribution's editor test helper is reused unchanged; it detaches on success.
    local started = sys.spawn_inject(nil, input.command_line, fs.path(input.client_dir), fs.path(input.loader))
    assert(started, 'legacy YDWE test entrance did not create the requested game process')
    print('M1_LEGACY_JAPI_GAME_CREATED')
elseif input.action == 'launch-managed' then
    local owned = launch_with_retained_handle(input.command_line, fs.path(input.client_dir), fs.path(input.loader))
    wait_for_owned_exit(owned, fs.path(input.pid_file))
end
