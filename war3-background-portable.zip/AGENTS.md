# 通用 War3 后台测试工具安装说明

用户可以把压缩包交给 Codex 并说「请按包内 `AGENTS.md` 安装 War3 后台测试工具，并接入本机 Codex 全局规则」。接到安装任务后，在目标 Windows 电脑上完成下面的步骤，并报告实际路径和验证结果。

## 找到本机依赖

1. 将压缩包完整解压到用户指定的新目录。没有指定时，在当前项目下选一个空目录，例如 `codexwork/war3-background-tool`。以包含本说明的目录为工具根，不需要沿用打包电脑的盘符或用户名。不要把工具解压到 War3 安装目录。
2. 优先寻找系统上的 Python 3.13 x64。尝试 `py -3.13`、`Get-Command python`、已安装的 uv，以及用户现有的 Python 安装目录。用实际解释器运行 `-c "import sys, struct; print(sys.version, struct.calcsize('P') * 8)"`，确认是 3.13 和 64 位。缺失时通过目标电脑可用的可信安装方式安装 Python 3.13 x64，再确认实际解释器路径。
3. 找到已有 War3 目录。优先使用用户指定的位置；否则从已有快捷方式、安装位置和项目配置中定位，并确认同一目录下存在 `War3.exe`、`Game.dll`、`Storm.dll`、`mss32.dll`、`ijl15.dll` 及 `War3.mpq`、`War3x.mpq`、`War3Patch.mpq`、`War3xLocal.mpq`。版本目标是已验证的 1.27.0.52240，装配脚本会核对 `War3.exe` 和 `Game.dll` 的指纹。若有多个候选，优先用脚本能验证的安装；缺少匹配客户端时报告缺少的文件或指纹差异。
4. 用用户指定的 `.w3x` 或 `.w3m`。安装任务没有指定地图时，可用该客户端已有的本地地图做首次装配。找不到地图时，向用户要一个可读的地图路径。包内提供测试程序和插件，War3 本体、地图和缓存从目标电脑取得。

## 装配与验证

在工具根目录执行以下 PowerShell 命令。把示例变量替换为实际查到的路径。

```powershell
$py = '实际的 Python 3.13 x64 解释器路径'
$war3Dir = 'War3.exe 所在目录'
$map = '实际待测地图的绝对路径'
$cli = 'codexwork/scripts/war3-test/war3_test.py'

& $py -B -X utf8 codexwork/scripts/install_portable_war3.py --war3-dir $war3Dir --map $map
if ($LASTEXITCODE -ne 0) { throw '运行基线装配失败' }
& $py -B -X utf8 $cli env
if ($LASTEXITCODE -ne 0) { throw '运行环境检查失败' }
& $py -B -X utf8 $cli list
if ($LASTEXITCODE -ne 0) { throw '场景目录检查失败' }
& $py -B -X utf8 $cli validate --scenario map-window-smoke
if ($LASTEXITCODE -ne 0) { throw '场景预检失败' }
```

装配会将已有客户端文件、包内启动文件和待测地图复制到工具自己的运行基线，并生成 SHA-256 清单和 `map-window-smoke` 场景。目标机的安装目录只用于取文件。装配完成后保留运行基线和生成的场景，后续测试直接使用它们。

安装任务包含实机验收时，按待测地图的加载提示调整 `map-window-smoke` 操作和等待时间，再运行。遇到现有游戏或编辑器时保留其进程，由工具按环境检测结果处理。

```powershell
$evidence = 'codexwork/logs/war3-test/smoke-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
& $py -B -X utf8 $cli run --scenario map-window-smoke --evidence-dir $evidence
```

实机完成后读取该轮 `result.json`，查看原生截图、退出码和清理状态。用截图确认画面达到了预期，窗口启动和非空截图只是各自的观察结果。要自动验收选人、任务或战斗，给对应地图的场景补上实际操作和回执断言。

后续单轮换图时，用对应场景并传入 `--map <地图路径> --sha256 <地图SHA-256>`。双开用 `run-pair --scenario <场景一> <场景二> --evidence-dir <新目录>`，各场景 JSON 各自记录地图路径和 SHA-256。

## 接入本机 Codex

安装任务包含全局接入时，在目标电脑的 Codex 用户目录找到 `AGENTS.md`，默认是 `%USERPROFILE%\.codex\AGENTS.md`，使用自定义 Codex 用户目录时以实际目录为准。保留原有规则，更新已有 War3 后台测试段落或新增一个段落。用本机工具根、入口和 Python 的真实绝对路径填入规则。

规则应要求 AI 遇到 War3、KKWE 或 JAPI 的本地实机测试时先读本文，调用已装配的共享 CLI。先运行 `env`、`list` 和匹配场景的 `validate`，单轮使用 `run`，两轮可并行时使用一次 `run-pair`。将证据写到正在测试的项目的 `codexwork/logs` 下的新目录，通过该轮终态、实际游戏回执、退出和清理判定。项目专用自测、联机或平台验收按各自的运行条件执行。

完成后报告实际的工具、Python 和 War3 目录、预检结果，以及更新过的全局规则路径。实机步骤如果因地图、客户端或环境受阻，报告对应的失败回执。
